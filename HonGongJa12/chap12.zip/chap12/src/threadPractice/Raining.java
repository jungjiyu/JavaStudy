package threadPractice;

public class Raining implements Runnable{
	private final int index;
	
	Raining(int index){
		this.index = index;
	}
	@Override
	public void run() {
		System.out.println(index+" Started rainging");
		try {
			Thread.sleep(1000);
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println(index+" Ended raining");
	}
}
