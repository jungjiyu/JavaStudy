package threadPractice;

public class Snowing implements Runnable {
	private int index;
	private String name;
	
	Snowing(int index){
		this.index = index;
		Thread tmp = Thread.currentThread();
		name = tmp.getName();
		System.out.println(name+"스레드의 객체가 생성되었습니다");
	}

	@Override
	public void run() {
		System.out.println("우와 "+index+"번째로 눈 온다");
		Thread tmp = Thread.currentThread();
		String name = tmp.getName(); 
		
		System.out.print("(Snowing 내부)현재 스레드:"+name);
		tmp.setName("SnowingThread"+index);
		System.out.println("\t변경된 이름:" + tmp.getName());
		
		
		System.out.println("와 "+index+"번째 눈이 그쳤다");
	}

}
