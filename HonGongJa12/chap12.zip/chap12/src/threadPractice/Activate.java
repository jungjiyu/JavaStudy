package threadPractice;

public class Activate {
	public static void main(String[] args) {
		for(int i = 0 ; i <10 ; i++) {
			Runnable snow = new Snowing(i);
			Thread thread1 = new Thread(snow);
		//	thread1.setDaemon(true);
			thread1.start();
			Thread tmp = Thread.currentThread();
			String name = tmp.getName(); 
			System.out.println("현재 스레드:"+name);
			
			// 중단 시키면서 하지 않으면 
				// 작업 스레드에 비해 메인 스레드가 너무 빨리 종료되고 (스레드 객체가 실행되는 속도가 생각보다 넘 느림)
				// 스레드 객체들이 빨리 생성됬다 하더라도 (스레드 객체가 실행되는 속도가 제각각이여서 ) 너무나도 무작위로 순서로 실행되서 잠시 중단 시키고 다음 스레드 객체 생성
			
			try {
			//	Thread.sleep(100);
			}catch(Exception e) {}
			
			
		}
		
		
		/*
		for(int i = 0 ; i <10 ; i++) {
			Runnable snow = new Snowing(i);
			Thread thread1 = new Thread(snow);
			thread1.setDaemon(true);
			thread1.start();
			
		}
		
	
		
		for(int i = 0 ; i <10 ; i++) {
			Runnable rain = new Raining(i); // Runnable 인터페이스 구현 객체
			Thread thread = new Thread(rain);
			thread.setDaemon(true);
			thread.start();
			
			
			
		}
		
		// 익명 구현 객체 생성
		for(int i = 0 ; i <10 ; i++) {
			Thread thread1 = new Thread(new Runnable() {
				
				@Override
				public void run() {
					System.out.println("번개 우르릉쾅쾅 시작");
					try{
						Thread.sleep(1000);
					}catch(Exception e) {}
					
					System.out.println("번개 우르릉쾅쾅 종료");

				}
			});
			thread1.setDaemon(true);
			thread1.start();
			
		}
		
		// 익명 자식 객체 생성
				for(int i = 0 ; i <10 ; i++) {
					Thread thread1 = new Thread(){
						@Override
						public void run() {
							System.out.println("우박 딱딱딱ㄸ..딱 시작");
							try{
							//	Thread.sleep(10000);
							}catch(Exception e) {}
							
							System.out.println("우박 딱딱딱ㄸ..딱 종료");

						}
					};
					thread1.setDaemon(true);

					thread1.start();
					
				}
				*/
		
		System.out.println("main thread ended");
		
	}

}
