package controlMthdPractice;

public class Activate {
	public static void main(String[] args) {
		Dancing d = new Dancing(); // setStop 써볼려고 Thread의 자식객체를 생성했음 (구현객체 생성하고 직접 Thread 객체를 만들지 않구)
		d.start();
		try {
			Thread.sleep(2000); 
		}catch(InterruptedException e) {}
		
		d.setStop(true);  
	}

}
