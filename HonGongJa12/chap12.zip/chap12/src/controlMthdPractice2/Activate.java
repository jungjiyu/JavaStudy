package controlMthdPractice2;

public class Activate {
	public static void main(String[] args) {
		Runnable dancing = new Dancing();
		Thread thread = new Thread(dancing);
		thread.start();
		try {Thread.sleep(2000);}catch(Exception e) {} // 걍 2초동안 실행되게 냅두는 코드
		System.out.println("haiyaaaaaaaaaa");
		thread.interrupt();
	}

}
