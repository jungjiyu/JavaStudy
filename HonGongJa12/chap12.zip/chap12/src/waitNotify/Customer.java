package waitNotify;

import java.util.ArrayList;

public class Customer implements Runnable{
	private Table table;
	private ArrayList <String> stomach = new ArrayList<String>();
	private static int index= 0;
	
	Customer(Table table){
		Thread t = Thread.currentThread();
		String name = t.getName();
		System.out.println("Customer 스레드 객체가 "+name+"스레드 객체에 의해 생성됨");
		this.table = table;
		index++;
	}
	
	@Override
	public void run() {
		Thread t = Thread.currentThread(); // run( ) 을 돌리는건 이 구현클래스로 만들어진 Thread 객체
		t.setName("CustomerThread-"+index);
		System.out.println("*손님이 식당에 들어왔습니다*");

		while(true) {
		System.out.println("아 음식 내놔");
		String food = table.getFood();
		if(food.equals("EOF")) break;
		stomach.add(food);
		System.out.println(food+"가 참 맛있군 음음~");
		
		}
		System.out.println("*손님이 거하게 먹고 식당을 나가셨습니다*");
		System.out.println("Customer Thread ended");

		
	}

}
