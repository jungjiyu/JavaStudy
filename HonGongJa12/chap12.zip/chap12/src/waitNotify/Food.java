package waitNotify;

import java.util.ArrayList;

public class Food implements Runnable{
	private ArrayList <String> cookedFood = new ArrayList<String>();
	private Table table;
	private static int index=0;

	Food(Table table){
		Thread t = Thread.currentThread();
		String name = t.getName();
		System.out.println("Food 스레드 객체가 "+name+"객체에 의해 생성");
		
		cookedFood.add("Bannana");
		cookedFood.add("Chocolate");
		cookedFood.add("Hambuger");
		cookedFood.add("Almond");
		cookedFood.add("Blackbean Noodles");
		cookedFood.add("Chicken");
		
		this.table = table;
		index++;
		
	}
	
	@Override
	public void run() {
		Thread t = Thread.currentThread(); // run( ) 을 돌리는건 이 구현클래스로 만들어진 Thread 객체
		t.setName("FoodThread-"+index);
		System.out.println("주방에 들어왔습니다");
		
		// ArrayList 쓸때 이런식으로 루프문 돌면서 삭제하면 안되는게 
			//i가 계속 0으로 초기화 되는게 아니라 계속 증가하는 꼴인데 
			//remove로 빠지고 남은 얘들은 그대로 뒷 인덱스에 남아있는게 아니라 앞으로 인덱스가 당겨져서 접근 못하는 상황에 빠진다.
		/*
		for(int i = 0 ; i <cookedFood.size(); i++) {
			System.out.println(cookedFood.size()+cookedFood.get(i)+"을 주방에서 가져갔습니다");
			table.addFood(cookedFood.get(i));
			cookedFood.remove(i);
		}
		*/
		
		for(int i = 0 ; i <cookedFood.size(); i++) {
			System.out.println(cookedFood.get(i)+"을 주방에서 가져갔습니다");
			table.addFood(cookedFood.get(i));
			System.out.println(cookedFood.size());

		}
		table.addFood("EOF"); // 종료 지점 표시
		
	/*	while(cookedFood.size()>0) {
			System.out.println(cookedFood.size());
			cookedFood.remove(0);
		}*/
		System.out.println("만든 음식을 다 주방서 내놓았습니다");
		System.out.println("Food Thread ended");

		
	}

}
