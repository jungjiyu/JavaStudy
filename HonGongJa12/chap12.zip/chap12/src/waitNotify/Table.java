package waitNotify;

import java.util.ArrayList;

public class Table { // 공유 객체
	private ArrayList <String> foodStack = new ArrayList<String>();
	
	Table(){
		System.out.println("띠링~ 테이블 생성");
	}
	
	public synchronized void addFood(String food) { 
		foodStack.add(food);
		notifyAll(); // 일처리 했다고 다시 조건 만족 되는지 검사하게 함
		
		if(!food.equals("EOF")) {
		
		System.out.println(food+"가 테이블에 놓였습니다");
		
		try{ // try 문까지 if 문 안에 넣은 것은 마지막 턴에선 wait( ) 가 걸리면 안되기 때문이다.
			Thread t = Thread.currentThread();
			String name = t.getName();
			System.out.println(name+"을 웨이팅 리스트에 올립니다");
			wait(); // 손님이 다 먹은 다음에 음식을 추가하려고 대기 리스트에 올림
			}catch(InterruptedException e) {}
		}
	}
	
	public synchronized String getFood() {
		while(foodStack.size() == 0) {
			System.out.println("음식이 없네요. 잠시 기다려보죠");
			notifyAll(); // 락 제거
			try{
				Thread t = Thread.currentThread();
				String name = t.getName();
				System.out.println(name+"을 웨이팅 리스트에 올립니다");
			wait(); // 지금 해도 되는거 없으니 자신은 일단 중지
			}catch(InterruptedException e) {}
		}
		
		String food = foodStack.get(0);
		foodStack.remove(0);
		
		if(!food.equals("EOF")) System.out.println(food+"가 나왔습니다. 맛있게 드세영");
		else System.out.println("모든 음식을 다 드렸습니다");
		return food;
		
		
		
		
	}

}
