package waitNotify;

public class Activate {
	public static void main(String[] args) {
		Table table = new Table();
		Thread foodThread = new Thread(new Food(table));
		Thread customerThread = new Thread(new Customer(table));
		foodThread.start();
		customerThread.start();
		
		try {
			foodThread.join();
			customerThread.join();
		}catch(Exception e) {}
		
		System.out.println("Main Thread ended");
	}

}
