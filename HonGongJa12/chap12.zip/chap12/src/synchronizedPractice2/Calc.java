package synchronizedPractice2;

public class Calc {
	private int valueA = 0;
	private int valueB = 0;
	private boolean isASetted = false;
	private boolean isBSetted = false;
	
	Calc(){
		System.out.println("Calc 객체 생성됨");
	}
	
	public void setValueA(String name,int valueA) {
		this.valueA = valueA;
		isASetted = true;
		System.out.println(name+" 스레드에의해 valueA값이 초기화되었습니다");
	}
	
	public void setValueB(String name,int valueB) {
		this.valueB = valueB;
		isBSetted = true;
		System.out.println(name+" 스레드에의해 valueB값이 초기화되었습니다");

	}

	public synchronized void sum(String name,int valueA ,int valueB) {
		setValueA(name,valueA);
		setValueB(name,valueB);
		if(isBSetted && isASetted) {
			try { // 학습 차원에서 다른 스레드에 의해서 방해 받기 위해 일부러 sleep 걸어둠
				Thread.sleep(2000);
			}catch(Exception e) {}
			System.out.println(name+"스레드에서: "+ valueA+"+"+valueB+"="+(valueA+valueB));
		}
		else System.out.println("피연산자 값을 모두 초기화 해주세요");
	}

}
