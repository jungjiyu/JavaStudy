package daemonPractice;

public class AutoSaveThread implements Runnable{
	public void save() {
		System.out.println("작업내용을 저장함");
	}
	
	@Override
	public void run() {
		while(true) { // 무한 루프 돌게함
			try {
				Thread.sleep(1000);
			}catch(InterruptedException e) {
				break;
			}
			save();
		}
	}
}
