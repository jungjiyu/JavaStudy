package daemonPractice;

public class DaemonControl {
	public static void main(String[] args) {
		AutoSaveThread ast = new AutoSaveThread();
		Thread primeThread = new Thread(ast); // public void Thread(Runnable rn)
		primeThread.setDaemon(true);
		primeThread.start();
		
		try {
			Thread.sleep(3000); // 이거 안주면 주 스레드의 종료와 함께 데몬 스레드도 종료되서 별 효과가 없어짐 
			
		}catch(Exception e) {
		}
		System.out.println("메인 스레드 종료");

	}

}
