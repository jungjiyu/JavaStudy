package synchronizedPractice;

public class Calc {
	private int valueA = 0;
	private int valueB = 0;
	private boolean isASetted = false;
	private boolean isBSetted = false;
	
	Calc(){
		System.out.println("Calc 객체 생성됨");
	}
	
	public void setValueA(String name,int valueA) {
	//	System.out.println(name+" 스레드에의해 valueA값이"+valueA+"로 초기화되었습니다11111");

		this.valueA = valueA;
		isASetted = true;
		System.out.println(name+" 스레드에의해 valueA값이"+valueA+"로 초기화되었습니다");
	}

	public void setValueB(String name,int valueB) {
	//	System.out.println(name+" 스레드에의해 valueB값이"+valueB+"로초기화되었습니다22222");

		this.valueB = valueB;
		isBSetted = true;
		System.out.println(name+" 스레드에의해 valueB값이"+valueB+"로초기화되었습니다");

	}

	
	public void sum(String name,int valueA ,int valueB) {
		setValueA(name,valueA);
		setValueB(name,valueB);
		try { // 학습 차원에서 다른 스레드에 의해서 방해 받기 위해 일부러 sleep 걸어둠
			Thread.sleep(2000);
		}catch(Exception e) {}
		if(isBSetted && isASetted) {
			
			System.out.println(name+"스레드에서: "+ this.valueA+"+"+this.valueB+"="+(this.valueA+this.valueB)); // 그냥 valueA , valueB 쓰면 매개변수값이 쓰이는거지 필드값이 쓰이는게 아니다
		}
		else System.out.println("피연산자 값을 모두 초기화 해주세요");
	}

}
