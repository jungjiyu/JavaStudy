package synchronizedPractice;

public class A implements Runnable{
	private Calc myCalc ; 
	
	A(Calc myCalc){
		this.myCalc = myCalc;
	}

	@Override
	public void run() {
		
		myCalc.sum("A",100,100);
	}
}
