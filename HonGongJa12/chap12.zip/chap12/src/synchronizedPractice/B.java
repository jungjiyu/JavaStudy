package synchronizedPractice;


public class B implements Runnable{
	private Calc myCalc ; 

	B(Calc myCalc){
		this.myCalc = myCalc;
	}
	
	@Override
	public void run() {
		myCalc.sum("B",-100,-100);
	}
}
