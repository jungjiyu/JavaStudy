package synchronizedPractice;

public class Activate {
	public static void main(String[] args) {
		Calc myCalc = new Calc();
		Thread tA = new Thread(new A(myCalc));
		Thread tB = new Thread(new B(myCalc));
		tA.start();
		tB.start();
	}
}
