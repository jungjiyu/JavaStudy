package interfaces;

public class ImplementedHuman implements Human{
	@Override
	public void doSomething(String task) {
		System.out.println("이 사람은 "+task+"를 수행 합니다");
	}

}
