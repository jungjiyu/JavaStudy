package interfaces;

public class Main {
	public static void main(String[] args) {
		Human human1 = new ImplementedHuman();
		human1.doSomething("컵라면 먹기");
		
		Human human2 = new Human() {
			@Override
			public void doSomething(String task) {
				System.out.println(task+"를 하는것을 때려치웠습니다");
			}
			
		};
		
		human2.doSomething("춤추기");
	}

}
