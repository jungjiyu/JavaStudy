package interfaces;

public interface Human {
	public abstract void doSomething(String task);
	public static final String name="me";
}
