package generic4;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
	ArrayList<B> bList = new ArrayList<>();
	Execute.takeParent(bList);
	for(int i = 0 ; i<bList.size();i++) {
		System.out.print(bList.get(i)+", ");
	}
	
	System.out.println();
	int[] intAry = new int[5];
	Execute.addAryElement(intAry);
	for(int i = 0 ; i<intAry.length;i++) {
		System.out.print(intAry[i]+", ");
	}
	
	}
}

class Ex{
	
}