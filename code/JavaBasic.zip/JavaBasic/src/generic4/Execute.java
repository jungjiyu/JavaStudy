package generic4;

import java.util.ArrayList;

public class Execute {
	// 반공변성 구현 >> C의 부모 타입은 모두 받을 수 있다
		// 넣기 위해 사용
	public static void takeParent(ArrayList<? super C> al) {
		al.add(new D());
		al.add(new C());
	}
	
	public static void addAryElement(int[] ary) {
		ary[0]=1;
		ary[1]=2;
		ary[2]=3;
	}
}
