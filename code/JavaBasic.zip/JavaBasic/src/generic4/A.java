package generic4;

public class A { }

class B extends A{}
class C extends B{}
class D extends C{}