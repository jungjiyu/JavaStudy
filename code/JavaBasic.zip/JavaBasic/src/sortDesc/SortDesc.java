package sortDesc;

import java.util.ArrayList;

class Box{
	int rank;
	int val;
	
	public Box(int rank , int val) {
		this.rank = rank;
		this.val = val;
	}
}

public class SortDesc {
	public static void main(String[] args) {
		ArrayList<Box> list = new ArrayList<>();
		for(int i = 0 ; i <12 ; i ++) {
			list.add(i,new Box(0,i*2));
			System.out.print(list.get(i)+" ");
		}
		System.out.println("\n---------------------------\n");
		
	
//		sortByDesc(list);
		setRank2(list);
		for( int i = 0 ; i <12 ; i ++) {
			System.out.println("("+list.get(i).rank +", "+ list.get(i).val+")");
		}

		
	}
	
	static void setRank(ArrayList<Box> list) {
		for(int i=0 ; i<list.size(); i++) {
			Box curBox = list.get(i);
			curBox.rank = 1; //일단 순위를 1로 해준다
			
			for(int j = 0 ; j <list.size(); j++) {
				if(curBox.val < list.get(j).val) {
					curBox.rank++;
				}
				}
		}
	}
	
	static void setRank2(ArrayList<Box> list) {
		
		sortByDesc(list);
		for(int i=0 ; i<list.size(); i++) {
			Box curBox = list.get(i);
			curBox.rank = i+1;
		}
	}

	

	static void sortByDesc(ArrayList<Box> list) {
		
	// sol1 : 일단 첨주터 끝까지 다	
		for(int i=0 ; i<list.size(); i++) {
			for(int j = 0 ; j <list.size()-1; j++) {
					if(list.get(j).val < list.get(j+1).val) {
						 Box tmp = list.get(j);
						 list.set(j, list.get(j+1));
						list.set(j+1, tmp);
					}
				}
			}

	// sol2 : 확정된 곳은 건들지 않는다
		for(int i=0 ; i<list.size(); i++) {
			for(int j = i ; j <list.size()-1; j++) {
				if(list.get(j).val < list.get(j+1).val) {
					 Box tmp = list.get(j);
					 list.set(j, list.get(j+1));
					list.set(j+1, tmp);
				}
				}
			}
		
		

		
	}
}
