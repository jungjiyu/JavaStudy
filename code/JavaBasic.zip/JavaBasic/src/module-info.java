/**
 * 
 */
/**
 * 
 */
module COTE {
}