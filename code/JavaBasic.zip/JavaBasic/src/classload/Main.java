package classload;

public class Main {
	public static void main(String[] args) {
		A a1 = new A(20);
		A a2 = new A(30);
	}
}
