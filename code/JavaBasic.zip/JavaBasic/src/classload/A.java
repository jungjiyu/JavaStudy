package classload;

public class A {
	int num4=-9;
	static int num1=-9;

	static {
		System.out.println("값 수정전 num1값:"+num1);
		System.out.println("static 블록 1 실행됨, num1을 1로 수정");
		num1 = 1;
	}
	
//	static int num1=-9; 


	A(int num4){
		System.out.println("-------------------------------------");
		System.out.println("num1값:"+num1);
		System.out.println("값 수정전 num4값:"+this.num4);
		System.out.println("A생성자 실행됨, num4값 "+num4+"로 수정완료");
		this.num4 = num4;

	}
	

	
	{
		System.out.println("++++++++++++++++++++++++++++++++++++++");
		System.out.println("값 수정전 num4값:"+this.num4);
		System.out.println("인스턴스 블록 1 실행됨, num4 값 4로 수정완료");
		num4=4;

	}

	static {
		System.out.println("값 수정전 num1값:"+num1);
		System.out.println("static 블록 2 실행됨, num1을 2로 수정");
		num1 = 2;
		System.out.println("\n\n");

	}
	

}
