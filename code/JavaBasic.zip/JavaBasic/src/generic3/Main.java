package generic3;

public class Main {
	public static void main(String[] args) {
		Apple apple = new Apple();
		Apple iphone11 = new Iphone11();
		Samsung samsung = new Samsung();
		Samsung galaxy24 = new Galaxy24();
		FancyDrill fancyDrill = new FancyDrill();
		NotFancyDrill notFancyDrill = new NotFancyDrill();
		
		fancyDrill.<Apple>penetrateSomething(apple);
		fancyDrill.<Apple>penetrateSomething(iphone11);
		notFancyDrill.<Apple>penetrateSomething(apple);
		
		fancyDrill.<Samsung>penetrateSomething(samsung);
		fancyDrill.<Samsung>penetrateSomething(galaxy24);
		notFancyDrill.<Samsung>penetrateSomething(samsung);
		
		
	}
}
