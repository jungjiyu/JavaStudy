package generic3;

public interface Phone<A>{
	public abstract int getStrength();
	public abstract A getKind();
	public abstract void callAI();
	
}

class Apple implements Phone<Apple>{
	int strength=4;
	static Apple kind = new Apple();
	public Apple() {}
	
	
	@Override
	public int getStrength() {
		return strength;
	}
	
	
	@Override
	public Apple getKind() {
		return kind;
	}
	
	@Override
	public void callAI() { // Samsung 과 차별성을 가지는 메서드
		System.out.println("siri: 무엇을 도와드릴까요");
	}

}

class Iphone11 extends Apple{
	
}

class Samsung implements Phone<Samsung>{
	int strength=7;
	static Samsung kind = new Samsung();
	
	public Samsung() {}
	
	
	@Override
	public int getStrength() {
		return strength;
	}
	

	@Override
	public Samsung getKind() {
		return kind;
	}

	
	@Override
	public void callAI() { // apple 과 차별성을 가지는 메서드
		System.out.println("bixby: 무엇을 도와드릴까요");		
	}

}

class Galaxy24 extends Samsung{
	
}
