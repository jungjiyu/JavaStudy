package generic3;

public interface Drill {
	
	public <T> void penetrateSomething(Phone<? extends T> something) ;
	
	
	public <T> void penetrateFail(Phone<? extends T> something);
	
	public <A> void penetrateSuccess(Phone<? extends A> something);
}

class FancyDrill implements Drill { // phone 이란 phone 은 죄다 뚫어버림
	private int drillStrength = 10;
	
	@Override
	public <T> void penetrateSomething(Phone<? extends T> something) {
		System.out.println(something.getClass().getSimpleName()+"뚫기를 시도합니다~");
		if(something.getStrength() >= drillStrength ) {
			penetrateFail(something);
		}
		else {
			penetrateSuccess(something);
		}

	}
	
	@Override
	public <T> void penetrateFail(Phone<? extends T> something) { // samsung 이하만 가능 (튼튼해서)
		
		System.out.println("Fancy drill 이"+something.getClass().getSimpleName()+"을 뚫기를 실패했습니다!");

	}
	
	
	@Override
	public <A> void penetrateSuccess(Phone<? extends A> something) {
		System.out.println("fancy drill 이 "+something.getClass().getSimpleName()+"을 모조리 뚫어버렸습니다!");
	}

	public int getDrillStrength() {
		return drillStrength;
	}

	public void setDrillStrength(int drillStrength) {
		this.drillStrength = drillStrength;
	}

}

class NotFancyDrill implements Drill {
	private int drillStrength = 5;
	
	@Override
	public <T> void penetrateSomething(Phone<? extends T> something ) {
		System.out.println(something.getClass().getSimpleName()+"뚫기를 시도합니다~");
		if(something.getStrength() >= drillStrength ) {
			penetrateFail(something);
		}
		else {
			penetrateSuccess(something);
		}

	}
	
	@Override
	public <T> void penetrateFail(Phone<? extends T> something) { // samsung 이하만 가능 (튼튼해서)
		
		System.out.println("NotFancydrill 이"+something.getClass().getSimpleName()+"을 뚫기를 실패했습니다!");

	}
	
	
	@Override
	public <A> void penetrateSuccess(Phone<? extends A> something) {
		System.out.println("NotFancydrill 이 "+something.getClass().getSimpleName()+"을 모조리 뚫어버렸습니다!");
	}

	public int getDrillStrength() {
		return drillStrength;
	}

	public void setDrillStrength(int drillStrength) {
		this.drillStrength = drillStrength;
	}
}

