package anonymous;

public interface Human {
	public static final String heart="심장";
	int age=19;
	//https://honbabzone.com/java/java-interface/
	

}
