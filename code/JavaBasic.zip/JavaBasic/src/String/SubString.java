package String;

public class SubString {
	public static void main(String args[]) {
		String str1= "you are a SpongeBob";
		String subStr1= str1.substring(10); // 이상 미만
		String subStr2= str1.substring(10,19); // 이상 미만
		System.out.println(subStr1+", "+subStr2);
		
	}
}
