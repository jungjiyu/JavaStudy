package Generic2;

public class Applicant<T> { // 참가자의 info. T에는 Person 의 자식 클래스 중 하나가 들어가게 될꺼임
	public T kind;
	
	public Applicant(T kind) { // 객체의 타입을 저장하는 용도
		this.kind = kind;
	}
}
