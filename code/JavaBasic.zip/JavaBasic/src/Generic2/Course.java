package Generic2;

public class Course { // 참가자들의 자격에 따라 참여 가능한 코스 들
	
	//신청하기만 하면 참여 가능
	public static void registerCourse1(Applicant<?> applicant) {
		System.out.println(applicant.kind.getClass().getSimpleName()+"이 Course1 등록함");
//		applicant.kind.getClass().getSimpleName() >> kind 필드에 저장된 객체를 대상으로 Class 객체가 만들어지고, 이 객체에서 해당 객체의 정보를 추출
	}
	
	// Student, Student 의 자식 클래스만 가능
	public static void registerCourse2(Applicant<? extends Student> applicant) {
		System.out.println(applicant.kind.getClass().getSimpleName()+"이 Course2-학생코스 등록함");
	}
	
// worker 혹은 일반인만 가능
	public static void registerCourse3(Applicant<? super Worker> applicant) {
		System.out.println(applicant.kind.getClass().getSimpleName()+"이 Course3-직장인&일반인코스 등록함");
	}

}
