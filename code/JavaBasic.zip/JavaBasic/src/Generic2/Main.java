package Generic2;

public class Main {
	public static void main(String[] args) {
	Course.registerCourse1(new Applicant<Person>(new Person()));
	Course.registerCourse1(new Applicant<Student>(new Student()));
	Course.registerCourse1(new Applicant<Worker>(new Worker()));
	Course.registerCourse2(new Applicant<Student>(new Student()));
	Course.registerCourse2(new Applicant<MiddleStudent>(new MiddleStudent()));
	Course.registerCourse3(new Applicant<Worker>(new Worker()));

	}
}
