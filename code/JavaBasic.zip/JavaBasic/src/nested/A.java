package nested;

public class A {
	B b =null;
	C c =null;
	int numA=0;
	

	A(){
		numA = (int)(Math.random()*100) + 1;
		System.out.println("A생성자 실행됨, 현재 객체의 랜덤필드값:"+numA);
		
		b = new B(20);//		A.B bb = this.new B(20); 
		
		
		c = new C(100);
		A.C cc = new A.C(10);

	}
	
	public void doSomething() {
		b.sayB();
		b.useQualifiedThis();
		System.out.println("인스턴스 inner 클래스에 의해 수정된 A객체의 랜덤필드값:"+numA);

		
		c.sayC();
	}
	
	public void useLocalClass(int num) {
		int num2 = num+100;
		
		class D{
			D(){
				System.out.println("클래스D의 생성자 실행됨");
			}
			
			public void sayD() { // JDK 17 이상부턴 static 허용 되는데 나는 JDK11 이라 안된다
				System.out.println("D");
			}
			
			public void shoutOutLocalVar() {
				System.out.println("local클레스에서 접근한 로컬 변수는:"+num+", "+num2);
				System.out.println("local클레스에서 접근한 outer 인스턴스 변수는:"+numA+"이고, 100 을 추가할 예정");
			//	num2 -=100; 수정 불가 하다
				numA +=100;
				
			}
			
		}
		
		D d = new D();
		d.sayD();
		d.shoutOutLocalVar();
	}
	
	class B{ // 인스턴스 inner 클래스
		int num = 0;
		B(int b){
			System.out.println("B생성자 실행됨");
			num = b;
		}

		public void sayB() {
			System.out.println("B"+num);
		}
		
		public void useQualifiedThis() {
			System.out.println("inner 클래스에서 접근한 외부 클래스 객체의 필드값"+A.this.numA+", 여기서 -100 할 예정");
			A.this.numA -=100;
		
		}
	}
	
	static class C{
		int num = 0;
		C(int c){
			System.out.println("C생성자 실행됨");
			num = c;
		}

		public void sayC() {
			System.out.println("C"+num);
		}

	}
	
	
	interface InYourFace{
		
		public abstract void ImYourFace();
		
		default void smile() {
			
			System.out.println(":_)");
		}
		static void fuckYou() {
			System.out.println("fuck you");
		}
	}
	
	static interface StaticInYourFace{
		
		public abstract void ImYourFace();
		
		default void cry() {
			
			System.out.println(":-(");
		}
		static void fuckMe() {
			System.out.println("fuck me");
		}
	}

	

}
