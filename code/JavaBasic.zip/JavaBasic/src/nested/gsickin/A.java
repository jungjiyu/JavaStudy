package nested.gsickin;


public class A {
	B b =null; int numA=0;
	A(){
		numA = (int)(Math.random()*100) + 1;
		b = new B(20);
	}
	public void doSomething() {
		System.out.println("A생성자 실행됨, 초기 numA값:"+numA);
		b.useQualifiedThis();
		System.out.println("인스턴스 inner 클래스에 의해 수정된  인스턴스 필드의 값:"+numA);
		useLocalClass(10);
		System.out.println("로컬 클래스에 의해 수정된 인스턴스 필드의 값: "+numA);
	}
	public void useLocalClass(int num) { 
		class D{
			public void yayLocalVar() {
				System.out.println("local클레스에서 접근한 로컬 변수는:"+num); //	num -=100;불가
			}
			public void yayInstanceField() {
				System.out.println("local클레스에서 접근한 outer 인스턴스 변수는:"+numA+"이고, 100 을 추가할 예정");
				numA +=100; // 인스턴스 필드값 수정까지 가능
			}	}
		D d = new D(); d.yayLocalVar(); d.yayInstanceField();
	}
	
	class B{ // 인스턴스 inner 클래스
		int num = 0;
		B(int b){ num = b; }
		
	public void useQualifiedThis() {
			System.out.println("인스턴스 inner 클래스에서 접근한 outer 클래스 객체의 필드값: "+A.this.numA+", 여기서 -100 할 예정");
			A.this.numA -=100;
		
		} } }
