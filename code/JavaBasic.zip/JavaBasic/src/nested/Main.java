package nested;

class E  implements A.InYourFace{
	@Override
	public void ImYourFace(){
		System.out.println("ლ(●ↀωↀ●)ლ");
	}
}
public class Main {
	public static void main(String[] args) {
	
//		InYourFace iyf = new InYourFace() {};
//		InYourFace.fuckYou();
//		iyf.smile();
		
		A a = new A();
		a.doSomething();
		
		A.B b = new A().new B(1);
		b.sayB();


		
		A.C c = new A.C(100);
		c.sayC();
		
		a.useLocalClass(190);
		System.out.println("수정된 인스턴스 필드의 값: "+a.numA);
	
		A.StaticInYourFace siyf = new A.StaticInYourFace() {
			
			@Override
			public void ImYourFace() {
				System.out.println("ᶘ ͡°ᴥ͡°ᶅ");
			}
		};
		
		siyf.ImYourFace();
		
		E e = new E();
		e.ImYourFace();
		
		
	}

}
