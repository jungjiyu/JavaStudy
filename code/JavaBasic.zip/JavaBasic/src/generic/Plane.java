package generic;
import java.util.ArrayList;

public class Plane<T,A> implements Rent<T>{
	private static int count = 0;
	private T something = null;
	private A name = null;
	
	Plane(){
		System.out.println(count+"번째 plane 객체 생성됨");
	}
	
	public void setSomething(T something) {
		this.something = something;
	}
	
	public T getSomething(){
		return something; 
	}
	
	public void setPlaneName(A name) {
		this.name= name;
			
	}
	
	public A getPlaneName() {
		if(name != null) System.out.println("이 비행기의 이름은" +name+"입니다");
		return name;
	}

	
	@Override
	public T rent() {
		System.out.println(something+"을 랜트하셨습니다.");
		return something;
	}
	
	
	
	public static <A> A load(A box) {
		System.out.println(box.toString()+"을 비행기에 실었습니다");
		return box;
		
	}
	
	public static <A> Car<A> loadCar(Car<A> car) { // 만약에 parameter 부분에 type parameter 가 없어도 유추를 할 수 있을까
		System.out.println(car.toString()+"을 비행기에 실었습니다");
		return car;
	}
	
	public static <A> void foo() {
		System.out.println("fooooooooooo");
	}
	
}
