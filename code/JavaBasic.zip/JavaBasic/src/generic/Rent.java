package generic;

public interface Rent<T> {
	public abstract T rent();  

}
