package generic;

public class RentalShop {
	
	public RentalShop() {
		System.out.println("rental shop 객체 생성됨");
	}
	public <T extends Rent<T>> void rent(T t) {
		System.out.println("~~렌탈샵~~");
		t.rent(); // Rent 의 하위 클래스의 공통적인 메서드인 rent( ) 를 실행한다.
	}

}
