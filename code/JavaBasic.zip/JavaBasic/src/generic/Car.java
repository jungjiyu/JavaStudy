package generic;

public class Car<T> implements Rent<Car>{ 
	private String vehicle = "자동차";
	private T gift =null;
	
	Car(String vehicle){ // 일단 생성자 자체에는 제너릭 타입 못쓰는 것 같다
		this.vehicle = vehicle; 
		System.out.println(vehicle+"이 생산되었습니다");
	}
	
	public T donateGiftBox(T t) {
		gift=t;
		System.out.println(t.toString()+"를 기부하셨습니다");
		return t;
	}
	
	public T pickGiftBox() {
		if(gift != null) {
			System.out.println(gift.toString()+"를 획득하셨습니다");
		}
		else {System.out.println("선물이 없습니다");}
		return gift;
	}
	
	@Override
	public Car rent() { // 일단 Rent 를 구현한다고 하는 선언붕에 Integer 타입으로 명시를 해놨기 때문에 , 인터페이스의 T 부분은 모두 Integer 이여야됨
		System.out.println(vehicle+"을 대여하셨습니다");
		return this;
	}
	
	public String getVehicle() {
		return vehicle;
	}
	
	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}

}
