package generic;

public class Main{
	public static void main(String[] args) {
		Car<String> ferrari = new Car<>("ferrari");
		Car<String> porsche = new Car<>("porsche");
		ferrari.rent();
		porsche.rent();
		
		ferrari.donateGiftBox("우비");
		String thing = porsche.pickGiftBox();
		System.out.println(thing);
		
		Plane<String,Integer> plane = new Plane();
		plane.setSomething("비행기 이륙 준비");
		plane.setPlaneName(1929482);
		Integer name = plane.getPlaneName();
		System.out.println("받은 비행기의 이름: "+name);
		Plane.load("짜장면"); // 와 개편히네
		Plane.<String>load("탕수육");
		
		Plane.foo();
		
		Rent<String> rent = new Rent<>() {
			@Override
			public String rent() {
				return "hehehehe";
			}
		};
		
		Rent<Car> carRent = ferrari; 
		Rent carRent2 = ferrari; // 이게 왜 됨 
		
		Rent planeRent = plane;
		System.out.println(rent instanceof Rent);
		System.out.println(ferrari instanceof Car);
		System.out.println(ferrari instanceof Rent);
		
		RentalShop rentalShop = new RentalShop();
		rentalShop.rent(porsche);
	//	rentalShop.rent(plane);
		
	}
}
