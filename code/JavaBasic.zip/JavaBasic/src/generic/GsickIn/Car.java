package generic.GsickIn;

public class Car<T> implements Rent<Car>{ 
	private String vehicle = "자동차";
	private T gift =null;
	
	Car(String vehicle){ 
		this.vehicle = vehicle; 
	}
	
	
	@Override
	public Car rent() { // 일단 Rent 를 구현한다고 하는 선언붕에 Integer 타입으로 명시를 해놨기 때문에 , 인터페이스의 T 부분은 모두 Integer 이여야됨
		System.out.println(vehicle+"을 렌트하셨습니다");
		return this;
	}
	
	public String getVehicle() {
		return vehicle;
	}
	
	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}

}
