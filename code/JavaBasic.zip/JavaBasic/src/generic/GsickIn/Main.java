package generic.GsickIn;

public class Main{
	public static void main(String[] args) {
		Car<String> ferrari = new Car<>("ferrari");
		
		Plane<Integer,String> plane = new Plane(18284);
		plane.loadSomething("짜장면"); 
		
	
		RentalShop rentalShop = new RentalShop();
		rentalShop.renting(ferrari);
		rentalShop.renting(plane);
		
		
	}
}
