package generic.GsickIn;

public class RentalShop {
	
	public <T extends Rent> void renting(T t) { // 아예 꺾쇄 자체를 쓰지 않은 경우 object 넣은걸로 간주된다.
		System.out.print("렌탈샵>>");
		t.rent(); 
	}
	
	public <T, A extends Rent<T>> void renting2(A a) { // <A extends Rent<T>> 라고 하면 안된다
		System.out.print("렌탈샵>>");
		a.rent(); 
	}

}
