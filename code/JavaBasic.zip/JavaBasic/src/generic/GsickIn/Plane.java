package generic.GsickIn;

public class Plane<T,A> implements Rent<T>{
	private A something = null;
	private T vehicle  = null;
	
	Plane(T vehicle ){
		this.vehicle  = vehicle ;
		System.out.println("비행기"+vehicle+"가 생산되었습니다");
	}
	

	

	@Override
	public T rent() {
		System.out.println(vehicle +"을 랜트하셨습니다.");
		return vehicle;
	}
	
	
	public void loadSomething(A something) {
		this.something = something;
		System.out.println(something.toString() +"을 비행기"+vehicle+"에 실었습니다");
	}
	
	public A unloadSomething() {
		return something;
	}

}
