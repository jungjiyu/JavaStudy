package generic.GsickIn;

public interface Rent<T> {
	public abstract T rent();  

}
