package copy.generic;
import java.util.ArrayList;
public class Main {
	public static void main(String[] args) {
		
		// 공변성 구현이 안되는건 제네릭 타입끼리 (ArrayList<B> <--> ArrayList<A>) 안되는 거지, 한 제네릭 타입에서 다양한 자식 element 를 받지 못한다는 말이 아니다.
		ArrayList<A> list = new ArrayList<A>();
		list.add(new A());
		list.add(new B());
		list.add(new C());
		list.add(new D());
		list.add(new E());
		
		printElement(list); 

		
		Execute.insertElement(list); // ArrayList<C> 가 아닌 ArrayList<A> 를 받은 것 주의
		printElement(list);
		
		
	}
	
	public static void printElement(ArrayList<? extends A> list) {
		System.out.println("----start PE-------");
		for(int i = 0 ; i < list.size() ; i++) {
		// 다형성 구현	
			// 부모 클래스로 받았다고 해당 객체가 부모 클래스타입으로 바뀌는게 아니라 부모 클래스에만 있는 멤버로 사용이 제한되는거다
			// 다형성을 구현하는 경우 레퍼런스 객체의 타입(부모 클래스) 에서 우선적으로 해당 멤버를 찾는게 아니라 생성자 로 생성된 실제 객체의 타입(클래스) 에서 우선적으로 찾아본다 
			A emt = list.get(i);
			emt.sayHi();
		}
		System.out.println("----end PE-------");

	}
}
