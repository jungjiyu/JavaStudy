package copy.generic;

public interface HeyBitch {
	public abstract void sayHi();

}
