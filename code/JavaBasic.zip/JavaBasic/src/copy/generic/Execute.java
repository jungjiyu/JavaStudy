package copy.generic;
import java.util.ArrayList;

public class Execute {
	
	// 반 공변성 구현 >> 삽입
		// 삽입하고 싶은 대상을 super 뒤에 쓴다 >> 와일드 카드는 그 클래스 이상이므로 무조건 그 클래스 이하의 객체를 받을 수 있다
	public static void insertElement(ArrayList<? super C> list) {
		int size = list.size();
		list = new ArrayList<C>(); // 기존껀 버린다

		for(int i = 0 ; i < size ;i++) { // 그냥 list.size( ) 박아버리면 안된다. 지금 list = [ ] 상태라 0 이다.
			list.add(new D());	
		}
	
		System.out.println("-------from Execute:-----");
		
		for(int i = 0 ; i <list.size();i++) {
			A a = (A)list.get(i);
			a.sayHi();
			
		}
//		Main.printElement(list);
	}

	//공변성 구현 >> 추출
		//내부에서 아무거나 다 받는 부모 타입으로써 사용하고 싶은 얘를 extends 뒤에다 쓴다.
	public ArrayList<C> extractElement(ArrayList<? extends C> list) {
		ArrayList<C> newList = new ArrayList<C>();
		
		for(int i = 0 ; i <list.size();i++) {
			newList.add(list.get(i));
		}
		return newList;
	}
}
