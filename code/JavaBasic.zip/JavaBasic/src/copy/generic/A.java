package copy.generic;

public class A implements HeyBitch{
	public static void aIm() {
		System.out.println("im A");
	}

	
	@Override
	public void sayHi() {
		System.out.println("hey A");
	}
}

class B extends A{
	@Override
	public void sayHi() {
		System.out.println("hey B");
	}
	
}		

class E extends A{
	@Override
	public void sayHi() {
		System.out.println("hey E");
	}

}

class C extends B{
	public static void imC() {
		System.out.println("im C");
	}
		@Override
		public void sayHi() {
			System.out.println("hey C");
		}

}
class D extends C{
	@Override
	public void sayHi() {
		System.out.println("hey D");
	}
}

