package ARRAY;

public class EX1 {
	public static void main(String args[]) {
		
	// ary 를 만드는 3가지 방법
		// 사이즈로만 초기화
		int[] intAry1 = new int[3];
		printAry(intAry1);
		

		
		// 요소와 함께 초기화
		int[] intAry2 = {1,2,3};
		printAry(intAry2);

		// 요소+ 대괄호와 함께 초기화
		int[] intAry3 = new int[]{4,5,6};
		printAry(intAry3);
		System.out.print("변경후:");
		changeAry(intAry3);
		printAry(intAry3);

		
		
	// 2차원 배열 연습	
		int[][] twoDemAry1 = new int[3][3];
		
		int n = 1;
		for(int i = 0 ; i <twoDemAry1.length;i++) { // 행의 개수
			for(int j = 0 ; j< twoDemAry1[i].length ; j++) {
				twoDemAry1[i][j] = n++;
			}
		}
		
		printTwoDemAry(twoDemAry1);
		
		
		int[][] twoDemAry2 = new int[3][3];

		 n = 9;
		for(int i = 0 ; i <twoDemAry2.length;i++) { // 행의 개수
				for(int j = 0 ; j< twoDemAry2[i].length ; j++) {
					twoDemAry2[i][j] = n--;
				}
		}
		System.out.println();
		printTwoDemAry(twoDemAry2);

		
		//2차원 배열 2개 합치기
		
				
		
		
		int [][] twoDemAry3 = new int[3][3];
		for(int i = 0 ; i <twoDemAry3.length;i++) { // 행의 개수
			for(int j = 0 ; j< twoDemAry3[i].length ; j++) {
				twoDemAry3[i][j] = twoDemAry1[i][j] +  twoDemAry2[i][j] ;
			}
	}
		System.out.println();		
		printTwoDemAry(twoDemAry3);
		
		
	// 가변길이 배열	
		int [][] twoDemAry4 = new int[3][];
		twoDemAry4[0] = new int[3];
		twoDemAry4[1] = new int[5];
		twoDemAry4[2] = new int[2];

		for(int i = 0 ; i< twoDemAry4.length ; i++) {
			for(int j=0; j <twoDemAry4[i].length;j++) {
				twoDemAry4[i][j] = i;
			}
		}
		System.out.println();		
		printTwoDemAry(twoDemAry4);
		System.out.println();		

		
	
		// random 연습 : 1~10 의 랜덤한 숫자
		for(int i = 0 ; i <20;i++) {
			int nn = (int)(Math.random()*10) +1;
			System.out.print(nn+" ");
		}
		
		
		System.out.println();
	// 각 자릿수를 분리하여 구하기
		int num2 = 39495;
		while(num2 != 0) { 
			
			int tmp =num2%10;
			num2/=10;
			System.out.println(tmp);
		}
		
		int nnn = (int)Math.pow(10, 2);
		System.out.println(nnn);
		int num3 = 10202;
		int num4=0;
		int count=0;
		while(num3 !=0) {
			int tmp = num3%10;
			num3/=10;
			System.out.println(tmp);
			num4 += tmp*(Math.pow(10, count++));
		}
		System.out.println("num4="+num4);
	}
	
	public static void printAry(int[] ary) {
		for(int i = 0; i <ary.length;i++) {
			System.out.print(ary[i]);
		}
		System.out.println("\n");
		
	}
	
	public static void printTwoDemAry(int[][] ary) {
		for(int i = 0 ; i <ary.length;i++) { // 행의 개수
			for(int j = 0 ; j< ary[i].length ; j++) {
				System.out.print(ary[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public static void changeAry(int[] ary) {
		ary[0] = -999;
		
	}
	
}
