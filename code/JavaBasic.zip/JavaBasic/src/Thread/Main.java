package Thread;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		String s = scanner.nextLine();
		System.out.println(s);
		
		Thread aANDb = new Thread(new AandB());
		aANDb.start();
		
		Thread[] threads = new Thread[5];
		for(int i =0;i<threads.length;i++) {
			threads[i] = new Thread( new HiAble((char)('A'+i)) );
		}
		
		// 순서대로 실행이 안된다
		for(int i =0;i<threads.length;i++) {
			threads[i].start();
		}
		
		
		
		try {
			for(int i =0;i<threads.length;i++) {
				threads[i].join();
			}
		}catch(Exception e) {e.printStackTrace();}

		
		System.out.println("mainthread 종료");
		
		
	}

}
