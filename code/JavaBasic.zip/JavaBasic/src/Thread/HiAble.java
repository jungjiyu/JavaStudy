package Thread;

public class HiAble implements Runnable{
	public char name;
	public HiAble(char name) {
		System.out.println("("+name+")HiAble 생성자 실행됨");
		this.name = name;
	}
	@Override
	public void run() {
		System.out.println("("+name+")안녕하세요");
		
	}

}
