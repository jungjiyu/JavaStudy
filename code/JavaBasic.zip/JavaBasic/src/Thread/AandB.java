package Thread;

public class AandB  implements Runnable{
	
	public void sayA() {
		System.out.println("A");
	}
	
	public void sayB() {
		System.out.println("B");
		try {
			Thread.sleep(500);
		}catch(Exception e) {e.printStackTrace();}

	}
	
	@Override
	public void run() {
		sayA();
		sayB();
		sayA();
		sayB();

		sayA();
		sayB();

		sayA();
		sayB();

	}
}
