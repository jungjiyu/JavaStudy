package Thread;



class SharedOBJ {
	  private int seq=0; 
	  public synchronized void mthdA(int i) { 
	    // System.out.println("a1-while 문 이전"); 
	    while(seq != 0 && seq != 3) { 
	      // System.out.println("a2 - while 문 내부"); 
	      wakeUp(); 
	      try { 
	        wait(); 
	        }catch(InterruptedException e) {} 
	     } 
	     // System.out.println("a3 - while 문 다음"); 
	     System.out.print("ThreadA :"+i); 
	     seq++; 
	     if(seq >=4) seq =0; 
	  } 
	  public synchronized void mthdB(int i) { 
	    // System.out.println("b1 - while 문 이전"); 
	    while(seq != 1 && seq != 2 ) { 
	      // System.out.println("b2 - while 문 내부"); 
	      wakeUp(); 
	      try { 
	        wait(); 
	        }catch(InterruptedException e) {} 
	     } 
	     // System.out.println("b3 - while 문 다음"); 
	     System.out.print("ThreadB :"+i); 
	     seq++; 
	  } 
	  public synchronized void wakeUp() { 
	    notifyAll(); 
	 } 
	} 
	


class A implements Runnable{ 
	 private SharedOBJ sOBJ; 
	  A(SharedOBJ obj){ 
	    sOBJ = obj; 
	 } 
	 @Override 
	 public void run() { 
	   for(int i = 1 ; i <=3 ;i++) { 
	     sOBJ.mthdA(i); 
	     System.out.print("\t"); 
	     sOBJ.mthdA(i); 
	     System.out.println(); 
	  } 
	  // System.out.println("Thread A 종료"); 
	  sOBJ.wakeUp(); 
	} 
	} 
	class B implements Runnable{ 
	  private SharedOBJ sOBJ; 
	  B(SharedOBJ obj){ 
	    sOBJ = obj; 
	 } 
	 @Override 
	 public void run() { 
	   for(int i = 1 ; i <=3 ;i++) { 
	     sOBJ.mthdB(i); 
	     System.out.println(); 
	     sOBJ.mthdB(i); 
	     System.out.print("\t"); 
	  } 
	  sOBJ.wakeUp(); 
	  // System.out.println("Thread B 종료"); 
	} 
	} 
	
	public class Practice { 
		  public static void main(String[] args) { 
		    SharedOBJ sobj = new SharedOBJ(); 
		    Thread ta = new Thread(new A(sobj)); 
		    Thread tb = new Thread(new B(sobj)); 
		    ta.start(); 
		    tb.start(); 
		    try{ 
		      ta.join(); 
		      tb.join(); 
		      }catch(Exception e) {} 
		      // System.out.println("main thread ended"); 
		   } 
	}


