package chap03;

import java.util.Arrays;
import java.util.List;

import java.util.function.Consumer;

import java.util.function.Function;

public class Main {
	
	public void print(String msg) {
		System.out.println(msg);
	}
	Main(){}
	
	Main(String str){
		System.out.println(str);
	}
	
	public static void main(String[] args) {
		// array 를 리스트로 변환
		List<String> words = Arrays.asList("apple","banana","orange");

		// forEach >> 괄 호 안의 동작을 반복해 수해하게 함
		words.forEach(word -> System.out.println(word)); // println == 정적메서드
		
		// 정적 메서드 참조하는 법
			// ㅡㄹ래스명::정적메서드명
		words.forEach(System.out::println);
		
		
		
		Main ins = new Main();
		Consumer<String> str1 = msg -> ins.print(msg);
		str1.accept("hello");
		
		// 인스턴스 메서드 참조하는 법
			//객체참조변수명::인스턴스메서드명
		Consumer<String> mthdRefer = ins::print;
		mthdRefer.accept("hello");
		
		
		Function<String, Main> lamdaConst = msg -> new Main(msg);
		lamdaConst.apply("hell from heell");
		
		
		//생성자 참조하는 법
			// 클래스명::new
		Function<String,Main> constRefer = Main::new;
		constRefer.apply("hell to hell");
		
	}
}
