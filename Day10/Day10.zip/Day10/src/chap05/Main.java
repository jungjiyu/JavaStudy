package chap05;

import java.util.Arrays; // 배열을 스트림으로 생성해주는 기능

public class Main {
	public static void main(String[] args) {
		int []ary1 = new int[5];
		
		for(int i = 0 ; i <ary1.length ; i++) {
			ary1[i] = i+1;
			System.out.print(ary1[i]+"\t");
		}
		System.out.println();
		
		for(int i : ary1) {
			System.out.print(i+"\t");
		}
		System.out.println();

		
		//Arrays stream 생성후 forEach 메서드 활용
		Arrays.stream(ary1);
		Arrays.stream(ary1).forEach(i-> System.out.print(i+"\t"));
		System.out.println();

		
		
		String[] ary2 = {"ape","bannana","tomato","fizzi"};
		for(int i =0;i<ary2.length;i++) {
			if(ary2[i].length()>=5)System.out.println(ary2[i]);
		}
		
		for(String fruit : ary2) {
			if(fruit.length()>=5)System.out.println(fruit);
		}
		
		Arrays.stream(ary2).filter(str->str.length() >=5).forEach(System.out::println);
		
		
		
		
		
	}
}
