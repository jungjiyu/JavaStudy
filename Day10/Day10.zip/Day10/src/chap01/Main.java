package chap01;

import java.util.function.*;


public class Main {
	public static void main(String[] args) {
		// Function의 합성2
		Function<Integer,Integer> func1 = x ->x+1;  
		Function<Integer,Integer> func2 = x ->x*2;
		Function<Integer,Integer> func3 = func1.compose(func2);
		int result = func3.apply(3);
		System.out.println(result);
		
		//Predicate 의 결합 3가지
		Predicate<Integer> isEven = (i) -> i%2==0;
		Predicate<Integer> isPositive = (i) -> i>=0;
		Predicate<Integer> isEvenAndPositive = isEven.and(isPositive);
		Predicate<Integer> isEvenOrPositive = isEven.or(isPositive);
		Predicate<Integer> isNotEven = isEven.negate();
		boolean result2 = isEvenAndPositive.test(6);
		System.out.println(result2);
		result2 = isEvenOrPositive.test(6);
		System.out.println(result2);
		result2 = isNotEven.test(6);
		System.out.println(result2);
		
		
		
		
	}
}
