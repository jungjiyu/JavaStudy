package chap04;

import java.util.function.*;

@FunctionalInterface
interface Maxable{
	public int max(int a,int b);
}

@FunctionalInterface
interface Info{
	public void printVar(String name,int age);
}

@FunctionalInterface
interface Squareable{
	public int square(int x);
}

@FunctionalInterface
interface Rollable{
	public int roll();
}

@FunctionalInterface
interface SumAryable{
	public int sumArr(int [] arr);
}

public class Main {
	public static void main(String[] args) {
		int intResult;
		boolean booleanResult;
		
		Maxable m1 = (a,b) -> a>b?a:b;
		intResult = m1.max(10,20);
		System.out.println(intResult);
		
		
		Info i1 = (s,i) -> System.out.println("이름:"+s+"\n나이"+i);
		i1.printVar("정지유", 10);
		
		Squareable s1 = x->{return x*x;};
		intResult = s1.square(10);
		System.out.println(intResult);
		
		Rollable r1 = ()-> (int)(Math.random()*6);
		intResult = r1.roll();
		System.out.println(intResult);
		
		
		SumAryable sa1 = (ar) -> {
			int sum = 0;
			for(int i: ar)
				sum+=i;
			return sum;
		};
		int[] ary = {1,2,3,4,5,6,7,8,9,10};
		intResult = sa1.sumArr(ary);
		System.out.println(intResult);
		
		
		Function<Integer,Integer> func1 = i -> i*i; 
		Function<Integer,Integer> func2 = i->i*2;
		Function<Integer,Integer> func3 = func1.andThen(func2);
		intResult =func3.apply(10);
		System.out.println(intResult);
		
		Predicate<Integer> pred1 = i-> i>10;
		Predicate<Integer> pred2 = i-> i%2==0;
		Predicate<Integer> pred3 = pred1.and(pred2);
		
		booleanResult = pred3.test(12);
		System.out.println(booleanResult);
		
	
	
	}

}
