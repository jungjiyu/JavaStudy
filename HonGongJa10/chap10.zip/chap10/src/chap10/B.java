package chap10;

public class B extends A {
	B(){
		System.out.println("'.'");
	}
}
