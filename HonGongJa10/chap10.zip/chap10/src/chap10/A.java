package chap10;

public class A {
	A(){
		System.out.println("hoiyaaa");
	}

}
