package chap10;

public class C extends A {
	C(){
		System.out.println("'~'");
	}

}
