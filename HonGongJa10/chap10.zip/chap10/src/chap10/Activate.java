package chap10;



public class Activate{
    public static void main(String[] args) {
    	
    //NullPointerException
    	/*
    	String str = null ;
    	System.out.println(str.equals("fuck"));
       */
    	
    //ArrayIndexOutOfBoundsException
    	/*
    	char[] ary = new char[9];
    	for(int i = 0 ; i<11;i ++) {
    		System.out.println(ary[i]);
    	}
    	*/
    	
    // NumberFormatExcption
    	/*
    	String str1 = "yiyi";
    	int num = Integer.parseInt(str1);
    	System.out.println(num); */
    	
    // ClassCastExcption
    /*	
    	A b = new B();
    	C c = (C)b;
   */	
    	
    	
    // 다중 catch 블럭	
    	try {
    		String str = null;
    		System.out.println(str.equals("d"));
    		A b = new B();
        	C c = (C)b;
    	}catch(ClassCastException e) {
    		System.out.println ("~올바르지 못한 강제 형변환~");
    	}catch(NullPointerException e) {
    		System.out.println("~레퍼런스 변수값이 null 입니다~");
    	}finally {
    		System.out.println("~finally 문~");
    	}
    	
    	

    	try {
    	uu();
    	}catch(ClassCastException e) { // 떠넘긴 예외를 처리한다
    		System.out.println ("~올바르지 못한 강제 형변환~");
    	}
    	
    	
    	
    	
    }
    
    public static void uu() throws ClassCastException{ // 예외처리를 호출된 곳으로 떠넘긴다

    		A b  = new B();
    		C c = (C)b;
    	
    }
  
      	
    }

