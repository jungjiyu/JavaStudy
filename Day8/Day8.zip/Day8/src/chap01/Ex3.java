package chap01;



class A implements Runnable{

	@Override
	public void run(){
		for(int i = 1 ; i <=3;i++) {
			System.out.println("Thread:"+i);
			
		}
	}
}

public class Ex3 {
	public static void main(String[] args) {
		
			Thread t= new Thread(new A());
			t.start();
			
		
	}

}
