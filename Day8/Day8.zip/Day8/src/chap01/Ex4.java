package chap01;

class WorkObject3 {
	
	WorkObject3(){
	}
	
	synchronized void methodA(int i) {
		System.out.print("ThreadA:"+i+"\t");
		notify();
		try {
			wait(); // 휴식상태
		}catch(InterruptedException  e) {
			
		}
//		System.out.print("ThreadA:"+i+"ends\t");
		
	}
	
	synchronized void methodA2(int i) {
		System.out.println("ThreadA2:"+i);
		notify();
		try {
			wait(); // 휴식상태
		}catch(InterruptedException  e) {
			
		}
	//	System.out.println("ThreadA2:"+i+"ends");

	}
	
	synchronized void methodB(int i) {
		System.out.println("ThreadB:"+i);
		notify(); // A깨운다
		try {
			wait(); // 휴식상태로 들어간다
		}catch(InterruptedException e) {
			
		}
	//	System.out.println("ThreadB:"+i+"ends");

	}
	
	synchronized void methodB2(int i) {
		System.out.print("ThreadB2:"+i+"\t");
		notify(); // A깨운다
		try {
			wait(); // 휴식상태로 들어간다
		}catch(InterruptedException e) {
			
		}
	//	System.out.print("ThreadB2:"+i+"ends\t");

	}
	
	public synchronized void notifyMainThread() {
		notify();
	}
	
	
}

class A11 implements Runnable{
	WorkObject3 wobj;
	A11(WorkObject3 wobj){
		this.wobj = wobj;
	}
	@Override
	public void run(){
		for(int i = 1 ; i <=3 ; i++) {
			
			wobj.methodA(i);
			wobj.methodB2(i);

		}
		
		wobj.notifyMainThread();
	}
}

class B11 implements Runnable{
	int index;
	WorkObject3 wobj;

	B11(WorkObject3 wobj){
		this.wobj = wobj;

	}
	@Override
	public void run(){
		
	for(int i = 1 ; i <=3 ; i++) {
		wobj.methodB(i);
		wobj.methodA2(i);

	}
	
	wobj.notifyMainThread();
	}
}


public class Ex4 {
	public static void main(String[] args) {
		
			WorkObject3 wob = new WorkObject3();
			Thread t= new Thread(new A11(wob));
			t.start();
			
			
			Thread t1= new Thread(new B11(wob));
			t1.start();
			
			
		
			try {
				t.join();
				t1.join();
			}catch(Exception e) {
				
				
			}
			
			System.out.println("main end");
	}
	


}