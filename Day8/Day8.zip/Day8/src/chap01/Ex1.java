package chap01;

// 공유 객체 클래스
class WorkObject {
	
	WorkObject(){
		System.out.println("wkojt 생성됨");
	}
	
	synchronized void methodA() {
		System.out.println("thrreadA");
		notify();
		try {
			wait(); // 휴식상태
		}catch(InterruptedException  e) {
			
		}
	}
	
	synchronized void methodB() {
		System.out.println("threadB");
		notify(); // A깨운다
		try {
			wait(); // 휴식상태로 들어간다
		}catch(InterruptedException e) {
			
		}
	}
	
	public synchronized void notifyMainThread() {
		notify();
	}
	
	
}

class Test1A implements Runnable{
	private WorkObject workObject;
	public Test1A(WorkObject workObject) {
		this.workObject = workObject;
		System.out.println("Test1A 객체 생성");
}
	@Override
	public void run() {
		for(int i = 0 ; i <5;i++) {
			workObject.methodA();
		}
		
		workObject.notifyMainThread();
	}
	

}

class Test1B implements Runnable{
	private WorkObject workObject;
	public Test1B(WorkObject workObject) {
		this.workObject = workObject;
		System.out.println("Test1B객체 생성");
}

	public void run() {
		for(int i = 0 ; i <5;i++) {
			workObject.methodB();
			
		}
		
		workObject.notifyMainThread();
	}
}

public class Ex1 {
	public static void main(String[] args) throws Exception {
		WorkObject sharedObject = new WorkObject();
		Runnable a =  new Test1A(sharedObject);
		Runnable b =  new Test1B(sharedObject);
		Thread t1= new Thread(a);
		Thread t2= new Thread(b);
		t1.start();
		t2.start();
		
		try {
			t1.join();
			t2.join();
		}catch(Exception e) {
			
		}
		
		System.out.println("메인 메서드 종료");
	}

}
