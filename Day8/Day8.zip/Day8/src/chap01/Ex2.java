package chap01;

import java.io.*;

public class Ex2 {
	public static void main(String[] args) {
		try(OutputStream fos = new FileOutputStream("c:/DailyJava2/Quiz1.txt")) {
			byte[] ary = new byte[26];
			for(byte i = 'A' ; i <= 'Z' ; i++) {
				ary[i-'A'] = i;
			}
	
			fos.write(ary);
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		try(InputStream fis = new FileInputStream("c:/DailyJava2/Quiz1.txt")) {
			byte[] ary = new byte[26];
			int count;
			while((count = fis.read(ary))!= -1) {
				System.out.println(count+"바이트 읽음");
				for(int i = 0 ; i <count;i++) {
					System.out.print((char)ary[i]);
				}
			}
	
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("\n\n");
		
		
		try(Writer fw = new FileWriter("c:/DailyJava2/Quiz2.txt")){
			fw.write("안녕하세요.반갑습니다.또만나요");
		}catch(IOException e) {
			
		}
		
		

		try(Reader fw = new FileReader("c:/DailyJava2/Quiz2.txt")){
			int n;
			while((n=fw.read())!=-1) {
				System.out.print((char)n);
			}
		}catch(IOException e) {
			
		}
		
		
		
		
	}

}
