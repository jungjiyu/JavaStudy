package chap01;
import java.util.ArrayList;


class WorkObject2 {
	
	WorkObject2(){
	}
	
	synchronized void methodA(int i) {
		System.out.println("ThreadA:"+i);
	/*
		notify();
		try {
			wait(); // 휴식상태
		}catch(InterruptedException  e) {
			
		}
		*/
		System.out.println("ThreadA:"+i+"ends");
	}
	
	synchronized void methodB(int i) {
		System.out.println("ThreadB:"+i);
	/*	notify(); 
		try {
			wait(); 
		}catch(InterruptedException e) {
			
		}
		*/
		System.out.println("ThreadB:"+i+"ends");

	}
	
	public synchronized void notifyMainThread() {
		notify();
	}
	
	
}

class A1 implements Runnable{
	WorkObject2 wobj;
	A1(WorkObject2 wobj){
		this.wobj = wobj;
	}
	@Override
	public void run(){
		for(int i = 1 ; i <=3 ; i++) {
			
			wobj.methodA(i);
		}
		
		wobj.notifyMainThread();
	}
}

class B1 implements Runnable{
	int index;
	WorkObject2 wobj;

	B1(WorkObject2 wobj){
		this.wobj = wobj;

	}
	@Override
	public void run(){
		
	for(int i = 1 ; i <=3 ; i++) {
		wobj.methodB(i);
	}
	
	wobj.notifyMainThread();
	}
}


public class Ex5 {
	public static void main(String[] args) {
		
			WorkObject2 wob = new WorkObject2();
			
			
			
			
			Thread t= new Thread(new A1(wob));
			t.start();
			
			Thread t1= new Thread(new B1(wob));
			t1.start();
			
			try {
				
				t.join();
				t1.join();
			}catch(Exception e) {
				
			}
			
			System.out.println("main end");
	}
	


}