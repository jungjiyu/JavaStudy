/**
 * 
 */
/**
 * 
 */
module Day8 {
	requires java.se;
}