package dbPractice;

import java.sql.Connection;
import java.sql.DriverManager;
public class Main2 {
	public static void main(String[] args) {
		
	// 데이터 베이스에 연결하는 코드
		Connection conn = null; // 일단 초기화
		
		String driver = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String dbId = "C##JAVAUSER";
		String dbPw = "java2024";
		
		try {
			Class.forName(driver); // 로드
			conn = DriverManager.getConnection(url,dbId,dbPw); // 정보 입력하여 객체 생성
			System.out.println("connection 성공");
			
		}catch(Exception e) {e.printStackTrace();}finally {
			try {
				if(conn != null) {
					conn.close();
				}
			}catch(Exception e) {e.printStackTrace();}
		}
		
		
		
	}
}
