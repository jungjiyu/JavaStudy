package dbPractice;

import java.sql.Connection;
import java.sql.DriverManager; // 데이터 베이스에 연결 할 수 있게 해줌
import java.sql.ResultSet; // 인페
import java.sql.Statement; // 인페


public class Main3 {
	public static void main(String[] args) {
		Connection conn = null; // 데이터 베이스 연결하는 객체
		Statement statement = null; // db 데이터 접근해서 crud 작업을 하게 해준다
		ResultSet rs = null; // 데이터 조회 결과를 가짐
		
		
		// 초기화
		String driver = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String dbId = "C##JAVAUSER";
		String dbPw = "java2024";
		
		// student 테이블에 있는 모든 핛생 조회하기
		try {
			String query = "SELECT * FROM STUDENT"; // 데이터 조회하는 쿼리문
			
			Class.forName(driver); // 드라이버 로드
			conn = DriverManager.getConnection(url,dbId,dbPw); // db 연결
			statement = conn.createStatement(); // sql 쿼리문을 실행하기 위한 객체 "준비"
			rs = statement.executeQuery(query); // 만든 객체로 쿼리문을 동작 시키고 결과를 저장함
			
			
			while(rs.next()) { // 열에 해당하는 데이터ㄹ를 꺼내 가져옴
				int studentId = rs.getInt("STUDENTID");
				String name = rs.getString("NAME");
				int age = rs.getInt("AGE");
				int grade = rs.getInt("GRADE");
				int departmentcode = rs.getInt("DEPARTMENTCODE");
				
				System.out.println(name+" 학생의 학번: "+ studentId);
				System.out.println(name+" 학생의 나이: "+ age);
				System.out.println(name+" 학생의 성적: "+ grade);
				System.out.println(name+" 학생의 학과 코드: "+ departmentcode);
				System.out.println();
	
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally { // 다 하면 연결을 끊어줌
			
			try {
				if(statement != null) statement.close();
				if(conn != null) conn.close();

			}catch(Exception e) {e.printStackTrace();}
		}
		
		
		
	}

}
