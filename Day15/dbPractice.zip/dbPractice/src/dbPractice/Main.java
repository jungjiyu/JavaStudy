package dbPractice;
//JDBC
/*

데이터 베이스 연결 및 작업을 ㅇ위한 자바 표준 인터페이스

*/



public class Main {
	public static void main(String[] args) {
		System.out.println("he");
		String driver = "oracle.jdbc.OracleDriver"; // 데이터베이스 연동할 수 있게 도와주는 드라이버
		try {
			Class.forName(driver);
			System.out.println("클래스로딩성공!");
		}catch(ClassNotFoundException e) {e.printStackTrace();}
		
		
	}

}
