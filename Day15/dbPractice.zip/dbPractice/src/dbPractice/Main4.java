package dbPractice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main4 {
	public static void main(String[] args) {
		Connection conn = null; // 데이터 베이스 연결하는 객체
		Statement statement = null; // db 데이터 접근해서 crud 작업을 하게 해준다
		
		
		// 초기화
		String driver = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String dbId = "C##JAVAUSER";
		String dbPw = "java2024";
		
	// 테이블에 데이터 출력
		try {
			String query = "INSERT INTO STUDENT VALUES (202412, '아이유' , 21 , 3 ,333)"; // 데이터 조회하는 쿼리문
			
			Class.forName(driver); // 드라이버 로드
			conn = DriverManager.getConnection(url,dbId,dbPw); // db 연결
			statement = conn.createStatement(); // sql 쿼리문을 실행하기 위한 객체 "준비"
			int result = statement.executeUpdate(query); // 결과를 int 형으로 바음. 변경된 레코드 값을 반환
			
			if(result == 1 ) { // 1 개 insert 잘 됬으면 (true 를 의미하는 1 이 아님)
				System.out.println(" INSERT 성공! ");
			}
			
		
			}catch(Exception e) {
				System.out.println("insert 실패:");
			e.printStackTrace();
			
		}finally { // 다 하면 연결을 끊어줌
			
			try {
				if(statement != null) statement.close();
				if(conn != null) conn.close();

			}catch(Exception e) {e.printStackTrace();}
		}
		
		
		
	}

}
