package chap05;


interface Catable{
	public void catString(String s1, String s2);
}




public class Activate {
	public static void main(String[] args) {
		String s1 ="hello";
		String s2 =", java";
		int i = 100;
		
		Catable con = (m,n) -> { // 매개변수명으로 이미 존재하는 변수명 쓰면 에러 난다
			
			System.out.println(i);
		//	i=200; 내부서 값을 못바꾼다
			System.out.println(m+n);
		};
		
		con.catString(s1, s2);
	
	}

}
