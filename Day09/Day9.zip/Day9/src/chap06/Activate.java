package chap06;

import java.util.function.*;

//function 의 합성1
//andThen 메서드 : andThen 메서드는 현제 함수를 실행한 이후에 다른 함수를 실행


public class Activate {
	public static void main(String[] args) {
		Supplier<String> supplier = () -> "Hello java";
		String str =supplier.get();
		System.out.println(str);
		
		Consumer<String> consumer = (s) -> System.out.println(s);
		consumer.accept(str);
		
		
		Function<String,Integer> function = (s) -> s.length();
		int count = function.apply(str);
		System.out.println(str+"의 글자 갯수:"+count);
		
		Predicate<String> predicate = (s) -> str.equals("hehe");
		boolean flag = predicate.test(str);
		System.out.println(str+"와 hehehe 는 같은 글자: "+flag);
		
		Predicate<Integer> isEven = (n) -> n%2==0;
		int num =100;
		boolean flag2 = isEven.test(num);
		System.out.println(str+"와 는 짝수: "+flag2);
		
		
		UnaryOperator<String> addEx = s -> s+".java";
		String newName= addEx.apply("file1");
		System.out.println(newName);
		
		//1. 함수 정의
		Function<Integer, Integer> addOne = x ->x+1;
		Function<Integer, Integer> multiplyByTwo = x ->x*2;
		
		//2. 함수 합성
		Function<Integer, Integer> addOneAndThenMultiplyByTwo = addOne.andThen(multiplyByTwo);
		int result = addOneAndThenMultiplyByTwo.apply(3);
		System.out.println("result: "+result);
	}

}
