package chap01;


@FunctionalInterface
interface Number{
	public int getMax(int num1, int num2);
}

@FunctionalInterface
interface PrintString{
	public void showString(String str);
}

@FunctionalInterface
interface LamdaTest1{
	int sum(int num1, int num2);
}

//문자열 두개를 연결해서 출력


public class Ex1 {
	public static void main( String[] args) {
		// &&람다식 선언
		Number max = (x,y) -> (x >= y) ? x : y ; 
		System.out.println(max.getMax(10, 20));
		
		
		PrintString lamdaStr = str -> System.out.println(str);
		lamdaStr.showString("hegegegeg");
		
		LamdaTest1 op = (a,b) -> a+b;
		System.out.println(op.sum(10,20));
		
		
	}
}
