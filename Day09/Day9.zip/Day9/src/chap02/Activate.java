package chap02;



interface Catable{
	public String catString(String s1, String s2);
}


class StringUsing implements Catable{
	@Override
	public String catString(String a1, String a2) {
		return a1+a2;
	}
}

public class Activate {
	public static void main( String[] args) {
		// 람다식 없이 인터페이스 구현 객체 만들고 쓰렴 좀 복잡하다
		StringUsing su = new StringUsing();
		String str = su.catString("hi ", "hello");
		System.out.println(str);
		
		// 람다식으로 훨씬 쉽게 쓸 수 있다
		Catable cs =(a1,a2) -> a1+a2;
		System.out.println(cs.catString("hehehe", " yoyo"));
	
		
	}

}
