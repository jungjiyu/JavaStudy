package chap07;

import java.util.function.*;

public class Activate {
	public static void main(String[] args) {
		
	}

}
