package chap04;

interface Catable{
	public String catString(String s1, String s2);
}

public class Activate {
	public static void main(String[] args) {
		String s1 ="hello";
		String s2 ="hello";
		
		Catable connection = new Catable() {
			@Override
			public String catString(String s1, String s2) {
				return s1+s2;
			}
		};
		
		String str = connection.catString(s1, s2);
		System.out.println(str);
	}

}
