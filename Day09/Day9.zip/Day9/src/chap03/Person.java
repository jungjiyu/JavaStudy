package chap03;

public class Person {
	String name;
	public Person(String name) {
		this.name = name;
	}

	public void speak() {
		System.out.println("내용 무");
	}
}
