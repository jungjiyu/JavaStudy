package chap03;

public interface Dance {
	void dancer();
}
