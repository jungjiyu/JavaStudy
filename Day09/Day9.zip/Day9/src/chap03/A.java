package chap03;

public class A {
	
	A(){
		System.out.println("A() 생성자 실행됨");
	}
	
	public void printA() {
		System.out.println("A");
	}

}
