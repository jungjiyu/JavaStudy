package chap03;

public class Activate {
	public static void main(String[] args) {
		// 익명 객체
		A a = new A() {
			@Override
			public void printA() {
				System.out.println("AAAAAa");
			}
		};
		// 익영 객체
		Person person = new Person("춘식이") {
			@Override
			public void speak() {
				System.out.println("춘식이 입니다");
			}
		};
		
		person.speak();
		
		
		Dance dance = new Dance() {
			@Override
			public void dancer() {
				System.out.println("dance");
			}
		};
		
		dance.dancer();
	}

}
