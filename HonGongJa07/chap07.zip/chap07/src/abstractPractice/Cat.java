package abstractPractice;

public class Cat extends Animal{
	
	@Override
	public void sound() {
		System.out.println("meow~~~");
	}

}
