package abstractPractice;

public abstract class Animal {
	String name;
	
	Animal(){}
	Animal(String name){
		this.name = name;
	}
	
	public abstract void sound(); // 추상메서드 >> 오버라이딩 강제성
	
	
}
