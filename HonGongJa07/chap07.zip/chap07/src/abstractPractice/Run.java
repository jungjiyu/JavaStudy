package abstractPractice;

public class Run {
	public static void main(String[] args) {
		Cat cat = new Cat();
		Dog dog = new Dog();
		
		animalSound(cat);
		animalSound(dog);
		
		// 추상클래스의 객체 생성은 불가해도 변수 선언은 가능하다
	}
	
	public static void animalSound(Animal animal) { 
		animal.sound();
	}
}
