package polymorphismPractice;

import polymorphismPractice.cars.*;
import polymorphismPractice.tires.*;

public class Run {
	public static void main(String[] args) {
		Hyundai myCar = new Hyundai();
		System.out.println("\n");
		System.out.println("--------------------------------------");
		for(int i=0; i <10 ; i++) {
		
			int problemIndex =myCar.run();
			switch(problemIndex) { // 타이어 펑크나면 교체함
			// 짜증나는게 case1,2,3,4 다 비스무리한데 메서드 만들어서 퉁 칠 수 없는게 인덱스가 1,2,3,4 냐 따라서 접근해야하는 필드자체가 다름
			case 1:
				myCar.tire1 = new KoreanTire(1);
				System.out.println("타이어1 펑크되어 교체함,새 타이어 수명:"+myCar.tire1.maxCount);
				break;
				
			case 2:
				myCar.tire2 = new KoreanTire(2);
				System.out.println("타이어2 펑크되어 교체함,새 타이어 수명:"+myCar.tire2.maxCount);
				break;
				
			case 3:
				myCar.tire3 = new ChineseTire(3);
				System.out.println("타이어3 펑크되어 교체함,새 타이어 수명:"+myCar.tire3.maxCount);
				break;
			case 4:
				myCar.tire4 = new Tire(4);
				System.out.println("타이어4 펑크되어 교체함,새 타이어 수명:"+myCar.tire4.maxCount);
				break;
			
			}
			
			System.out.println("--------------------------------------");
		}
		
	}
	
	
}
