package polymorphismPractice.cars;

import polymorphismPractice.tires.Tire;

public class Genesis {
	public int distance =0; 

	public Tire[] tires = new Tire[4]; // 오류남 :(
	 
	public Genesis(){
		for(int i = 0; i < tires.length ; i++) {
			tires[i] = new Tire(i+1);  
		}
		
		
	}


	
	public int run() {
		draw();
		for(int i =0;i<4;i++) {
			if(tires[i].roll()) {
				stop();
				return i+1;
			}
		}
		distance+=3;
		
	return 0;
	}
	
	
	public void stop() {
		System.out.println("자동차멈춤!");
	}
	
	public void draw() {
		System.out.println("");
		space();
		System.out.print("  ______\r\n");
		space();
		System.out.print(" /|_||_\\`.__\r\n");
		space();
		System.out.print("(   _    _ _\\\r\n");
		space();
		System.out.print("=`-(_)--(_)-' ");
		System.out.println("주행:"+distance+"km");
	}
	
	public void space() {
		for(int i=0;i<distance;i++) {
			System.out.print(" ");
		}
	}

}
