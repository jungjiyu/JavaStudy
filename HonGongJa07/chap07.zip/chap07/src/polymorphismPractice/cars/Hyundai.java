package polymorphismPractice.cars;

import polymorphismPractice.tires.*;

public class Hyundai {
	
	public int distance =0; 
	public Tire tire1 = new Tire(1);
	public Tire tire2 = new Tire(2);
	public Tire tire3 = new Tire(3);
	public Tire tire4 = new Tire(4);
	
	
	/*
	public Tire[] tires = new Tire[4]; // 오류남 :(
	 
	
	for(int i = 0; i < tires.length ; i++) {
		tires[i] = new Tire(i+1);  
	}
	
	*/
	
	public int run() {
		draw();
		if(tire1.roll()) {
			stop(); 
			return 1;
			}
		
		if(tire2.roll()) {
			stop(); 
			return 2;
			}
		
		if(tire3.roll()) {
			stop(); 
			return 3;
			}
		
		if(tire4.roll()) {
			stop(); 
			return 4;
			}
		distance+=3;
		
	return 0;
	}
	public void stop() {
		System.out.println("자동차멈춤!");
	}
	public void draw() {
		System.out.println("");
		space();
		System.out.print("  ______\r\n");
		space();
		System.out.print(" /|_||_\\`.__\r\n");
		space();
		System.out.print("(   _    _ _\\\r\n");
		space();
		System.out.print("=`-(_)--(_)-' ");
		System.out.println("주행:"+distance+"km");
	}
	
	public void space() {
		for(int i=0;i<distance;i++) {
			System.out.print(" ");
		}
	}
}
