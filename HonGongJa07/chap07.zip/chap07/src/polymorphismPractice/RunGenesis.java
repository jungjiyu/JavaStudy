package polymorphismPractice;

import polymorphismPractice.cars.Genesis;
import polymorphismPractice.tires.ChineseTire;
import polymorphismPractice.tires.KoreanTire;
import polymorphismPractice.tires.Tire;

public class RunGenesis {
	
	
	public static void main(String[] args) {
		Genesis myCar = new Genesis();
		System.out.println("\n");
		System.out.println("--------------------------------------");
		for(int i=0; i <10 ; i++) {
		
			int problemIndex =myCar.run();
			switch(problemIndex) { // 타이어 펑크나면 교체함
			case 1:
				changeToKorean(myCar,1);
				break;
				
			case 2:
				changeToKorean(myCar,2);
				break;
				
			case 3:
				changeToChinese(myCar,3);
				break;
			case 4:
				changeToTire(myCar,4);
				break;
			
			}
			
			System.out.println("--------------------------------------");
		}
		
		
	}
	
	public static void changeToKorean(Genesis car,int index) {
		car.tires[index-1] = new KoreanTire(index);
		System.out.println("타이어"+index+"펑크되어 교체함,새 타이어 수명:"+ car.tires[index-1].maxCount);
	}
	
	public static void changeToChinese(Genesis car,int index) {
		car.tires[index-1] = new ChineseTire(index);
		System.out.println("타이어"+index+"펑크되어 교체함,새 타이어 수명:"+ car.tires[index-1].maxCount);
	}
	
	public static void changeToTire(Genesis car,int index) {
		car.tires[index-1] = new Tire(index);
		System.out.println("타이어"+index+"펑크되어 교체함,새 타이어 수명:"+ car.tires[index-1].maxCount);
	}
}
