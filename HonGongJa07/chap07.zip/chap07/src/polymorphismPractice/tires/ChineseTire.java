package polymorphismPractice.tires;

public class ChineseTire extends Tire{
	public ChineseTire(int index){
		super(index);
		maxCount = 2; // 중국산 == 최대 3회 사용 가능
		System.out.println("ChineseTire 생성자 실행됨");
	}
	
	@Override
	public boolean roll() {
		count+=3; //일반 타이어보다 더 빨리 닳는다
		if(count >maxCount) return true; //펑크 난 경우
		System.out.println("tire"+index+" 잘 굴러감 (남은수명: "+(maxCount-count)+")");
		return false;
	}
	
	
}
