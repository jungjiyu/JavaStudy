package polymorphismPractice.tires;

public class Tire { 
	public int maxCount=5;
	public int count=0;
	public int index; // 1~4
	
	public Tire(int index) {
		this.index = index;
		System.out.println("Tire 생성자 실행됨");
		//System.out.println("최초수명:"+maxCount); 
			/*
			 이거 쓰면 에러는 안나지만 프로그램 맥락이 이상하게 되는게 자식클래스의 생성자가 실행되기 이전에 
			 부모클래스 생성자가 실행되는거라 자식클래스의 생성자 부분에서 maxCount 값을 바꾸는게 적용되기 이전의 부모의 원래 maxCount 값이 출력된다.
			 
			 그리고 자식클래스에서 단순히 maxCount 값을 바꾸는 차원을 넘어 재정의했다해도 똑같이 문제가 되는게 부모클래스 내부서 매개변수로 넘어오지 않는 한
			 자식 클래스의 개별적인 멤버에 접근 못할 뿐아니라 애초에 자식 클래스의 생성자가 완료되지 않았기에 자식 클래스의 멤버는 생성조차 안됬음
			 
			 */
	}
	
	public boolean roll() {
		count+=2;
		if(count >maxCount) return true; //펑크 난 경우
		System.out.println("tire"+index+" 잘 굴러감 (남은수명: "+(maxCount-count)+")");
		return false;
	}

}
