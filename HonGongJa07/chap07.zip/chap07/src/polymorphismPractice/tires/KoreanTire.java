package polymorphismPractice.tires;

public class KoreanTire extends Tire{
	
	public KoreanTire(int index){
		super(index);
		maxCount = 8;
		System.out.println("KoreanTire 생성자 실행됨");
	}
	
	@Override
	public boolean roll() {
		count++; // 일반 타이어보단 덜 닳는다
		if(count >maxCount) return true; //펑크 난 경우
		System.out.println("tire"+index+" 잘 굴러감 (남은수명: "+(maxCount-count)+")");
		return false;
	}
	
	
	
}
