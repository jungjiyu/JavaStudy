package overridingPractice;

public class Parent {
	String name;
	int age;
	char sex; //w , m
	final String car = "Ferrari";
	
	public Parent(String name, int age , char sex){ // 기본 생성자 Parent( ) 는 없는 상황 >> 자식메서드에서 필수적으로 super(arg1 ,..) 직접 호출 필요
		this.name = name;
		this.age = age;
		this.sex = sex;
		System.out.println("Parent 클래스의 생성자 내부에 들어왔습니다");
	}
	
	public void airpods() {
		System.out.println("으디 업무시간에 에어팟을 껴? 여윽시 mz야 mz!");
	}
	
}
