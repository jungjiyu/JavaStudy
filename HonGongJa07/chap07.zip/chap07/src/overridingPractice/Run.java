package overridingPractice;

public class Run {
	public static void main(String[] args) {
		child ex1 = new child("HongGilDong",10,'w');
		ex1.airpods();
		ex1.car();
		
	}
}

// 질문 >> 메서드와 다르게 필드에선 오버라이딩 개념이 존재하지 않고, 필드는 겹치는 이름의 필드가 있으면 필드 하이딩이라고 한다는데
	// 그럼 부모 클래스와 자식 클래스에서 필드가 어떻게 존재하는 거임? 
		// 이름 겹치는 필드 없으면 그냥 부모 클래스것이 자기것인것 마냥 편하게 이름으로만 쓰면 되고
		// 이름 겹치는 필드 있으면 자식꺼는 별도로 생기는거고 숨겨진 부모의 필드를 쓰려면 super.필드명 으로 접근해야됨?
