package overridingPractice;

public class child extends Parent{

	static String car = "Hyundai"; // 필드 하이딩
	
	public child(String name,int age,char sex){
		super(name, age, sex);
		System.out.println("child 클래스의 생성자가 종료됬습니다");
	}
	
	@Override
	public void airpods() {
		System.out.println(name+"왈: 에어팟은 업무의 효율을 증진시킵니다."); //name >> 부모클래스에만 존재하는 필드인데도 별다른 선언 없이 쓸 수 있음
		System.out.print("그 말을 들은 꼰대: ");
		super.airpods();
	}
	
	public void car() {
		System.out.println("내차:"+car);
		System.out.println("꼰대 차:"+super.car); // 부모 클래스와 겹치는 필드명이기에 super 를 밝혀 써야됨
		
	}

	
	
}
