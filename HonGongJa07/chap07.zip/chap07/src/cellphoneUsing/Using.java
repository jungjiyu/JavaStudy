package cellphoneUsing;

import cellphones.ApplePhone;
import cellphones.SamsungPhone;

public class Using {
	public static void main(String[] args) {
		System.out.println("ApplePhone 객체 생성 이전");
		// ApplePhone 객체 생성전 >> "Apple" 로 초기화 안되서 "Samsung" 나오는게 정상임
		System.out.println("ApplePhone.model: "+ApplePhone.model);
		System.out.println("\n");
		
		//new 키워드 사용 시점에서 ApplePhone의 생성자가 실행되어 값이 "Apple"로 초기화됨 , 주의해야 할 것은 Samsung.model 마져 "Apple" 로 세팅되버림
		ApplePhone myPhone = new ApplePhone();
		System.out.println("\n");
		System.out.println("ApplePhone 객체 생성 후");
		
		myPhone.gamSung();
		System.out.println("\n");
		
		System.out.println("ApplePhone.model: "+ApplePhone.model);
		System.out.println("SamsungPhone.model: "+SamsungPhone.model);  // 얘도 "Apple" 나옴 >>  ApplePhone이 개별적으로 필드를 가지고 있는게 아니라 SamsumgPhone꺼 갖다 쓰고있어서 그럼.
	
		
	}
}