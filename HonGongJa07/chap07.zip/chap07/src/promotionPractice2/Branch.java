package promotionPractice2;

public class Branch extends Tree{
	
	String name = "Branch";
	
	Branch(){}
	
	Branch(String name){
		this.name = name;
	}
	
	public void bird() {
		System.out.println("   ,_\r\n"
				+ "  >' )\r\n"
				+ "  ( ( \\ \r\n"
				+ "   ''|\\");
	}
	@Override
	public void sayMyName() {
		System.out.println("my name is "+ name+ " who is Branch");
	}
	
}
