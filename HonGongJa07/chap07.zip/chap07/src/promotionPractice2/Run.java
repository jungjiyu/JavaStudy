package promotionPractice2;

public class Run {
	public static void main(String[] args) {
		
		Tree obj1 = new Branch("kim kardashian"); // Tree 타입으로 자동형변환
		Tree obj2 = new Leaf("kylie jenner"); 
		
		obj1.sayMyName(); 
		obj2.sayMyName(); 
		
		System.out.println("\n");
	
		returnOrgin(obj1);
		System.out.println("\n");
		returnOrgin(obj2);
		
	}
	
	public static void returnOrgin(Tree obj) {
		if(obj instanceof Branch) {
			System.out.println(obj+"객체는 Branch 클래스의 객체 입니다");
			Branch newObj1 = (Branch)obj; // 자식타입으로 되돌리고 이를 자식타입변수로 받는다.		
			newObj1.bird();
			newObj1.sayMyName(); // 명시적 형변환 되어도 타입이 변하는거지, 객체를 갈아치우는게 아니라 기존 정보(kim kardarshian) 유지된다.
		}
		
		else if(obj instanceof Leaf) {
			System.out.println(obj+"객체는 Leaf 클래스의 객체가 맞습니다");
			Leaf newObj2 = (Leaf)obj; // 자식타입으로 되돌리고 이를 자식타입변수로 받는다.	
			newObj2.Bug();
			newObj2.sayMyName(); // 명시적 형변환 되어도 타입이 변하는거지, 객체를 갈아치우는게 아니라 기존 정보(Kylie jenner) 유지된다.
		}
		
		
	}

}
