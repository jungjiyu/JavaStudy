package promotionPractice2;

public class Tree {
	String name = "Tree";
	
	Tree(){} // 내가 봤을때 arg 를 필요로 하는 생성자를 만들어놨을때 당장은 필요없어보여도 기본생성자를 만들어두는건 혹시라도 이 클래스를 부모 생성ㅇ자를 하게 될 경우 별도로 super(arg1, ..); 하지 않아도 되게 하기 위해서이다(컴파일러 차원에서 기본생성자로 싸바싸바 하고 끝내게 하기 위해서이다)
	
	Tree(String name){
		this.name = name;
	}
	
	public void sayMyName() {
		System.out.println("my name is " + name + " who is Branch");
	}
	
}


