package promotionPractice2;

public class Leaf extends Branch{
	
	String name = "Leaf";
	
	Leaf(){}

	Leaf(String name){
		this.name = name;
	}
	
	public void Bug() {
		System.out.println("  \\_/-.--.--.--.--.--.\r\n"
				+ "    (\")__)__)__)__)__)__)\r\n"
				+ "     ^ \"\" \"\" \"\" \"\" \"\" \"\"");
	}

	@Override
	public void sayMyName() {
		System.out.println("my name is "+name+" who is Leaf");
	}
}
