package promotionPractice;

import overridingPractice.child;
import overridingPractice.Parent;

public class Run {
	public static void main(String[] args) {
		
		child ch =  new child("jiyu",10,'w');
		Parent par =  ch; // 커팅되어 들어간다
		
		System.out.println(ch==par); // 부모타입참조변수도 할당받은 자식 객체를 참조하고 있다
		
		//par.car(); 같은 자식타입객체를 참조하고 있지만 부모타입멤버가 아닌 멤버엔 접근하지 못한다
		
		par.airpods(); // 부모타입이라도 오버라이딩된 메서드를 호출하면 자식클래스의 메서드가 호출된다
		
		
		
	}

}
