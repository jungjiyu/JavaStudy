package cellphones;

import cellphones.SamsungPhone;

public class ApplePhone extends SamsungPhone{
	
	
	public ApplePhone(){
		price = 300;  // 생성자나 메서드 블럭 외부에서는 선언 혹은 선언과 동시에 초기화 	밖에 못함. 외부에서 price = 300; 으로 못고침
		model = "Apple";
		System.out.println("ApplePhone의 생성자 안에 들어왔음");

	}
	
	public void gamSung() {
		System.out.println("▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒\r\n"
				+ "▒▒▄▄▄▒▒▒█▒▒▒▒▄▒▒▒▒▒▒▒▒\r\n"
				+ "▒█▀█▀█▒█▀█▒▒█▀█▒▄███▄▒\r\n"
				+ "░█▀█▀█░█▀██░█▀█░█▄█▄█░\r\n"
				+ "░█▀█▀█░█▀████▀█░█▄█▄█░\r\n"
				+ "████████▀█████████████");
	}
}
