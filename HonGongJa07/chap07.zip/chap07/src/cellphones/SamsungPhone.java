package cellphones;

public class SamsungPhone {

	//private SamsungPhone() {} : 이렇게 하면 부모 객체가 생성되지 못하여서 이를 이용하여 생성되는 자식 객체 마저 생성되지 못한다
	
	protected SamsungPhone(){
		System.out.println("SamsungPhone의 생성자 안에 들어왔음");
	} //protected 으로 선언해도 다른 패키지의 Using.java 가 실행이 잘 되는건 Using.java 는 SamsungPhone 과 같은 패키지 내에 있는 ApplePhone.java 를 매개로 SamsungPhone()을 호출하였기 때문이다
	
	public static String model = "samsung";
	public int price = 190;
	
	public  void powerOn() {System.out.println("power on :~)");}
	public void bell() {
		System.out.println("ringringring");
	}
	public void takeCall() {
		System.out.println("(딸깍)");
	}
	
	public void failCall() {
		System.out.println("전화를 받을 수 없어 삐 소리 후 통화료가 부과되며 소리샘으로 연결됩니다");
	}
	
	public void endCall() {
		takeCall();
	}
	
	void powerOff() {System.out.println("power off :~( ");}

}
