package chap01;


import java.io.*;



public class Ex2 {
	public static void main(String[] args) {

		String str = "안녕하세요";
		try(Writer fr = new FileWriter("C:/DailyJava2/reader.txt")){
			fr.write(str);
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
		char[] ary = new char[100];
		int n ;
		try(Reader fr = new FileReader("C:/DailyJava2/reader.txt")){
			n = fr.read(ary);
			System.out.println("받아온 값의 개수: "+n);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		// 에엑 ??? 초기화가 안됬다고 썅??
		/*
		for(int i = 0 ; i < n ; i++) { 
			System.out.print(ary[i]);
		}
		*/
		
	}

}
