package chap01;


import java.io.*;
//write ( ) 3가지 이상 이용해 텍스트 쓰고, FileWriter 를 사용하여 자료 출력후 파일확ㅇ;ㄴ
public class Ex3 {
		public static void main(String[] args) {

			String str = "안녕하세요\n";
			String str2 = "안녕하지못합니다\n";
			String str3 = "...?\n";
			
			try(Writer fr = new FileWriter("C:/DailyJava2/reader.txt")){
				fr.write(str);
				fr.write(str2);
				fr.write(str3);
				
			}catch(IOException e) {
				e.printStackTrace();
			}
			
			
			char[] ary = new char[100];
			int n ;
			try(Reader fr = new FileReader("C:/DailyJava2/reader.txt")){
				n = fr.read(ary);
				System.out.println("받아온 값의 개수: "+n);
				
				for(int i = 0 ; i < n ; i++) { 
					System.out.print(ary[i]);
				}
			}catch(IOException e) {
				e.printStackTrace();
			}
			
			
			
			
			
		}

	}
