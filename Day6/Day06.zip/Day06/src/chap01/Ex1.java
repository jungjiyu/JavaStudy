package chap01;


import java.io.FileOutputStream;
import java.io.IOException;


public class Ex1 {
	public static void main(String[] args) {
		try(FileOutputStream fos = new FileOutputStream("C:/DailyJava2/output.txt")){
			fos.write(23);
			fos.write(66);
			fos.write(67);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		// 기본 디폴트 값이었던 false 를 true 로 함으로써 append 기능이 구현됨
		try(FileOutputStream fos = new FileOutputStream("C:/DailyJava2/output.txt",true)){
			fos.write(23);
			fos.write(66);
			fos.write(67);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
		// 크기 26인 배열 생성 , write () 와 반복문 써서 A-Z 값 쓰기
		
		byte[] ary = new byte[26];
		
		for(int i = 'a';i<='z';i++) {
			ary[i-'a'] = (byte)i;
		}
		try(FileOutputStream fos = new FileOutputStream("C:/DailyJava2/output.txt")){
			fos.write(ary);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
		// 위의 배열을 이용하여 c 부터 l 까지 값 쓰기		
		
		
		try(FileOutputStream fos = new FileOutputStream("C:/DailyJava2/output.txt")){
			fos.write(ary,'c'-'a', 'l'-'c' + 1 ); // 맨 마지막 arg 는 끝 인덳스가 아니라 갯수임을 주의
													// 초등 수학
														// 피연산자가 이상 미만 혹은 초과 이하 >> 걍 뺌 됨
														// 피연산자가 이상 이하 (양사이드 다 포함)>> 빼고 +1
														// 피연산자가 초과 미만 >> 빼고 -1
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

}
