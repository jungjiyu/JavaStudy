package chap01;

import java.io.*;

//file input 기반 스트림가 inputstreamreader 버저 스트림 이영해 읽고 출력

public class Ex4 {

		public static void main(String[] args) {

			
			
			
			int n;
			try(InputStream fr = new FileInputStream("C:/DailyJava2/input.txt")){
				InputStreamReader isr = new InputStreamReader(fr);
				
				while((n = fr.read())!= -1) {

					System.out.print(n+"\t");	
				}
				
				
				
			}catch(IOException e) {
				e.printStackTrace();
			}
			
			
		}

	}