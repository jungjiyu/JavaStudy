/**
 * 
 */
/**
 * 
 */
module Day06 {
	requires java.se;
}