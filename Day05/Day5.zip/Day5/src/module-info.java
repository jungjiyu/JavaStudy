/**
 * 
 */
/**
 * 
 */
module Day5 {
	requires java.se;
}
