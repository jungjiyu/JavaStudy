package chap01;
import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;

public class Ex5 {
	public static void main(String[] args) {
		byte[] b= new byte[10];
		int count =0;
		try (FileInputStream fis = new FileInputStream("C:/DailyJava2/input2.txt")){
			
			/*
			count =0;
			while(count <=9) {
				int n = fis.read();
				b[count] = (byte)n;
				System.out.println(count);
				count++;
			
			}
			
			count =0;
			while(count <=9) {
				System.out.print((char)(b[count]));
				count++;
			
			}
			
			*/
			int i;
			while((i = fis.read(b)) != -1){ // 내부에 배열이 arg 로 들어감
				for(byte bb: b) { // 덮어쓰기 문제가 있다
					System.out.print((char)bb);
				}
				System.out.println(":"+i+"바이트 읽음");
			}
			
			
			

			// 답
			
			
			
			
						
		}catch (IOException e) {
			e.printStackTrace(); // 어떤 에러가 발생했는지 정보 보여줌 . 경로까지
		}
		
		
		
	}

}
