package chap01;

import java.io.IOException; // 인풋 과정서 발생하는 예외 처리
import java.util.Scanner;

public class Ex2 {
	static int i;
	public static void main(String[] args) {
		
		
			// 문자열로 반환하기
			try{
				System.out.print("문자열 입력:");
				
				while(true) {
				i= System.in.read();
				System.out.print((char)i); 
				if(i=='\n') break;
				}
				
			} catch(IOException e) {
				e.printStackTrace(); 
			}
			
			
			int k;
			
			try{
				System.out.print("문자열입력: ");
				while( (k =System.in.read()) != '\n') {
					System.out.print((char)k);
				}
				
			} catch(IOException e) {
				e.printStackTrace(); 
			}
			
			
			
		
		
		
		//
		
		
		
	}

}
