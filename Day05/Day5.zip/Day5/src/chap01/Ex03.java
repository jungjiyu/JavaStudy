package chap01;

import java.io.FileInputStream; // ㅇ;ㅂ력 관려ㄴㄴ해선 io 패키지에 있음
import java.io.IOException; // read () 써서 필요

public class Ex03 {
	public static void main(String[] args) {
		byte[] ary = new byte[4];
		//FileInputStream fis =null;
		try (FileInputStream fis = new FileInputStream("C:/DailyJava2/input.txt")){
			//fis = new FileInputStream("C:/DailyJava2/input.txt");

			while(true) {
				int n = fis.read();
				if(n == -1) break;
				
				System.out.print((char)(n));
				
			}
			
			// 답
			
			int n ;
			while((n= fis.read()) != -1) {
				System.out.print((char)(n));				
			}
			
			
		//	fis.close();
			
		}catch (IOException e) {
			e.printStackTrace(); // 어떤 에러가 발생했는지 정보 보여줌 . 경로까지
		}
		
		
		
	}

}
