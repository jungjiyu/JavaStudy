package chap01;

import java.io.IOException; // 인풋 과정서 발생하는 예외 처리

public class Ex1 {
	public static void main(String[] args) {
		// 표쥰 줄력 스트림
		System.out.println("hell");
		
		
		// 표준 입력 스트림
		int i ;
		try{
			System.out.print("문자 하나 입력:");
			i= System.in.read();
			System.out.println(i); 
			System.out.println((char)i); 
		} catch(IOException e) {
			e.printStackTrace(); 
		}
		
		//
		
		
		
	}

}
