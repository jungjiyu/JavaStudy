package chap01;

import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;

public class Ex04 {
	public static void main(String[] args) {
		
		
		}

}
