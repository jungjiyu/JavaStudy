package chap01;

import java.io.*;

public class Ex2 {
	public static void main(String[] args) {
		//Buffed 보조 스트림 사용
		
long millisecond = 0;
		
		try(InputStream fis = new FileInputStream("c:/DailyJava2/A.zip");
				OutputStream fos = new FileOutputStream("c:/DailyJava2/A1.zip");
				){
			
			millisecond = System.currentTimeMillis(); // 파일 읽어오는 시간 체크하는 메서드
			int count ;
			byte[] ary = new byte[10000];
			
			while((count = fis.read(ary)) != -1) {
				System.out.println(count+"개의 자료를 읽어왔습니다");
				fos.write(ary);
				millisecond = System.currentTimeMillis()-millisecond;
				System.out.println("\n복사에 "+millisecond+"밀리초 걸렸습니다");

				for(int i = 0 ;i <count;i++) {
					System.out.print((char)ary[i]);
				//	fos.write(ary[i]);
				}
				
				
			}
			
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
		try(InputStream fis = new FileInputStream("c:/DailyJava2/A.zip");
				OutputStream fos = new FileOutputStream("c:/DailyJava2/A1.zip");
				InputStream bis = new BufferedInputStream(fis);
				OutputStream bos = new BufferedOutputStream(fos);){
			
			millisecond = System.currentTimeMillis(); // 파일 읽어오는 시간 체크하는 메서드
			int count ;
			while((count = bis.read()) != -1) {
				bos.write(count);
			}
			millisecond = System.currentTimeMillis()-millisecond;
			System.out.println("\n복사에 "+millisecond+"밀리초 걸렸습니다");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		try(InputStream fis = new FileInputStream("c:/DailyJava2/A.zip");
				OutputStream fos = new FileOutputStream("c:/DailyJava2/A1.zip");
				BufferedInputStream bis = new BufferedInputStream(fis);
				BufferedOutputStream bos = new BufferedOutputStream(fos);){
			
			millisecond = System.currentTimeMillis(); // 파일 읽어오는 시간 체크하는 메서드
			int count ;
			while((count = bis.read()) != -1) {
				bos.write(count);
			}
			millisecond = System.currentTimeMillis()-millisecond;
			System.out.println("\n복사에 "+millisecond+"밀리초 걸렸습니다");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}

}
