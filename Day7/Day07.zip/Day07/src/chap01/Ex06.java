package chap01;

import java.util.ArrayList;

class Test3 extends Thread{
	int seq;
	Test3(int seq){
		this.seq = seq;
	}
	public void run() { 
		System.out.println(seq+"thread start");
		
		try {
		Thread.sleep(1000); // 1초 대기
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println(seq+"thread end");

	}
	
}

public class Ex06 {
	public static void main(String[] args) {
		ArrayList<Thread> threads = new ArrayList<Thread>();

		for(int i = 0 ; i <10;i++) { // 10 개 생성하여 담음 >> 랜덤한 순서대로 생성,종료됨
			Thread t= new Test3(i);
			t.start(); // run( ) 이 실행됨
			threads.add(t);
		}
		
		for(int i =0;i<10;i++) {
			Thread t = threads.get(i);
			try{
				t.join(); // thrad 가 다 종료될때가지 대기하는 메서드
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("main end"); // thread 가 다 종료되기 이전에 메인 메서드가 먼저 끝나버린다
		
	}

}
