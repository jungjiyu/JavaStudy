package chap01;

class Test1 extends Thread{
	
	public void run() { 
		System.out.println("dfsfsdf");
		}
}

public class Ex4 {
	public static void main(String[] args) {
		Test1 t1 = new Test1();
		t1.start(); // run( ) 이 실행됨
	}

}
