package chap01;

import java.io.*;

public class Ex01 {
	public static void main(String[] args) {

		long millisecond = 0;
		
		try(InputStream fis = new FileInputStream("c:/DailyJava2/A.zip");OutputStream fos = new FileOutputStream("c:/DailyJava2/A1.zip")){
			
			int count ;
			byte[] ary = new byte[10000];
			
			while((count = fis.read(ary)) != -1) {
				millisecond = System.currentTimeMillis(); // 파일 읽어오는 시간 체크하는 메서드
				fos.write(ary);
				
				millisecond = System.currentTimeMillis()-millisecond;
				System.out.println(count+"개의 자료를 읽어왔습니다");
				System.out.println("복사에 "+millisecond+"밀리초 걸렸습니다");

						
			}
			
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
		try(InputStream fis = new FileInputStream("c:/DailyJava2/A.zip");OutputStream fos = new FileOutputStream("c:/DailyJava2/A1.zip")){
			millisecond = System.currentTimeMillis(); // 파일 읽어오는 시간 체크하는 메서드
			int count ;			
			while((count = fis.read()) != -1) {
				fos.write(count);
				
			}
			millisecond = System.currentTimeMillis()-millisecond;
			System.out.println("\n복사에 "+millisecond+"밀리초 걸렸습니다");
			
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
		
	}

}
