package chap01;

import java.io.*;

public class Ex3 {
	public static void main(String[] args) {
		// data.txt 로 데이터 꺼내와서 출력
		
		try(InputStream fis = new FileInputStream("c:/DailyJava2/A.zip");OutputStream fos = new FileOutputStream("c:/DailyJava2/A1.zip");DataInputStream dis = new DataInputStream(fis); DataOutputStream dos = new DataOutputStream(fos)){
			long millisecond = System.currentTimeMillis(); // 파일 읽어오는 시간 체크하는 메서드
			int count ;
			while((count = dis.readByte()) != -1) {
				dos.write(count);
			}
			millisecond = System.currentTimeMillis()-millisecond;
			System.out.println("\n복사에 "+millisecond+"밀리초 걸렸습니다");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	
		try(OutputStream fos = new FileOutputStream("c:/DailyJava2/writer.txt");DataOutputStream dos = new DataOutputStream(fos)){
			
			//dos.write(10);
			dos.writeUTF("ememememme");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		/*
		try(InputStream fis = new FileInputStream("c:/DailyJava2/data.txt");DataInputStream dis = new DataInputStream(fis)){
		//	System.out.println(dis.readInt());
			System.out.println(dis.readUTF());
			
		}catch(IOException e) {
			e.printStackTrace();
		
		}
		
		*/
		
		
	}

}
