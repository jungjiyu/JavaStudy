package com.java.servlet6;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
@WebServlet(
		urlPatterns= {"/Param"},
		initParams= {
				@WebInitParam(name="id",value="hong")
		})
*/		
public class ParamInital extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	ServletConfig config = getServletConfig(); // 서블릿이 초기화 되는 동안 참조해야할 정보를 가지고 있다가 전달해주는 역할
	String id =config.getInitParameter("id");
	String pw =config.getInitParameter("pw");
	System.out.println(id+","+pw);
	
	PrintWriter pww =  response.getWriter() ;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
