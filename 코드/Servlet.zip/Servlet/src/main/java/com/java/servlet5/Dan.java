package com.java.servlet5;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Dan")
public class Dan extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter(); 
		
		int num = Integer.parseInt(request.getParameter("dan"));
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		
		out.print("<head>");
		out.print("<title>GUGU</title>");
		out.print("</head>");
		
		out.print("<body>");
		out.print("<h2>구구단"+num+"단"+"</h2>");
		if(num<2 || 9<num) {
			out.print("<p>제대로 입력하세요.</p>");
		}
		else{
			for(int i = 0; i<9;i++) {
		
			out.print("<p>"+(i+1)+"*"+num+"= "+((i+1)*num)+"</p>");
		}
		}
		out.print("</body>");
		out.print("</html>");
		out.close();
		
		
		
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
