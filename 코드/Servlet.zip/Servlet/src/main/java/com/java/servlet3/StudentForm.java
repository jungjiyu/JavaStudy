package com.java.servlet3;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


 @WebServlet(
	urlPatterns= {"/Student"},
	initParams= {
		@WebInitParam(name="host",value="jiyu")
	}
)


public class StudentForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public StudentForm() {
        super();
        System.out.println("StudentForm 객체가 만들어졌습니다");
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost 메서드 실행");
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		// studentID, name , age , tel, major, circle[checkbox], action = 따로 만들어라 
		String studentId= request.getParameter("stduentID");
		String name= request.getParameter("name");
		String age= request.getParameter("age");
		String tel= request.getParameter("tel");
		String major= request.getParameter("major");
		String[] circles= request.getParameterValues("circle");
		
		PrintWriter out = response.getWriter();
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		
		out.print("<head>");
		out.print("<title>MemberInfo</title>");
		out.print("</head>");
		
		out.print("<body>");
		out.print("<h2>학생인적사항</h2>");
		out.print("<img src=\"trump.jpg\" alt=\"your face\" title=\"your face\"><br>");
		out.print("<p>이름:"+name+"</p>");
		out.print("<p>나이:"+age+"</p>");
		out.print("<p>전화번호:"+tel+"</p>");
		out.print("<p>학번:"+studentId+"</p>");
		out.print("<p>전공:"+major+"</p>");
		out.print("<p>동아리:"+Arrays.toString(circles)+"</p>");
		out.print("</body>");
		out.print("</html>");
		out.close();
        System.out.println("특정 서블릿의 초기 파라미터: "+ getInitParameter("host"));
        System.out.println("모든 서블릿이 공유하는 초기 파라미터: "+ getInitParameter("host"));

		
	}

}
