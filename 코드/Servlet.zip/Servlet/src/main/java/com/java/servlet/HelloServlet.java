package com.java.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

@WebServlet("/Hello") 
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L; // 직렬화 키 라는 것으로, 역직렬화할때 체크하는데 쓰인다. 없어도 상관 없긴 하다
														// 직렬화 >> 자바 객체를 바이트  로 변환해서 저장하는것
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// request :클라이언트로부터의 요청 처리 객체
			//ex) 클라이언트의 아이디와 비밀번호 정보는 reuqest 객체에 담겨져온다
		
		//response: 클라이언트의 응답 처리 객체
			//ex) 회원인지 아닌지 정보를 클라이언트에게 보냄
		
		response.setCharacterEncoding("UTF-8"); // 해당 문서를 utf-8로 인코딩하여 웹 브라우져에게 전송한다 
		response.setContentType("text/html; charset=UTF-8"); // 웹 브라우져에게 html 문서를 utf-8로 해석하란 소리

		
		//웹 브라우져 에거 출력하기 위한 출력 스트림 객체 얻기
		PrintWriter out = response.getWriter();
		// html 방식으로 출력해야도니다ㅣ
		out.print("<!DOCTYPE HTML>");
		out.print("<html>");
		out.print("<head>");
		out.print("<title>서블릿 시작</title>");
		out.print("</head>");
		out.print("<body>");
		out.print("<h1>장충동 왕족발 보싸암</h1>");
		out.print("</body>");
		out.print("</html>");
		
		out.close();
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
