package com.java.servlet4;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration; // iterator 의 이전 버전
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Student2")
public class StudentForm2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost 메서드 실행");
		request.setCharacterEncoding("UTF-8");
	//	response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		// studentID, name , age , tel, major, circle[checkbox], action = 따로 만들어라 
		
		Enumeration<String> enumeration = request.getParameterNames(); // ctrl+shift+ 영문??
		// hasMoreElements >> 더 읽어올거 있음 true 반환
		// nextElement >> 일거온다
		while(enumeration.hasMoreElements()) { 
			String[] values = request.getParameterValues(enumeration.nextElement());
			System.out.println(Arrays.toString(values));
		}
		
		String studentId= request.getParameter("stduentID");
		String name= request.getParameter("name");
		String age= request.getParameter("age");
		String tel= request.getParameter("tel");
		String major= request.getParameter("major");
		String[] circles= request.getParameterValues("circle");
		
		PrintWriter out = response.getWriter();
		out.print("으아악");
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		
		out.print("<head>");
		out.print("<title>MemberInfo</title>");
		out.print("</head>");
		
		out.print("<body>");
		out.print("<h2>학생인적사항</h2>");
		out.print("<img src=\"trump.jpg\" alt=\"your face\" title=\"your face\"><br>");
		out.print("<p>이름:"+name+"</p>");
		out.print("<p>나이:"+age+"</p>");
		out.print("<p>전화번호:"+tel+"</p>");
		out.print("<p>학번:"+studentId+"</p>");
		out.print("<p>전공:"+major+"</p>");
		out.print("<p>동아리:"+Arrays.toString(circles)+"</p>");
		out.print("</body>");
		out.print("</html>");
		out.close();
		
	}

}
