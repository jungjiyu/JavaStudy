package com.java.servlet2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/MemberForm")
public class MemberForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=utf-8");
		
		
		System.out.println("doPost 메서드임");
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String[] hobbies = request.getParameterValues("hobby");
		
		System.out.println("입력받은 정보");
		System.out.println("이름: "+name);
		System.out.println("나이: "+age);
		System.out.println("id: "+id);
		System.out.println("pw: "+pw);
		System.out.print("취미:"+Arrays.toString(hobbies));
	
		
		PrintWriter out = response.getWriter();
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		
		out.print("<head>");
		out.print("<title>MemberInfo</title>");
		out.print("</head>");
		out.print("<body>");
		out.print("id:"+id+"<br>");
		out.print("이름:"+name+"<br>");
		out.print("취미:"+Arrays.toString(hobbies)+"<br>");
		out.print("</body>");
		out.print("</html>");
		out.close();
	}

}
