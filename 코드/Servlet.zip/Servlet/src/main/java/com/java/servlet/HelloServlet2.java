package com.java.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/getPost")
public class HelloServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet메서드임");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		System.out.println("입력받은 정보) id: "+id+", pw:"+pw);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		System.out.println("doPost 메서드임");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		System.out.println("입력받은 정보) id: "+id+", pw:"+pw);
	}

}
