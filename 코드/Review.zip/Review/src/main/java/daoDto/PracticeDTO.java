package daoDto;

public class PracticeDTO {
	private String myName = null;
	public PracticeDTO(){}
	public PracticeDTO(String myName){
		this.myName = myName;
	}
	public String getMyName() {
		return myName;
	}
	public void setMyName(String myName) {
		this.myName = myName;
	}
	
	

}
