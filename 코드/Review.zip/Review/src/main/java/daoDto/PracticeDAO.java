package daoDto;

public class PracticeDAO {

}
