package bean;

public class BeanEx {
	// 생성자와 getter setter 를 제외한 모든건 private
	private int age = 10;
	private String name = "hong";
	
	public BeanEx(){ // 기본생성자		
		System.out.println("bean 객체 생성");
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
