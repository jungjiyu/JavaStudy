package bean;

public class loginInfo { // 자바빈
	
	private String id;
	private String pw;
	
	public loginInfo() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}
	
	

}
