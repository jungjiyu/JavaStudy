<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h2> page 2</h2>
<%
out.print("page2 시작<br>");


// 같은 request 객체를 공유하는지 알아보기 위함
int num  = (int)request.getAttribute("num");
out.print("request 객체에 저장됬었던 객체: "+num+"<br>");
// out.print("page1에서 선언됬었던 변수 : "+a+"<br>"); 

%>

<%
out.print("page2 끝<br>");

%>
</body>
</html>