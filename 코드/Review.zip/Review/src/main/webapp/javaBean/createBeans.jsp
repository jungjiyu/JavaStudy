<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Bean</title>
</head>
<body>

	<%-- 빈 생성 --%>
	
	<jsp:useBean id="bean1" class="bean.BeanEx" scope="page"/>
	<jsp:setProperty name="bean1" property="age" value="25"/>
	<p><jsp:getProperty name="bean1" property="age"/></p>
	<p><jsp:getProperty name="bean1" property="name"/></p>
	<%
	
	
	
	
	
	
	
	%>
</body>
</html>