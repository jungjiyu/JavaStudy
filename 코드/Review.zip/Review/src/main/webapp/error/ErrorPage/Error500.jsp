<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ page isErrorPage="true" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>에러 500</title>
</head>
<body>
<% response.setStatus(200); %>
<h2>에러 500</h2>
</body>
</html>