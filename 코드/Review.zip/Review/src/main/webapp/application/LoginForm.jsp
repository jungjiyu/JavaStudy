<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>로그인창</title>
</head>
<body>
	<form action="Redirect.jsp" method="post">
		<fieldset>
			<legend>NAVER</legend>
		<P><label>아이디:<input type="text" name="id"></label></p>
		<P><label>비밀번호<input type="text" name="pw"></label></p>
		<input type="submit" value="로그인">
		</fieldset>
	</form>

</body>
</html>