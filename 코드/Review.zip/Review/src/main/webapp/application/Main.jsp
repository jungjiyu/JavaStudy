<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Main</title>
</head>
<body>
	<%@include file="LoginStatusCheck.jsp"%>
	
	<%
		if(flag){response.sendRedirect("LoginForm.jsp");}
	%>
	
	<p><img src="images/cat.gif"></p>
	<p>JsessionID: <%=session.getId()%></p>
	<a href="Logout.jsp">로그아웃</a>	
	
</body>
</html>