<%@page import="java.util.Enumeration"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>loginCheck</title>
</head>
<body>
	<%
	//세션 객체에 저장한 것들 모두 가져오기
	
	boolean flag = true;
		
	if(application.getAttribute("loginStatus") != null){
		flag= false;
	
}
	
	
	%>

</body>
</html>