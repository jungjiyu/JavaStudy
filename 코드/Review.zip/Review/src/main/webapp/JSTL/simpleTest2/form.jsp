<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>문제</title>
</head>
<body>
	<form action="resultPage.jsp" method="post">
		<fieldset>
			<legend>다음 문제의 답은? (5점)</legend>
			<%
			int a = (int)(Math.random()*10) +1;
			int b = (int)(Math.random()*10) +1;
			
			session.setAttribute("a",a);
			session.setAttribute("b",b);
			%>
			<p><c:out value="${a}${'+'}${b}${'='}"/><input type="text" name="answer"></p>
			<input type="submit" value="제출">
		 
		</fieldset>
	</form>

</body>
</html>