<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>정답</title>
	<c:if test="${param.answer == (sessionScope.a + sessionScope.b) }">
		<c:out value="정답입니다!"/>
	</c:if>
	
	<c:if test="${param.answer != (sessionScope.a + sessionScope.b) }">
		<c:out value="정답이 아닙니다!"/>
	</c:if>
	<input type="button" onclick="goBack( )" value="되돌아가기">
	
	<%
	out.print(session.getAttribute("a"));
	
	%>
	
	<script>
		function goBack(){
			history.back();
		}	
	</script>
</head>
<body>

</body>
</html>