<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
 <%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>page01</title>
</head>
<body>
	<c:set var="num" value="100"/>
	<c:out value="${pageScope.num}"></c:out>  <br>
	
	<c:set var="num1" value="10" scope="application"/>
	<c:out value="${applicationScope.num1}"></c:out> <br>
	
	<c:set var="num2" value="0" scope="request"/>
	<c:out value="${requestScope.num2}"></c:out> <br>


	
	<c:forEach var="i" begin="0"  end="20" step="1">
		<c:out value="${i+num}"/>	
	</c:forEach>
	
	<%
	int[] ary = {1,2,3,4};
	ArrayList<Integer> aryList= new ArrayList<Integer>();
	aryList.add(1);
	aryList.add(2);
	aryList.add(3);
	
	pageContext.setAttribute("numbers", ary);
	pageContext.setAttribute("numberss", aryList);
	%>
	<%-- 향상된 for 문 --%>
	<c:forEach var="ii" items="${pageScope.numbers}"> 
		<c:out value="${ii}"/><br>	
	</c:forEach>
	

</body>
</html>