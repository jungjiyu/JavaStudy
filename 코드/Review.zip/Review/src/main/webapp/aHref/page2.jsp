<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
param.myName>> :<c:out value="${param.myName}"/><br>
myName>> :<c:out value="${myName}"/><br>

<%
String id = request.getParameter("myName");
out.print("getParameter 로 받은 일반적인 필드값:"+id+"<br>");


String dto = request.getParameter("dto");
out.print("getParameter 로 받은 dto값:"+dto);
%>

</body>
</html>