<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
String pastSessionId = session.getId();
out.print( session +"<br>");

session.invalidate();
HttpSession currentSession = pageContext.getSession();
String currentSessionId = currentSession.getId();
HttpServletRequest currentRequest = (HttpServletRequest)pageContext.getRequest();


out.print( currentSession +"<br>");
out.print(  currentRequest  +"<br>");
out.print( currentSessionId +"<br>");
out.print(  pastSessionId +"<br>");

%>

</body>
</html>