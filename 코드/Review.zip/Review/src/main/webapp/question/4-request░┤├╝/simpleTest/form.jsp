<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>문제</title>
</head>
<body>

	<%-- 
		
		request 객체의 소멸 시점?
			: forward 혹은 include 를 통한 페이지 전환이 아닌 이상 페이지 전환 될때마다 request 객체는 새로 생성 되는거임?
			
		이전 페이지에서 request 객체에 바인딩 시킨 attribute 가 
		form 의 submit 을 통한 웹 페이지 전환했을때 
		다음 페이지에서 null 로 나옴 

		--%>
	<form action="resultPage.jsp" method="post">
		<fieldset>
			<legend>다음 문제의 답은? (5점)</legend>
			<%
			int a = (int)(Math.random()*10) +1;
			int b = (int)(Math.random()*10) +1;
			
			request.setAttribute("a",a);
			request.setAttribute("b",b);
			%>
			<p><c:out value="${a}${'+'}${b}${'='}"/><input type="text" name="answer"></p>
			<input type="submit" value="제출">
		 
		</fieldset>
	</form>

</body>
</html>