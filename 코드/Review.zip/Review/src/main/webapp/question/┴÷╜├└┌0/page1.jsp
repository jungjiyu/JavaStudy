<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<%
out.print("page1 시작<br>");



// 같은 request 객체를 공유하는지 알아보기 위함
request.setAttribute("num",10);
int a = 9;
%>
<%@include file="page2.jsp"%>
<%@include file="page3.jspf" %>
<%
out.print("page1 끝<br>");

%>
</body>
</html>