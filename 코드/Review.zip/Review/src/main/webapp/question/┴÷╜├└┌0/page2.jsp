<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
out.print("page2 시작<br>");


// 같은 request 객체를 공유하는지 알아보기 위함
int num  = (int)request.getAttribute("num");
out.print("request 객체의 속성으로 저장됬었던 값: "+num+"<br>");
// out.print("page1에서 선언됬었던 변수 : "+a+"<br>");  << 실행에 문제가 있진 않고, 걍 이클립스가 멍청해서 그런거다

%>

<%
out.print("page2 끝<br>");

%>
</body>
</html>