<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>p1</title>
</head>
<body>
<jsp:useBean id="bean" class="bean.loginInfo" scope="application"/>
<jsp:setProperty name="bean" property="id" value="hong"/>
<jsp:setProperty name="bean" property="pw" value="1234"/>


<jsp:getProperty name="bean" property="id" /><br>
<jsp:getProperty name="bean" property="pw" />

<p><a href="page2.jsp">이동</a></p>


</body>
</html>