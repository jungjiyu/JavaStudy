<%@page import="bean.loginInfo"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>p2</title>
</head>
<body>


<%-- 
<jsp:getProperty name="bean" property="id" /><br>
<jsp:getProperty name="bean" property="pw" />

--%>
<%
loginInfo ins = (loginInfo)application.getAttribute("bean");
out.print(ins.getId());
%>

</body>
</html>