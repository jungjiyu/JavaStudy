
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<p>다음페이지로 이동하시겠습니까?</p>
	<input type="button" onclick="goNext()" value="yes">
	<input type="button" onclick="goBack()" value="no">

<script>
	function goNext(){
			alert('이동성공');
			//window.location = 'Page2.jsp' ; 
	<%
		response.sendRedirect("Page2.jsp");
	%>
		
	}
</script>




</body>
</html>