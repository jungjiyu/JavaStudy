<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
session.setAttribute("aN","sV");
application.setAttribute("aN","aV");
request.setAttribute("rN","rV");
session.setAttribute("sN","sV");
pageContext.setAttribute("pN","pV");

%>

requestScope.rN: ${requestScope.rN }<br> 
requestScope.paramN: ${requestScope.paramN }<br> <%-- request 객체의 param 값은 못구하는 듯 --%>
param.paramN : ${param.paramN }<br>


</body>
</html>