<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
session.setAttribute("aN","sV");
application.setAttribute("aN","aV");
request.setAttribute("rN","rV");
session.setAttribute("sN","sV");
pageContext.setAttribute("pN","pV");


%>

${aN }<br> <%-- application 에서 보다 session 에서 먼저 찾음 --%>
${rN }<br>
${pN }<br>
${sN }<br>

<form action="page2.jsp" method="post">
아무 값이나 입력:<input type="text" name="paramN"><br>
<input type="submit">

</form>

</body>
</html>