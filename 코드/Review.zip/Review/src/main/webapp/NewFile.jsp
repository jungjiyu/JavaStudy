<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
Cookie[] cookies = request.getCookies();
for(int k = 0 ; k < cookies.length ; k++){
	String sName = cookies[k].getName() ;
	out.print(sName+" ");
		
	}
%>

</body>
</html>