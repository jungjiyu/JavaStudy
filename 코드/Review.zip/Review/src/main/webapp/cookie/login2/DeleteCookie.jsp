<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>DeleteCookie</title>
</head>
<body>

<%
	Cookie[] cookies = request.getCookies();
	boolean flag = true;
	for(int i = 0 ; i <cookies.length;i++){
		 
		if(cookies[i].getName().equals("loginResult") && cookies[i].getValue().equals("success")  ){
			cookies[i].setMaxAge(0);
		//	cookies[i].setPath("/Review/cookie/login2"); // URI 로 접근 경로 설정
			response.addCookie(cookies[i]);
			out.print("loginResult 쿠키가 삭제되었습니다<br>");
			response.sendRedirect("MainPage.jsp");
		}
	}

	
	%>	

</body>
</html>