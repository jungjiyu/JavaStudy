<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>LoginSuccess</title>
</head>
<body>
	<% 
	Cookie cookie = new Cookie("loginResult","success");
	cookie.setMaxAge(60*60); // 1시간
	//cookie.setPath("/Review/cookie/login2"); // URI 로 접근 경로 설정
	cookie.setPath("/");
	response.addCookie(cookie);
	
	response.sendRedirect("MainPage.jsp");
	%>

</body>
</html>