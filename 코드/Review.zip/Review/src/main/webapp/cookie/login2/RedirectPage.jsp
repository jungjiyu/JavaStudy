<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Redirect</title>
</head>
<body>
	<%
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String pw =request.getParameter("pw");
		
		if(id.equals("hong") && pw.equals("1234")){
			response.sendRedirect("LoginSuccessPage.jsp");
		}else{
			response.sendRedirect("LoginFailPage.jsp");
		}
	
	
	%>

</body>
</html>