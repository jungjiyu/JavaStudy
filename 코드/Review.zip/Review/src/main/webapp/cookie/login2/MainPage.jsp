<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Naver</title>
</head>
<body>

	
	
	<!-- 로그인 되있는지 확인하기 -->
	<%

	
	
	Cookie[] cookies = request.getCookies();
	boolean flag = true;
	if(cookies!=null){
	for(int i = 0 ; i <cookies.length;i++){
		
		if(cookies[i].getName().equals("loginResult") && cookies[i].getValue().equals("success") ){
			out.print("naver에 로그인 된 상태입니다<br>");
			out.print("쿠키는 해당 경로에서 유효합니다: "+cookies[i].getPath());
			flag=false;
			break;
		}
	}
	}
	
	if(flag){// 로그인 성공 안한 상태
		response.sendRedirect("FormPage.jsp");
	}
	%>	
		
	<!--  로그인 되있을 경우 -->
	<p><img src="images/cat.gif"></p>
	
	<a href="DeleteCookie.jsp">로그아웃</a>		

	
</body>
</html>