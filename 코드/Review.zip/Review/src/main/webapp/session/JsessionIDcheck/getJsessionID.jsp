<%@page import="java.util.Calendar"%>
<%@page import="java.util.Date"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>getJsessionID</title>
</head>
<body>
<%

	String id = session.getId();
	long bornTime = session.getCreationTime(); //ms 단우;
	out.print("sessionID: "+id+"<br>");
	out.print("born time: "+ new Date(bornTime)+"<br>");


%>

</body>
</html>