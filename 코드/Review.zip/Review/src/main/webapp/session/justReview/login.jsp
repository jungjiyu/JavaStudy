<%@page import="bean.loginInfo"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>로그인 창</title>
</head>
<body>



<jsp:useBean id="online" class="bean.loginInfo" scope="application" />
<jsp:setProperty name="online" property="*" /> 
	

<jsp:getProperty name="online" property="id"/><br>
<jsp:getProperty name="online" property="pw"/>


	
	
	<%
	
	// 방문자수 집계
	int count =0;
	if( application.getAttribute("count") != null){
	count = (int)application.getAttribute("count");
	}
	count++;
	application.setAttribute("count",count);
	
	
	// 세션 객체의 속성으로 자바빈 객체 추가
	session.setAttribute("visitor",online);
	response.sendRedirect("main.jsp");
	
	%>
	
</body>
</html>