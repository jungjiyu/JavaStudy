<%@page import="java.util.Enumeration"%>
<%@page import="bean.loginInfo"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>main</title>
</head>
<body>


<script>
	function toForm(){
	window.location="logout.jsp";
	return;
	}
</script>

<%

if(session.getAttribute("visitor")==null){
	response.sendRedirect("loginform.jsp");
}


else{

out.print("현재 이용자수: "+application.getAttribute("count")+"<br>");
loginInfo lInfo =  (loginInfo)session.getAttribute("visitor");
out.print("id: "+lInfo.getId()+"<br>");
out.print("pw: "+lInfo.getPw()+"<br>");
out.print("JsessionID: "+session.getId()+"<br>");
}

%>



<p><a href="logout.jsp">로그아웃</a></p>
<input type="button" onclick="toForm()" value="로그아웃-javascript">


</body>
</html>