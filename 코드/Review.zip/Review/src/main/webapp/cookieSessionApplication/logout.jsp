<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>logout</title>
</head>
<body>

<%
// 이용자 수 감소시킴
	int count = 0 ;
	if(application.getAttribute("count")!=null){
		count = (int) application.getAttribute("count");
		out.print(count+"<br>");
	}
	application.setAttribute("count",count-1);
	
	session.invalidate();
	response.sendRedirect("loginform.jsp");
%>
</body>
</html>