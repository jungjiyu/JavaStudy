<%@page import="java.util.Enumeration"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<script>
	function popupReq(){
		window.close();
		window.location = "CreateCookie.jsp";
	}
</script>


<img src="images/wally.png" width="200">
<form>
<input type="button" value="24시간 동안 팝업 띄우지 않기" onclick="popupReq()">
</form>



</body>
</html>