<%@page import="java.util.Enumeration"%>
<%@page import="bean.loginInfo"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>main</title>
</head>
<body>

<%-- 팝업창 관련 --%>
<% 
Cookie[] cookies = request.getCookies();
boolean flag = true;

for(int i= 0 ; i <cookies.length;i++){
	if(cookies[i].getName().equals("notice") && cookies[i].getValue().equals("dontShow")){
		flag=false;
		break;
	}
}
 if(flag){ %>
<script>
	window.open("popup.jsp" , "wally" , "width=300, height=400");
</script>

<% }%>



<script>
	function toForm(){
	window.location="logout.jsp";
	return;
	}
</script>

<%
// visitor 객체가 존재하지 않는 상태면(== 로그인 안된 상태면)
if(session.getAttribute("validUser")==null){
	response.sendRedirect("loginform.jsp");
}



else{ // visitor 객체가 존재한다면(== 로그인된 상태라면)

out.print("현재 접속자수: "+application.getAttribute("count")+"<br>");
loginInfo lInfo =  (loginInfo)session.getAttribute("validUser");
out.print("id: "+lInfo.getId()+"<br>");
out.print("pw: "+lInfo.getPw()+"<br>");
out.print("JsessionID: "+session.getId()+"<br>");
}

%>
<input type="button" onclick="toForm()" value="로그아웃"> 




</body>
</html>