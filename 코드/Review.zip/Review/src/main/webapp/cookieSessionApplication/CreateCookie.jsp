<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>CreateCookie</title>
</head>
<body>
<%
	Cookie cookie = new Cookie("notice","dontShow");
	cookie.setMaxAge(60*60*24);
	response.addCookie(cookie);


%>

</body>
</html>