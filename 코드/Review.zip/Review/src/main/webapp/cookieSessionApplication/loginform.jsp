<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>login</title>

<style>
	table{
		text-align:center;
		margin:0 auto;
		color:red;
	}
</style>
</head>


<body>
<form action="login.jsp" method="post">
	<table border="1">
		<caption>로그인폼</caption>
		<tr>
			<th>아이디:</th>
			<td><input type="text" name="id"></td>
			<td rowspan="2"><input type="submit" value="로그인"></td>
		</tr>
		<tr>
			<th>비밀번호:</th>
			<td><input type="password" name="pw"></td>
		</tr>
	</table>
	
	
</form>
</body>
</html>