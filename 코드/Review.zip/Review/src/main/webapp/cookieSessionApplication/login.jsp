<%@page import="java.util.ArrayList"%>
<%@page import="bean.loginInfo"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>로그인 창</title>
</head>
<body>


<%-- request 객체로 받은 속성값( id , pw )을 자바빈 객체에 저장 --%>
<jsp:useBean id="online" class="bean.loginInfo" />
<jsp:setProperty name="online" property="*" /> 
	
	
	<%
	
	// 이용자수 집계
	int count =0;
	if( application.getAttribute("count") != null){
	count = (int)application.getAttribute("count");
	}
	count++;
	application.setAttribute("count",count);
	
	
	ArrayList<HttpSession> currentSessions = (ArrayList<HttpSession>)application.getAttribute("currentSessions");
	
	for(int i=0;i<currentSessions.size();i++){
		// 현재 해당 브라우져의 다른 탭에서 로그인 성공 상태인데 현재 탭에서 로그인 한 상태라면
		HttpSession s = currentSessions.get(i);
		String sId = s.getId();
		if(sId.equals(session.getId())){ 
		%>
		<jsp:include page="logout.jsp"/>
		
		<%
		
		
		break;
		}
	}
	%>
	
	
	<%
	
	session = request.getSession();
	session.setAttribute("validUser",online);
	application.setAttribute("currentSessions",session);
	response.sendRedirect("main.jsp");
	
	%>
	
</body>
</html>