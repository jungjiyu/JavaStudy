package practice;

public class ClassDTO { // Data Transfer Object << 자바빈
	private String nameXX ;
	private String ageXX ;
	private String emailXX ;
	
	public ClassDTO() {
		
	}

	public String getNameXX() {
		return nameXX;
	}

	public void setNameXX(String nameXX) {
		this.nameXX = nameXX;
	}

	public String getAgeXX() {
		return ageXX;
	}

	public void setAgeXX(String ageXX) {
		this.ageXX = ageXX;
	}

	public String getEmailXX() {
		return emailXX;
	}

	public void setEmailXX(String emailXX) {
		this.emailXX = emailXX;
	}

}
