package practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ClassDAO { // Data Access Object
	
	private static String driver="oracle.jdbc.OracleDriver";
	private static String dbURL = "jdbc:oracle:thin:@localhost:1521:xe"; 
	private static String dbID="C##JAVAUSER";
	private static String dbPW="java2024";
	
	private static Connection conn;
	private static PreparedStatement pstmt;
	private static ResultSet rs;
	
	private static ClassDAO instance = new ClassDAO();

	private ClassDAO() {
		// 드라이버를 로딩해놓음
		try {
		Class.forName(driver);
		}catch(Exception e) {e.printStackTrace();}
	}
	
	public static ClassDAO getInstance() {
		return instance;
	}
	
	
	
	public static ArrayList<String>  getNameList() {
		String query = "SELECT nameXX from YayTest";
		ArrayList<String> result = new ArrayList<String>();
		
		try {
			
			conn = DriverManager.getConnection(dbURL, dbID, dbPW);
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				result.add(rs.getString("namexx"));
			}
			
		}catch(Exception e) { e.printStackTrace();}finally {
			try {
				if(rs == null )rs.close();
				if(pstmt == null )pstmt.close();
				if(conn == null )conn.close();
			}catch(Exception e) {e.printStackTrace();}
			
		}
		
		return result;
		
	}
}
