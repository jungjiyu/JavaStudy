package com.jsp.member;

import java.sql.Timestamp;

public class memberDTO {
	// DTO == Data Transfer Object
		// 계층간 데이터 교환을 위한 자바빈 객체
		// db 와 데어터 교환을 해야하므로 타입을 일치시켜줘야된다
	
	private String id;
	private String pw;
	private String name;
	private String email;
	private String address;
	private Timestamp regDate; // java.sql.Timestamp 따로 import 필요
	
	
	

	public memberDTO(String id, String pw, String name, String email, String address, Timestamp regDate) {
		super();
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.email = email;
		this.address = address;
		this.regDate = regDate;
	}


	public memberDTO() {
		System.out.println("memberDTO 객체가 생성되었습니다");
	}
	
	
	
	public Timestamp getRegDate() {
		return regDate;
	}


	public void setRegDate(Timestamp regDate) {
		this.regDate = regDate;
	}


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}



}
