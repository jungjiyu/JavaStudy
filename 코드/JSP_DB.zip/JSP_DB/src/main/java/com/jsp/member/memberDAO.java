package com.jsp.member;

import java.sql.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

//DAO == 데이터에 ㅈ접근 위한 객체
public class memberDAO {
	
	// DAO : Data Access Object . db 의 데이터에 접근하여 CRUD 을 처리하는 객체
	private DataSource ds;
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
///	 사실 DataSource 준비해놨음 필요 없다 아래 4가지 정보는
	private String driver="oracle.jdbc.OracleDriver";
	private String dbURL = "jdbc:oracle:thin:@localhost:1521:xe"; 
	private String dbID="C##JAVAUSER";
	private String dbPW="java2024";
	
	// 싱글톤패턴구현
	private static memberDAO instance = new memberDAO();
	
	private memberDAO() {
		try {
			Context context =new InitialContext();
			ds = (DataSource)context.lookup("java:comp/env/jdbc/oracle"); // 이름으로 해당하는 객체를 얻을 수 있다
			//반환 타입이 obj 임
		}catch(Exception e) {e.printStackTrace();}
	}
	
	private void close(ResultSet rs , PreparedStatement pstmt, Connection conn ) {
		try{
			if(rs!= null) rs.close();
			 if (pstmt != null) pstmt.close();
			 if (conn != null) conn.close();
		}catch(Exception e){}
	}
	
    public static memberDAO getInstance() {
        return instance;
    }
    
    // 회원관리
    	// 기능 1. 회원가입 2. 로그인 3. 로그아웃 4. 회원보기 5. 회원정보수정 6.회원탈퇴
    		// 3 번 기능 뺴고는 모두 db 와의 연동이 필요하다
    
      //회원가입
    	// 테이블에서  회원의 아이디가 같은 아이디가 존재하는지 확인해주는 메서드
    public boolean idCheck(String id) {
    	boolean result = false;
    	String query = "SELECT ID FROM KGMEMBER WHERE ID=?";
    	
    	try {
    		
    		conn = ds.getConnection();
    		pstmt = conn.prepareStatement(query);
    		pstmt.setString(1,id);		
    		rs = pstmt.executeQuery();
    		
    		// if(rs != null) result = true;   
    	if(rs.next()) {
    		result = true; 
    		System.out.println("아이디 중복문제로 insert 싪패"+ rs.getString("id"));
    	}
    	
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);
    		    		
    	}
    	return result;
    }
    
    
    
    	// 회원 가입 폼에서 넘어온 데이터를 테이블에 insert 하는 메서드
    public int insertMember(memberDTO dto) {
    	int result = 0 ;
    	String query = "INSERT INTO KGMEMBER(ID, PW, NAME, EMAIL, ADDRESS) VALUES (?,?,?,?,?)";
    	try {
    		Class.forName(driver);
    		conn = DriverManager.getConnection(dbURL,dbID,dbPW);
    		pstmt = conn.prepareStatement(query);
    		pstmt.setString(1,dto.getId());		
    		pstmt.setString(2,dto.getPw());		
    		pstmt.setString(3,dto.getName());
    		pstmt.setString(4,dto.getEmail());
    		pstmt.setString(5,dto.getAddress());
    		result = pstmt.executeUpdate();
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		try{
        		close(rs,pstmt,conn);
    		}catch(Exception e){}
    		    		
    	}
    	return result;
    }
  

   
    // 로그인
    	// 아이디와 비밀번호가 맞는지 확인ㄴ해주는 ㅔㅁ서드
    		// 둘 중 하나가 틀린 . 둘다 틀린
    			// 아이디가 틀린 >> -1 , 아이디가 맞고 비밀번호는 틀릭 > 0 , 아이디가 맞고 비밀번호도 맞는 > 1

    
    public int loginCheck(String id , String pw) {
    	int result = -1 ;
    	String query = "SELECT PW FROM KGMEMBER WHERE ID=?";
    	try {
    		Class.forName(driver);
    		conn = DriverManager.getConnection(dbURL,dbID,dbPW);
    		pstmt = conn.prepareStatement(query);
    		pstmt.setString(1,id);
    		rs = pstmt.executeQuery();
    		
    		if(rs.next()) {    		
    			System.out.println(id+" 맞음");
    			result = 0;
    			
    			String tmpPw = rs.getString("pw");
    			if(tmpPw.equals(pw)) {
    				System.out.println(pw+" 맞음");
    				result = 1;
    			}
    			
    		}
    		
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);    		    		
    	}
    	return result;
    }

   
    
    // 회원 정보	
    	// 정보 얻는 메서드
    		// dto 객체를 반환한다
    public memberDTO getMember(String id) {
    	memberDTO dto = null;
    	
    	String query = "SELECT * FROM KGMEMBER WHERE ID=?";
    	
    	try {
    		Class.forName(driver);
    		conn = DriverManager.getConnection(dbURL,dbID,dbPW);
    		pstmt = conn.prepareStatement(query);
    		pstmt.setString(1,id);
    		rs = pstmt.executeQuery();
    		
    		if(rs.next()) {    		
  
    			dto = new memberDTO();
    			dto.setId(rs.getString("id"));
    			dto.setPw(rs.getString("pw"));
    			dto.setName(rs.getString("name"));
    			dto.setEmail(rs.getString("email"));
    			dto.setAddress(rs.getString("address"));	
    			dto.setRegDate(rs.getTimestamp("regDate"));	
    		
    			
    		}
    		
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);

    	}
    	
    	
    	return dto;
    }
    
  
    // 회원정보수정
    	// 비밀번호, 이메일 정보 수정하는 메서드
    public int modifyMember(memberDTO dto) {
    	int result = 0;

    	String query = "UPDATE KGMEMBER SET pw=?, email=?, address=? WHERE id=?";
    	
    	try {
    		Class.forName(driver);
    		conn = DriverManager.getConnection(dbURL,dbID,dbPW);
    		pstmt = conn.prepareStatement(query);
    		pstmt.setString(1,dto.getPw());
    		pstmt.setString(2,dto.getEmail());
    		pstmt.setString(4,dto.getId());
    		pstmt.setString(3,dto.getAddress());
    		result = pstmt.executeUpdate();
    		
    	
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);
		
    	}
    	
    	return result;
    
    }

    
    // 회원 삭제 메서드
    
    public int deleteMember(String id) {
    	int result = 0;

    	String query = "DELETE FROM KGMEMBER WHERE id=?";
    	
    	try {
    		Class.forName(driver);
    		conn = DriverManager.getConnection(dbURL,dbID,dbPW);
    		pstmt = conn.prepareStatement(query);
    		pstmt.setString(1,id);
    		result = pstmt.executeUpdate();
    		
    	
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);    		
    	}
    	System.out.println(result+"개 삭제됨");
    	return result;
    
    }


}
