<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%-- 넘어온 데터 받기
ID VARCHAR2(50) PRIMARY KEY,
PW VARCHAR2(50) NOT NULL,
NAME NVARCHAR2(50) NOT NULL,
EMAIL VARCHAR2(100),
ADDRESS NVARCHAR2(100),
REGDATE TIMESTAMP DEFAULT SYSTIMESTAMP //TIMESTAMP(6)


 --%>
 <%!


Connection conn; 
PreparedStatement pstmt; 
ResultSet rs; 


String driver="oracle.jdbc.OracleDriver";
String dbURL = "jdbc:oracle:thin:@localhost:1521:xe"; 
String dbID="C##JAVAUSER";
String dbPW="java2024";
%>



<%

	request.setCharacterEncoding("UTF-8");
	String id = request.getParameter("id");
	String pw = request.getParameter("pw");
	String name = request.getParameter("name");
	String email = request.getParameter("email");
	String address = request.getParameter("address");

	out.print(id+pw+name+address+"<br>");
	
	//	String query= "INSERT INTO KGMEMBER VALUES ("+id+", "+pw+", "+name+", "+email +","+address+") ";
	String query= "INSERT INTO KGMEMBER(ID, PW, NAME, EMAIL, ADDRESS) VALUES (?,?,?,?,?)";

%>


<%
try{


//1. 드라이버 로드
Class.forName(driver);

//2. db와의 연결을 돕는 connection 객체 생성
conn = DriverManager.getConnection(dbURL,dbID,dbPW);
 
//3.0 이미 존재하는 primary key 인지 검사
pstmt = conn.prepareStatement("SELECT ID FROM KGMEMBER"); 
rs = pstmt.executeQuery();
boolean flag = false;
while(rs.next()){
	String tmpID = rs.getString("id");
	if(tmpID.equals(id)){
		flag = true;
		break;
	}
}

if(flag){ // 겹치는 이름 있으면
	%>

	<script type="text/javascript">
	   alert("이미 존재하는 id 입니다");
	</script>
	
	<%
	response.sendRedirect("joinForm.html");
}

else{
//3. statement 객체를 생성하여 쿼리문 실행할 수 있게 준비함
	// preparedstatement d의 setter 메서드로 ? 에 대한 데이터를 넣느다 (인덱스, 값) 
			// 물음표에 대한 인덱스는 1 부터 시작한다
pstmt = conn.prepareStatement(query);
pstmt.setString(1,id);		
pstmt.setString(2,pw);		
pstmt.setString(3,name);
pstmt.setString(4,email);
pstmt.setString(5,address);



//4. query 문 실행
int num = pstmt.executeUpdate();

if(num==1){
out.print(num+"개가 정상적으로 출력되었습니다<br>");
response.sendRedirect("memberList.jsp");
}

}

}catch(Exception e){
	e.printStackTrace();
}finally{

	try{
		if(rs!= null) rs.close();
		 if (pstmt != null) pstmt.close();
		 if (conn != null) conn.close();
	}catch(Exception e){}
	
	
}

%>
</body>
</html>