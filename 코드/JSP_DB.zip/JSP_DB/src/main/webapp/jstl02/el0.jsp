<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
 <%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>

   <%-- 자바에서 import 문을 선언하듯 jsp 에서 jjstl 확장 태그를 사용하려면 taglib 지시자로 라이브러리의 선언이 필요 --%>
   <%-- 
   ctrl + space
  
  if 문은 있는데 else 문은 엇ㅂ다
  test 속성에 조건식을 쓴다
  if 문이 맞으면 해당 태그 내부에 있는 것들이 실행되낟
  
   --%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<c:if test="${1+2==3}">
<p>1+2==3입니다</p>
</c:if>

<c:if test="${1+2!=3}"> <%-- else 문이 없어서 별도로 써줘야됨 --%>
<p>1+2!=3입니다</p>
</c:if>

<%-- 
choose 태그는 자바의 switch 와 비슷한 역할을 한다.
case 문과 같은 역할을 하는 것은 choose 태그 안의 when 태그이다.
default 문과 같은 역할을 하는 것은 choose 태그 안의 otherwise 태그이다.
 --%>

<c:set var="a" value="20"/>
<c:choose >
	<c:when test="${a==10}">
	a는 10 이다<br>
	</c:when>
	
	<c:when test="${a==20}">
	a는 20 이다<br>
	</c:when>
	
	<c:when test="${a==30}">
	a는 30 이다<br>
	</c:when>
	<c:otherwise>
		a는 10,20,30 이 아니다<br>
	
	</c:otherwise>

</c:choose>

<%--
forEach : for 문
 --%>

<c:forEach var="i" begin="0" end="20" step="3">
	<c:out value="${i}"/><br>
</c:forEach>

<%
ArrayList<String> list = new ArrayList<String>();
list.add("홍길동");
list.add("성춘향");
list.add("심봉사");

request.setAttribute("names",list);

%>

<%---
향상된 for 문
items 속성에 컬렉션 객체를 넣음 순서대로 뽑아준다
 --%>
<c:forEach var="name" items="${names}">
	<c:out value="${name}"/><br>
</c:forEach>

</body>
</html>