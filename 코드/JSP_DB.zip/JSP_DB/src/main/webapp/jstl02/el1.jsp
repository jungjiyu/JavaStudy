<%@page import="com.jsp.member.memberDTO"%>
<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
 <%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%--
	1. memberDTO 타입의 arraylist 생성하기
	2. 3개의 memberDTO 객체를 생성 후 Arraylist 에 저장하기
	3. reqeust 객체에 arraylist 바인딩하기
	4. jstl 의 foreach 태그 써서 arraylist 안에 memberDTO 객체들의 속성일일이 출력하기
	
		private String id;
	private String pw;
	private String name;
	private String email;
	private String address;
	private Timestamp regDate; // java.sql.Timestamp 따로 import 필요
	
	

 --%>
 
 <jsp:useBean id="dto1" class="com.jsp.member.memberDTO"/>
 <jsp:setProperty name="dto1" property="id" value="hong"/>
 <jsp:setProperty name="dto1" property="pw" value="1111"/>
 <jsp:setProperty name="dto1" property="name" value="honggildong"/>
 <jsp:setProperty name="dto1" property="email" value="hong@naver.com"/>
 <jsp:setProperty name="dto1" property="address" value="gangdong"/>
 
  
 <jsp:useBean id="dto2" class="com.jsp.member.memberDTO"/>
 <jsp:setProperty name="dto2" property="id" value="sung"/>
 <jsp:setProperty name="dto2" property="pw" value="2222"/>
 <jsp:setProperty name="dto2" property="name" value="sungsigyeong"/>
 <jsp:setProperty name="dto2" property="email" value="sung@naver.com"/>
 <jsp:setProperty name="dto2" property="address" value="gunja"/>
 
 
 
  
 <jsp:useBean id="dto3" class="com.jsp.member.memberDTO"/>
 <jsp:setProperty name="dto3" property="id" value="sim"/>
 <jsp:setProperty name="dto3" property="pw" value="3333"/>
 <jsp:setProperty name="dto3" property="name" value="simbongsa"/>
 <jsp:setProperty name="dto3" property="email" value="sim@naver.com"/>
 <jsp:setProperty name="dto3" property="address" value="bukan"/>

 
 <%
 
 ArrayList<memberDTO> list = new ArrayList<memberDTO>();
 list.add(dto1);
 list.add(dto2);
 list.add(dto3);
 

request.setAttribute("dtos",list);

 
 %>
 
<c:forEach var="ins" items="${requestScope.dtos}">
	<table border="1">
		<tr>
			<th>아이디:</th>
			<td><c:out value="${ins.getId()}"/></td>
			<td><c:out value="${ins.id}"/></td>
		</tr>
		
		<tr>
			<th>비번:</th>
			<td><c:out value="${ins.getPw()}"/></td>
			<td><c:out value="${ins.pw}"/></td>
			
		</tr>
		
		<tr>
			<th>이름:</th>
			<td><c:out value="${ins.getName()}"/></td>
			<td><c:out value="${ins.name}"/></td>
			
		</tr>
		
		<tr>
			<th>주소:</th>
			<td><c:out value="${ins.getAddress()}"/></td>
			<td><c:out value="${ins.address}"/></td>

		</tr>
	
		<tr>
			<th>이메일:</th>
			<td><c:out value="${ins.getEmail()}"/></td>
			<td><c:out value="${ins.email}"/></td>
		</tr>
	
	<br>
</c:forEach>

</body>
</html>