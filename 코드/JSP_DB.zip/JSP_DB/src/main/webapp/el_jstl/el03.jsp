<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%-- 서블릿 보관소에 저장된 데이터를 사용가능 --%>
<%
	application.setAttribute("appliNam","appliVal");
	session.setAttribute("sessionNam","sessionVal");
	request.setAttribute("reqNam","reqVal");
	pageContext.setAttribute("pagNam","pagVal");
%>
${applicationScope.appliNam }<br>
${requestScope.reqNam }<br>
${sessionScope.sessionNam }<br>
${pageScope.pagNam}<br>

<%-- 사실 이름만으로도 실행 가능 --%>
${appliNam }<br>
${reqNam }<br>
${sessionNam }<br>
${pagNam}<br>

</body>
</html>