<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
 <%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>

   <%-- 자바에서 import 문을 선언하듯 jsp 에서 jjstl 확장 태그를 사용하려면 taglib 지시자로 라이브러리의 선언이 필요 --%>
   <%-- 
   
   prefix >> 접두사
   	:  core 를 나타내는 "c"를 많이 씀
   
   일반적으로 jstl 이란 JSTL + EL 의 조합을 말한다
   HTML 코드 내에 java 코드인 스크립틀릭 코드를 대체하여 사용한다.
   스크립틀릿을 사용하면 가독성 떨어지고ㅡ 뷰(=화면)와 비즈니스 로직 분리로 인해 현재는 jstl 을 더 많이 쓰는 추세
   
   
   set  : 변수값선언
   out: 변수값 출력
   remove: 변수값 제거
   --%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<c:set var="name" value="홍길동" scope="page"/> <%-- var == variable . 변수명 --%>
이름: <c:out value="${name}"/><br>
<c:remove var="name" scope="page"/><br>

이름: <c:out value="${name}"/><br>

</body>
</html>