<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<%-- EL
	: 정수, 실수 ,논리 , 문자열, 널을 표현 가능
	: 산술, 비교(관걔) , 논리 , 조건(삼항)
 --%>
 
정수: ${100}<br>
실수: ${3.14}<br>
논리: ${true}<br>
문자열: ${'문자열'}<br>
논리: ${null}<br>

 
산술: ${1+2}<br>
비교: ${1>3}<br>
논리: ${1<3 &&3<8}<br>
삼항: ${1==1?100:-100}<br>
</body>
</html>