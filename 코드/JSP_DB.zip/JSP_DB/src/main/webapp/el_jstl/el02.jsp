<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style>
	table{
		text-align:center;
		margin:0 auto;
		color:red;
	}
</style>	
</head>

<body>
<%-- id , pw 입력 받는 폼 --%>
<form action="el02.jsp" method="post">
	<table border="1">
		<caption>로그인폼</caption>
		<tr>
			<th>아이디:</th>
			<td><input type="text" name="id"></td>
			<td rowspan="2"><input type="submit" value="로그인"></td>
		</tr>
		<tr>
			<th>비밀번호:</th>
			<td><input type="password" name="pw"></td>
		</tr>
	</table>
	
<%-- EL 의 내장객체 param 객체로 넘어온 파라미터 값을 사용할 수 있다 --%>
아이디:${param["id"]}<br>
아이디:${param.id }<br> <%-- name 속성값ㅇ르 이용하여 접근 --%>
비밀번호:${param.pw }<br> <%-- name 속성값ㅇ르 이용하여 접근 --%>

</body>
</html>