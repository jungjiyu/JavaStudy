<%@page import="java.sql.Timestamp"%>
<%@page import="com.jsp.member.memberDTO"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>modify</title>
</head>
<body>

<% 
	memberDTO dto = (memberDTO)session.getAttribute("member");
	String id = dto.getId();
	String name = dto.getName();
	String pw= dto.getPw();
	String address = dto.getAddress();
	String email = dto.getEmail();
	Timestamp regDate  = dto.getRegDate();
	%>
	
	
<form action="modifyCheck.jsp" method="post">	
	<input type="hidden" name="id" value="<%=id %>">
	<table border="1">
		<caption>회원정보수정</caption>
		<tr>
			<th>아이디</th>
			<td><%=id %></td>
		</tr>
	
	<tr>
		<th>비밀번호</th>
		<td><input type="text" name="pw"  value="<%=pw %>"></td>
	</tr>
	
	
	<tr>
		<th>이름</th>
		<td><%=name %></td>
	</tr>
	
	<tr>
		<th>이메일</th>
		<td><input type="text" name="email"  value="<%=email %>"></td>
	</tr>
	
	<tr>
	<th>주소</th>
		<td><input type="text" name="address"  value="<%=address %>"></td>
	</tr>	
	
	<tr>
		
		<td colspan="2">
			<input type="submit" value="정보 수정"> <%-- 바로 체크 안되게함 --%>
		</td>
	</tr>	
	</table>
</form>
</body>
</html>