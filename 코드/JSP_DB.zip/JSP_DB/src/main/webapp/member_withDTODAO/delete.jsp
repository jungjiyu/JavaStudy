<%@page import="com.jsp.member.memberDTO"%>
<%@page import="com.jsp.member.memberDAO"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<p>진짜 삭제하시겠습니까?</p>
	<input type="button" onclick="deleteFr()" value="yes">
	<input type="button" onclick="goBack()" value="no">

<script>
	function deleteFr(){
		
		<%
		memberDTO dto = (memberDTO) session.getAttribute("member");
		String id = dto.getId();

		memberDAO dao = memberDAO.getInstance();
		int n = dao.deleteMember(id);
		
		if(n==1){
			
	%>
			alert('탈퇴되었습니다');
			window.location = 'logout.jsp' ; 
		
		<% 
		}
			
		else{
			%>
				alert("데이터 처리 과정에 문제 발생");
				history.back();
		<% 
		}

	%>
		
	}
</script>

<script>
	function goBack(){
		history.back();

	}
</script>


</body>
</html>