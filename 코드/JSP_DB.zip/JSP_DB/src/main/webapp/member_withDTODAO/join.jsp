<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style>
	table{
		text-align:center;
		margin: 0 auto;
	}

</style>

</head>
<body>



<%-- 간단한 유효성 체크 --%>
	<script type="text/javascript">
		// 함수 >> function 이란 키워드로 시작
		function joinFormCheck(){
			
			//alert('hello');
			var id = document.joinForm.id.value; //  << 현재 문서에 접근하는 객체
			var pw = document.joinForm.pw.value; //  
			var pwCheck = document.joinForm.pwCheck.value; 

			if(id==null || id==""){
				alert("아이디는 필수사항입니다."); // 위에 경고 창 띄위기
				document.joinForm.id.focus(); // 아이디 쪽으로 커서를 이동시킴
				return ; // 함수 종료
			}
			
			if(pw==null || pw==""){
				alert("비밀번호는 필수사항입니다."); // 위에 경고 창 띄위기
				document.joinForm.pw.focus(); // 아이디 쪽으로 커서를 이동시킴
				return ; // 함수 종료
			}
			
			if(pwCheck!=pw){
				alert("비밀번호를 확인해주세요."); // 위에 경고 창 띄위기
				document.joinForm.pwCheck.focus(); // 아이디 쪽으로 커서를 이동시킴
				return ; // 함수 종료
			}
	
			document.joinForm.submit();
		}
	</script>

<form name="joinForm" action="joinCheck.jsp" method="post">

	
	<table border="1">
		<caption>회원가입폼</caption>
	<tr>
		<th>아이디</th>
		<td><input type="text" name="id"></td>
	</tr>
	
	<tr>
		<th>비밀번호</th>
		<td><input type="text" name="pw"></td>
	</tr>
	
	<tr>
		<th>비밀번호 확인</th>
		<td><input type="text" name="pwCheck"></td>
	</tr>
	
	<tr>
		<th>이름</th>
		<td><input type="text" name="name"></td>
	</tr>
	
	<tr>
		<th>이메일</th>
		<td><input type="text" name="email"></td>
	</tr>
	
	<tr>
	<th>주소</th>
		<td><input type="text" name="address"></td>
	</tr>	
	
	<tr>
		
		<td colspan="2">
			<input type="button" onclick="joinFormCheck()" value="회원가임"> <%-- 바로 체크 안되게함 --%>
		</td>
	</tr>	
	
	
	</table>
</form>



</body>
</html>