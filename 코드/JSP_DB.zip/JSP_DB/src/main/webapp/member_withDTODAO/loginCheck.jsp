<%@page import="com.jsp.member.memberDTO"%>
<%@page import="com.jsp.member.memberDAO"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>loginCheck</title>
</head>
<body>


<%
	request.setCharacterEncoding("UTF-8");
%>



<%
// memerDAO 객체 생성 해야됨

	memberDAO dao = memberDAO.getInstance();
	String id = request.getParameter("id");
	String pw = request.getParameter("pw");
	int flag = dao.loginCheck(id,pw); // getProperty 액션 태그 안쓰고 바로 getId( ) 사용 가능
	if(flag==1){  // 아이디와 비밀번호가 일치
		
		memberDTO dto = dao.getMember(id);
		session.setAttribute("member",dto);
		
		
		%>	
		<script >
			alert('로그인 성공');
			history.back(); 
		</script>
	<%	
		response.sendRedirect("main.jsp");
	}
	
	else if(flag == -1){ // 아이디 틀림
		%>	
		<script >
			alert('아이디가 존재하지 않습니다');
			history.back(); 
		</script>
	<%	
	}
	else{ // 비밀번호 틀림
		
		%>
		<script >
			alert('비밀번호가 일치하지 않습니다');
			history.back(); 
		</script>
		
	<%
	}

%>


</body>
</html>