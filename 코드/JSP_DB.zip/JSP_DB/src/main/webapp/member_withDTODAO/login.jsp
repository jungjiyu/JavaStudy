<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<form action="loginCheck.jsp" method="post">
		<fieldset>
			<legend>로그인 폼</legend>
		<p><label>아이디:<input type="text" name="id"></label></p>
		<p><label>비밀번호:<input type="text" name="pw"></label></p>
		<p><input type="submit" name="전송"></p>
		</fieldset>
	</form>
	
</body>
</html>