<%@page import="com.jsp.member.memberDAO"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<%
	request.setCharacterEncoding("UTF-8");
%>


<jsp:useBean id="dto" class="com.jsp.member.memberDTO" scope="page" />

<jsp:setProperty name="dto" property="*"  /> 

<%
// memerDAO 객체 생성 해야됨

	memberDAO dao = memberDAO.getInstance();
	System.out.print(dto.getId());
	boolean flag = dao.idCheck(dto.getId()); // getProperty 액션 태그 안쓰고 바로 getId( ) 사용 가능
	if(flag){ 
		// 같은 아이디가 졵재한다면
	
		
	%>	
		<script >
			alert('아이디가 이미 존재');
			window.location = 'join.jsp' ; // window의 redirection
		</script>
	<%	
	}else{ // 같은 아이디가 존재하지 않다면 
		int result = dao.insertMember(dto);
		if(result==1){ // insert 성공
		%>
		<script >
			alert('회원가입되었습니다');
			window.location = 'login.jsp' ; // window의 redirection
		</script>
		<%}else{ // 실패
			%>
		<script >
			alert('데이터 추가 과정에 문제가 생겼습니다.');
			history.back(); // 이전 페이지로 돌아가기 . history == 이전 페이지 객체
							// window.location = 'join.jsp' 랑 같은거
			</script>
			
			
			<%
		}
	}

%>


</body>
</html>