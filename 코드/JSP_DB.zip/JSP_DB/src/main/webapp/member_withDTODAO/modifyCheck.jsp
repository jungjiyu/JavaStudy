<%@page import="java.sql.Timestamp"%>
<%@page import="com.jsp.member.memberDTO"%>
<%@page import="com.jsp.member.memberDAO"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>modifyCheck</title>
</head>
<body>


<%
	request.setCharacterEncoding("UTF-8");
%>
	
<jsp:useBean id="dto" class="com.jsp.member.memberDTO" scope="page" />
<jsp:setProperty name="dto" property="*"  /> 


<%
// memerDAO 객체 생성 해야됨
	
	memberDAO dao = memberDAO.getInstance();
	
	int result = dao.modifyMember(dto);
		if(result==1){ // insert 성공
			
			/*memberDTO oldDto = (memberDTO)session.getAttribute("member");
			oldDto.setPw(request.getParameter("pw"));
			oldDto.setEmail(request.getParameter("email"));
			oldDto.setAddress(request.getParameter("address")); */
			memberDTO dto2 = dao.getMember(dto.getId());
			session.setAttribute("member", dto2);
		
		%>
		<script >
			alert('회원정보가 수정되었습니다');
			window.location = 'login.jsp' ; 
			
		</script>
		<%}else{ // 실패
			%>
		<script >
			alert('데이터 수정 과정에 문제가 생겼습니다.');
			history.back(); 
			</script>
			
			
			<%
		}
	

%>

</body>
</html>