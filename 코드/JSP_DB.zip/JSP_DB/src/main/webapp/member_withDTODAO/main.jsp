<%@page import="java.sql.Timestamp"%>
<%@page import="com.jsp.member.memberDTO"%>
<%@page import="java.util.Enumeration"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h1>main</h1>

<%-- 외원 정보 출력하기 --%>
<%

	if(session.getAttribute("member")==null){ %>
		<jsp:forward page="login.jsp"/>
		<%	
	}

	memberDTO dto = (memberDTO)session.getAttribute("member");
	String id = dto.getId();
	String name = dto.getName();
	String  pw= dto.getPw();
	String address = dto.getAddress();
	String email = dto.getEmail();
	Timestamp regDate  = dto.getRegDate();

%>
	<table border="1">
		<caption>회원 정보</caption>
	<tr>
		<th>아이디</th>
		<td><%=id %></td>
	</tr>
	
	<tr>
		<th>비밀번호</th>
		<td><%=pw %></td>
	</tr>
	

	<tr>
		<th>이름</th>
		<td><%=name %></td>
	</tr>
	
	<tr>
		<th>이메일</th>
		<td><%=email %></td>
	</tr>
	
	<tr>
	<th>주소</th>
		<td><%=address %></td>
	</tr>	
	<tr>
	<th>등록시간</th>
		<td><%=regDate%></td>
	</tr>	

	</table>
	
	<p><a href="logout.jsp">로그아웃</a></p>
	<p><a href="modify.jsp">회원정보 수정</a></p>
	<p><a href="delete.jsp">회원탈퇴</a></p>

	
</body>
</html>