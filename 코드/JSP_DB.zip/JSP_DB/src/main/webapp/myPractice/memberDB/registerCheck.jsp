<%@page import="practice.ClassDAO"%>
<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>check</title>
</head>
<body>
			<%
			request.setCharacterEncoding("utf-8");
			ArrayList<String> names = ClassDAO.getNameList();
			for(int i =0;i<names.size();i++){
				out.print(names.get(i)+"&nbsp");
			}
			%>
			
	<script type="text/javascript">
		function duplicationCheck(){
			var flag=true;
			
			
			<%
			for(int i =0;i<names.size();i++){
				
				if(names.get(i).equals(request.getParameter("name"))){
					%>
					alert('false');

					flag=false;
					<%
					break;
				}
			}
			%>
			
			if(flag){
				alert('사용할 수 있는 이름입니다');
			}else{
				alert('이미 사용중인 이름입니다');
			}
			
			//document.rForm.submit();
			
			
			return;
		}
	
	</script>
	<jsp:useBean id="dto" class="practice.ClassDTO"/>
	<jsp:setProperty name="dto" property="*"/>

</body>
</html>