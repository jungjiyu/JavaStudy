
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>회원등록</title>

<style>
	th{
		text-aligh:center;
		margin:0 auto;
		color:red;
	}

</style>
</head>


<body>

	<script type="text/javascript">
		function isNULL(){
			var flag=true;
			var name = document.rForm.name.value;
			if(name==null || name==""){
				alert('이름을 입력해주세요');
				document.rForm.name.focus();
				flag = false;
			}
			
			return flag;
		}
	
	</script>
	
	
	<script type="text/javascript">
		function approval(){
			if(isNULL()){
				document.rForm.submit();
				return;

			}

			return;
		}
	
	</script>
	

	
	<h1>회원등록</h1>
	
<form name="rForm" action="registerCheck.jsp" method="post">	
	<table border="1">
	
		<caption>회원등록 폼</caption>
	
		<tr>
			<th>이름</th>
			<td>
				<input type="text" name="name">
				<input type="button" value="확인" onclick="isNULL()">
			</td>
			<td rowspan="3"><input type="button" value="전송" onclick="approval()"></td>
		
		</tr>
		
		
		
		<tr>
			<th>전화번호</th>
			<td><input type="text" name="phone"></td>
			
		</tr>
				
		<tr>
			<th>이메일</th>
			<td><input type="text" name="email"></td>
			
		</tr>
		
	
	</table>	
</form>
</body>
</html>