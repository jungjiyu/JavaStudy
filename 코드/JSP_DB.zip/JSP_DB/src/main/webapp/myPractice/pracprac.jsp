<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<%!


// 이거 미리 안해두면 finally 문에서 해제 못한다 
Connection conn; 
PreparedStatement pstmt; 
ResultSet rs; 


String driver="oracle.jdbc.OracleDriver";
String dbURL = "jdbc:oracle:thin:@localhost:1521:xe"; 
String dbID="C##JAVAUSER";
String dbPW="java2024";
String query= "SELECT * from YayTest";
%>
<%
try{


//1. 드라이버 로드
Class.forName(driver);

//2. db와의 연결을 돕는 connection 객체 생성
conn = DriverManager.getConnection(dbURL,dbID,dbPW);

//3. statement 객체를 생성하여 쿼리문 실행할 수 있게 준비함
pstmt = conn.prepareStatement(query);

//4. 쿼리문 실행한 결과를 Resultset 객체로 받음
rs = pstmt.executeQuery();

while(rs.next()){
	//next : 다음 레코드가 있는지 확인 후에 다음 레코드가 있다면 true, 없으면 false 를 반환
	String name = rs.getString("NAMEXX"); // ResultSet 의 getter 계열 메서드에 column 의 이름을 문자열타입으로 arg 를 넣어 해당 column 값을 얻을 수 있다
	String age = rs.getString("AGEXX"); 
	out.print(name+" "+age+"<br>");
	
	

}

}catch(Exception e){
	e.printStackTrace();
}finally{

	try{
		if (rs != null) rs.close();
		 if (pstmt != null) pstmt.close();
		 if (conn != null) conn.close();
	}catch(Exception e){}
	
	
}

%>

</body>
</html>