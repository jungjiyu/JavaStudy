<%@page import="com.mvc.board.BoardDTO"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>contentView</title>

	
</head>
<body>

<table border="1">
	<caption>글</caption>
	<tr>
		<th>제목</th>
		<td><c:out value="${requestScope.contentViewDTO.title }"/></td>
	</tr>
	
	<tr>
		<th>작성자</th>
		<td><c:out value="${requestScope.contentViewDTO.writer }"/></td>
	</tr>
	
	<tr>
		<th>내용</th>
		<td><c:out value="${requestScope.contentViewDTO.content }"/></td>
	</tr>
	
	
	<tr>
		<td colspan="2">
			<form action="/JSP_MVC/modifyForm.do" method="post">
				<input type="submit" value="글수정">
				<input type="hidden" name="title" value="${requestScope.contentViewDTO.title }">
				<input type="hidden" name="boardId" value="${requestScope.contentViewDTO.boardId }">
				<input type="hidden" name="writer" value="${requestScope.contentViewDTO.writer }">
				<input type="hidden" name="content" value="${requestScope.contentViewDTO.content }">
				<input type="hidden" name="numer" value="${requestScope.contentViewDTO.number }">
				<input type="hidden" name="boardDate" value="${requestScope.contentViewDTO.boardDate }">
			</form>
			
			<form action="/JSP_MVC/delete.do" method="post">
				<input type="hidden" name="boardId" value="${requestScope.contentViewDTO.boardId }">
				<input type="submit" value="글삭제">
			</form>
			<a href="/JSP_MVC/list.do?page=${sessionScope.cp}" >  목록으로 </a>
	<%--  <a href="/JSP_MVC/list.do?page=${param.page}" >  목록으로 </a>   --%>	
			
			
			
		</td>
	</tr>
	
</table>
	

<br>



</body>
</html>