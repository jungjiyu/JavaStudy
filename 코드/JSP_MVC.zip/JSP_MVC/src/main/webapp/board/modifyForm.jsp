<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>수정페이지</title>
</head>
<body>
<%---
	수정 폼 > > 제목 , 내용 수정
		: 글 번호 , 잓성자 ㅡ 조회수는 출력

 --%>
	<h2>글 수정 폼</h2>
	<form action="/JSP_MVC/modify.do" method="post">
	<%--
					<input type="hidden" name="title" value="${requestScope.contentViewDTO.title }">
				<input type="hidden" name="boardId" value="${requestScope.contentViewDTO.boardId }">
				<input type="hidden" name="writer" value="${requestScope.contentViewDTO.writer }">
				<input type="hidden" name="content" value="${requestScope.contentViewDTO.content }">
				<input type="hidden" name="numer" value="${requestScope.contentViewDTO.number }">
				<input type="hidden" name="boardDate" value="${requestScope.contentViewDTO.boardDate }">
	
	
	 --%>
		<table border="1">
			<tr>
				<th>작성자</th>
				<td><c:out value="${param.writer}"/></td> 
			</tr>
			
			<tr>
				<th>제목</th>
				<td><input type="text" name="title" value="${param.title}" ></td> <%-- 되도록 dto 선언한거랑 필드머ㅕㅇ 맟주차 --%>
			</tr>
			
			<tr>
				<th>내용</th>
				<td><textarea cols="23" rows="5" name="content"  >${param.content}</textarea></td> <%-- 되도록 dto 선언한거랑 필드머ㅕㅇ 맟주차 --%>
			</tr>
			<tr>
				<input type="hidden" name="boardId" value="${param.boardId}"/>
				<td colspan="2"><input type="submit" value="글등록"></td> <%-- 되도록 dto 선언한거랑 필드머ㅕㅇ 맟주차 --%>
			</tr>
			
		</table>
	</form>

</body>
</html>