<%@page import="java.text.SimpleDateFormat"%>
<%@page import="com.mvc.board.BoardDTO"%>
<%@page import="java.util.ArrayList"%>
<%@page import="com.mvc.board.BoardDAO"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
 <%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
 <%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

<style>
	body,table{
		text-align:center;
		 margin:auto; 
	}
</style>
</head>
<body>
<%--
	request.setAttribute("list", list);
	el 과 jstl 을 사용하여 게시판 목록 페이지 만들기
 --%>



	
<a href="/JSP_MVC/list.do?page=${sessionScope.cp}">MVC게시판</a>

	
	<%-- 포멧하고 클릭할 수 있게 끔 contentView.do로  --%>
<c:forEach var="element" items="${list}">
<table border="1">
	<tr>
		<th>글번호</th>
		<th>작성자</th>
		<th>제목</th>
		<th>내용</th>
		<th>등록일</th>
		<th>조회수</th>
	</tr>
	<tr>
	<td><c:out value="${ element.boardId}"/><br></td>
	<td><c:out value="${ element.writer}"/><br></td>
	<td><a href="/JSP_MVC/contentView.do?boardId=${element.boardId}&page=${paging.currentPage}">
	<c:if test="${ element.newMark}">
		<span style="color:orange">[new]</span>
		
	</c:if>
	<c:out value="${ element.title}"/>
	</a><br></td>
	<td><c:out value="${ element.content}"/><br></td>

	<c:set var="date" value="${ element.boardDate}" />
	<td><fmt:formatDate value="${element.boardDate}" pattern="yyyy년 MM월 dd일 HH:mm:ss"/><br></td>
	<td><c:out value="${ element.number}"/><br><br></td>
</c:forEach>
	</tr>
	
	<tr>
		<td colspan="5">
			<a href="/JSP_MVC/writeForm.do">글작성</a>
		</td>
	</tr>
</table>

	<%--
	
	currentPage 를 증가시켜서 param 으로 보내고
	------- 페이징 처리
		
		1.이전 버튼 활성화 여부를 jstl 로 표현
		2.다음 버튼 활성화 '' 
	 --%>
	 
	<c:if test="${requestScope.paging.prev}">
		<a href="/JSP_MVC/list.do?page=${paging.startPage-1}">[이전]</a>
	 </c:if>
	 
	 <c:forEach var="pageNum" begin="${paging.startPage}" end="${paging.endPage}" step="1">
	 		<a href="/JSP_MVC/list.do?page=${pageNum}" style="${paging.currentPage == pageNum ? 'color:red':'color:blue'}">  ${pageNum} </a>&nbsp 	
	 </c:forEach>
	 
	 <c:if test="${requestScope.paging.next}">
		<a href="/JSP_MVC/list.do?page=${paging.endPage+1}">[다음]</a>
	 </c:if>
</body>
</html>