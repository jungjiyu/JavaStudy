<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
</head>
<body>

<%--

public int boardInsert(BoardDTO dto) {
	/*
	 
BOARD_ID	NUMBER(4,0)
WRITER	NVARCHAR2(50 CHAR)
TITLE	NVARCHAR2(500 CHAR)
CONTENT	NVARCHAR2(500 CHAR)
BOARD_DATE	TIMESTAMP(6)
HIT	NUMBER(4,0)
	
	 */
	int result = 0 ;
	// default 값의 경우 테이븖명( column 명 , ... ) 부분에서 아예 column 을 명시 안하면 애초에 default 란 값조차 안넣어도 된다.
	String query = "INSERT INTO Board(BOARD_ID , WRITER , TITLE , CONTENT, BOARD_DATE, HIT ) VALUES (board_seq.nextVal,?,?,?,default,default)";
	try {
		conn = ds.getConnection();
		pstmt = conn.prepareStatement(query);
		pstmt.setString(2,dto.getWriter());		
		pstmt.setString(3,dto.getTitle());
		pstmt.setString(4,dto.getContent());
		result = pstmt.executeUpdate();
		
	}catch(Exception e) {e.printStackTrace();}finally {
		try{
    		close(rs,pstmt,conn);
		}catch(Exception e){}
		    		
	}
	return result;
}

 --%>
 <%
 application.setAttribute("", "");
 
 %>
	<h2>글 작성 폼</h2>
	<form action="/JSP_MVC/write.do" method="post">
		<table border="1">
			<tr>
				<th>작성자</th>
				<td><input type="text" name="writer"></td> <%-- 되도록 dto 선언한거랑 필드머ㅕㅇ 맟주차 --%>
			</tr>
			
			<tr>
				<th>제목</th>
				<td><input type="text" name="title"></td> <%-- 되도록 dto 선언한거랑 필드머ㅕㅇ 맟주차 --%>
			</tr>
			
			<tr>
				<th>내용</th>
				<td><textarea cols="23" rows="5" name="content"></textarea></td> <%-- 되도록 dto 선언한거랑 필드머ㅕㅇ 맟주차 --%>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" value="글등록"></td> <%-- 되도록 dto 선언한거랑 필드머ㅕㅇ 맟주차 --%>
			</tr>
			
		</table>
	</form>
</body>
</html>