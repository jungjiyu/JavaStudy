package com.mvc.board;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//.do >>jsp 에서 사용하는 가상의 주소
	// 사용자는 파일의 실제 경로룰 알 수 없으므로 보안에 도움이 된다
@WebServlet("*.do")  // *.do >> 어떤 request 이든 .do 로 끝나면 BoardController 가 이를 처리하겠다
public class BoardController extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("BoardController 의 service() 실행");
		
		request.setCharacterEncoding("UTF-8");
		
		// 전체 URL 에서 *.do 부분만 추출
			// 어떤 로직을 수행할지 구분하기 위해 필요한건 맨 뒤의 /*.do 부분이기 때문
			// 컨트롤러로 들어온 이상 /contextPath/../ 는 확실한거니까딱히 쓸데 없다
		
		String uri = request.getRequestURI(); // url 에서 context 부분부터 문자열로 뽑아온다
		System.out.println("URI: "+uri);
		
		String conPath = request.getContextPath(); // contextpath 즉 프로젝트 명만 얻어온다
		System.out.println("conPath: "+conPath);
		
		String result = uri.substring(conPath.length()); // / *.do 만 남는다
		System.out.println("uri.substring(conPath.length()) : "+result);
		String viewPage =null; //포워딩될 jsp 페이지 url 할당받을 변수
		Command command = null; // model 역할을 수행하는 Command 객체
		// command 객체>> 컨트롤러에서 받은 요청을 분석해 어떤 처리가 필요한지에 따라서 각 처리에 필요한 command 객체를 실행시켜 로직을 처리하게 하고 필요한 데이터를 가지고 컨트롤러로 보내준다

		
		if(result.equals("/list.do")) { // 게시판 목록 페이지 요청
			command = new ListCommand();
			viewPage= command.excute(request, response);
			
		}
		else if(result.equals("/writeForm.do")) {	// 게시글 작성 폼페이지 요청 : /writeForm.do

			viewPage= "board/writeForm.jsp";
		}
		else if(result.equals("/write.do")) {// 게시글 등록 페이지 요청 : /write.do
			command = new WriteCommand();
			viewPage = command.excute(request, response);
			
		}
		else if(result.equals("/contentView.do")) {// 제목 클릭시 해당 페이지 요청: /contentView.do
			command = new ContentViewCommand();
			viewPage = command.excute(request, response);	
		}
		
		else if(result.equals("/modifyForm.do")) {// ㅅㅜ정 폼페이지 요청: /modifyForm.do
			viewPage="board/modifyForm.jsp";
		}
		else if(result.equals("/modify.do")) {// ㅅㅜ정  요청: /modify.do
			command = new ModifyCommand();
			viewPage = command.excute(request, response);	

		}
		else if(result.equals("/delete.do")) {//게시글 삭제 요청: /delete.do
			command = new DeleteCommand();
			viewPage = command.excute(request, response);	

		}
		
		// 서블릿의 forward 객체
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response); //해당 jsp 페이지로 forward
		
	}


}
