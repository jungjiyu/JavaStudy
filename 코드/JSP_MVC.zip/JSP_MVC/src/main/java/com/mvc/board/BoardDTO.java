package com.mvc.board;

import java.sql.Timestamp;

public class BoardDTO {
	private int boardId;
	private String writer;
	private String title;
	private String content;
	private Timestamp boardDate;
	private int number;
	private boolean newMark; // new 마크 활성화 여부
	
	public boolean isNewMark() {
		return newMark;
	}

	public void setNewMark(boolean newMark) {
		this.newMark = newMark;
	}

	public Timestamp getBoardDate() {
		return boardDate;
	}

	public BoardDTO(int boardId, String writer, String title, String content, Timestamp boardDate, int number) {
		super();
		this.boardId = boardId;
		this.writer = writer;
		this.title = title;
		this.content = content;
		this.boardDate = boardDate;
		this.number = number;
	}

	public void setBoardDate(Timestamp boardDate) {
		this.boardDate = boardDate;
	}

	public BoardDTO(){
		
	}

	public int getBoardId() {
		return boardId;
	}

	public void setBoardId(int boardId) {
		this.boardId = boardId;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}



	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	
	

}
