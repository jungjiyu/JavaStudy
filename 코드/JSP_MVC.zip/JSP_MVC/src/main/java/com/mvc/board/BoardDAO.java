package com.mvc.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;





public class BoardDAO {
	
	// DAO : Data Access Object . db 의 데이터에 접근하여 CRUD 을 처리하는 객체
	private DataSource ds;
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
///	 사실 DataSource 준비해놨음 필요 없다 아래 4가지 정보는
	private String driver="oracle.jdbc.OracleDriver";
	private String dbURL = "jdbc:oracle:thin:@localhost:1521:xe"; 
	private String dbID="C##JAVAUSER";
	private String dbPW="java2024";
	
	// 싱글톤패턴구현
	private static BoardDAO instance = new BoardDAO();
	
	private BoardDAO() {
		
		try {
			Context context =new InitialContext();
			ds = (DataSource)context.lookup("java:comp/env/jdbc/oracle"); // 이름으로 해당하는 객체를 얻을 수 있다
			//반환 타입이 obj 임
		}catch(Exception e) {e.printStackTrace();}
	}
	
	
	private void close(ResultSet rs , PreparedStatement pstmt, Connection conn ) {
		try{
			if(rs!= null) rs.close();
			 if (pstmt != null) pstmt.close();
			 if (conn != null) conn.close();
		}catch(Exception e){}
	}
	
	public static BoardDAO getInstance() {
		return instance;
	}
	
	
	/*
	 
	 1. 게시판 목록
	 2. 글 작성 폼 > 글 등록
	 3. 목록에서 제목 클릭시 해당 내용페이지가 보여짐
	 4. 글 수정
	 5. 글 삭제
	 
	 
	 */
	//0. 조회수 증가
	
	/*
	 
	 */
	//1. 게시판 목록 만들기 위해 모든 데이터를 얻어오는 긴능

	public ArrayList<BoardDTO> boardList(int postStart , int postEnd){
		ArrayList<BoardDTO> list= new ArrayList<BoardDTO>();

    	String query = "select * from"
    			+ "    (select ROWNUM num, B.* from"
    			+ "    ("
    			+ "    select * from BOARD order by board_id desc"
    			+ "    )B"
    			+ "    )"
    			+ "where NUM between ? and ?";
    	
    	try {
    		conn = ds.getConnection();
    		pstmt = conn.prepareStatement(query);
    		pstmt.setInt(1, postStart);
    		pstmt.setInt(2, postEnd);
    		rs = pstmt.executeQuery();
    		
    		while(rs.next()) {    		
  
    			BoardDTO dto = new BoardDTO();
    			dto.setBoardId(rs.getInt("board_id")); 
    			dto.setWriter(rs.getString("writer"));
    			dto.setTitle(rs.getString("title"));
    			dto.setContent(rs.getString("content"));
    			dto.setBoardDate(rs.getTimestamp("board_date"));	
    			dto.setNumber(rs.getInt("hit"));
    			
    		
    			list.add(dto);
    		}
    		
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);
    	}

		
		return list;
	}
	
	
	//2. 데이터를 매개변수로 받아서 DB에 데이터를 넣는 기능
	
	// 회원 가입 폼에서 넘어온 데이터를 테이블에 insert 하는 메서드
public int boardInsert(BoardDTO dto) {
	/*
	 
BOARD_ID	NUMBER(4,0)
WRITER	NVARCHAR2(50 CHAR)
TITLE	NVARCHAR2(500 CHAR)
CONTENT	NVARCHAR2(500 CHAR)
BOARD_DATE	TIMESTAMP(6)
HIT	NUMBER(4,0)
	
	 */
	int result = 0 ;
	// default 값의 경우 테이븖명( column 명 , ... ) 부분에서 아예 column 을 명시 안하면 애초에 default 란 값조차 안넣어도 된다.
	String query = "INSERT INTO Board(BOARD_ID , WRITER , TITLE , CONTENT ) VALUES (board_seq.nextVal,?,?,?)";
	try {
		conn = ds.getConnection();
		pstmt = conn.prepareStatement(query);
		pstmt.setString(1,dto.getWriter());		
		pstmt.setString(2,dto.getTitle());
		pstmt.setString(3,dto.getContent());
		result = pstmt.executeUpdate();
		System.out.println(result);
		
	}catch(Exception e) {e.printStackTrace();}finally {
		try{
    		close(rs,pstmt,conn);
		}catch(Exception e){}
		    		
	}
	return result;
}



	//3. 제목 클릭시 해당 내용 페이지로 가서 해당 글을 보여주기 위해 데이터를 얻어오는 기능
public BoardDTO getContent(int boardId) { // 프라이머리키
	BoardDTO dto = null;
	String query = "SELECT * FROM BOARD WHERE BOARD_ID=?";
	upHit(boardId); // 조회수 1 증가
	
	try {
		conn = ds.getConnection();
		pstmt = conn.prepareStatement(query);
		pstmt.setInt(1,boardId);
		rs = pstmt.executeQuery();
		
		if(rs.next()) {   
			/*
			 
			BOARD_ID	NUMBER(4,0)
			WRITER	NVARCHAR2(50 CHAR)
			TITLE	NVARCHAR2(500 CHAR)
			CONTENT	NVARCHAR2(500 CHAR)
			BOARD_DATE	TIMESTAMP(6)
			HIT	NUMBER(4,0)
				
				 */

			dto = new BoardDTO();
			dto.setBoardId(rs.getInt("board_id"));
			dto.setWriter(rs.getString("writer"));
			dto.setTitle(rs.getString("title"));
			dto.setContent(rs.getString("content"));
			dto.setNumber(rs.getInt("hit"));	
			dto.setBoardDate(rs.getTimestamp("BOARD_DATE"));	
		

		}
		
		
	}catch(Exception e) {e.printStackTrace();}finally {
		close(rs,pstmt,conn);

	}
	
	
	return dto;
}



	private void upHit(int boardId) {
    	String query = "UPDATE Board SET hit=hit+1 WHERE board_id=?";
    	
    	try {
    		conn = ds.getConnection();
    		
    		pstmt = conn.prepareStatement(query);
    		pstmt.setInt(1,boardId);
    		pstmt.executeUpdate();
    		
    	
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);
		
    	}
    	
    
		
	}
	
	//4. 글 수정폼에서 넘어온 데이터를 매개변수로받아서 해당 글을 수정해주는기능 
		// title, content, boardId 를 매개변수로 받아야됨
	public int boardUpdate(BoardDTO dto) {
    	int result = 0;

    	String query = "UPDATE Board SET title=?, content=? WHERE board_id=?";
    	
    	try {
   
    		conn = ds.getConnection();
    		pstmt = conn.prepareStatement(query);
    		pstmt.setString(1,dto.getTitle());
    		pstmt.setString(2,dto.getContent());
    		pstmt.setInt(3,dto.getBoardId());
    		result = pstmt.executeUpdate();
    		
    	
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);
		
    	}
    	
    	return result;
	}
	
	
	
	
	
	//5. 글 번호(primary key) 를 매개변수로 받아서 해당 글을 삭제해주는 기능

    public int boardDelete(int boardId) {
    	int result = 0;

    	String query = "DELETE FROM Board WHERE board_id=?";
    	
    	try {
    		conn = ds.getConnection();
    		pstmt = conn.prepareStatement(query);
    		pstmt.setInt(1,boardId);
    		result = pstmt.executeUpdate();
    		
    	
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);    		
    	}
    	System.out.println(result+"개 삭제됨");
    	return result;
    
    }


    // 페이징 처리를 위해 총 게시물 글을 얻는 메서드
    public int getTotalPosts() {
    	int result = 0;
    	//select count(*) from board; -- board table 의 모든 행의 수를 조회한다
    	String query = "select count(*) as total from board";
    	
    	try {
   
    		conn = ds.getConnection();
    		pstmt = conn.prepareStatement(query);
    		rs = pstmt.executeQuery();
    		if(rs.next()) {
    			result= rs.getInt("total");
    			System.out.println(result);
    		}

    	
    		
    	}catch(Exception e) {e.printStackTrace();}finally {
    		close(rs,pstmt,conn);
		
    	}
    	
    	return result;
    }

   //select rownum from board where writer='이순신99';
    
}
