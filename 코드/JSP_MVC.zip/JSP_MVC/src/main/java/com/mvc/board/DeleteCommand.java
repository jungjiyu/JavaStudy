package com.mvc.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteCommand implements Command {

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response) {
	//    public int boardDelete(int boardId) {

		int boardId = Integer.parseInt(request.getParameter("boardId"));
		BoardDAO dao = BoardDAO.getInstance();
		int num = dao.boardDelete(boardId);
		
		String msg=null;
		String url="/JSP_MVC/list.do";
		if(num==1) {
			msg = "정상적으로 삭제되었습니다";
		}
		else {
			msg = "삭제에 실패하였습니다";
		}
		
		request.setAttribute("msg",msg);
		request.setAttribute("url",url);
		return "board/message.jsp";	}

}
