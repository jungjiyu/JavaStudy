package com.mvc.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Command {
	public String excute(HttpServletRequest request, HttpServletResponse response);// 뷰페이지 반환
}
