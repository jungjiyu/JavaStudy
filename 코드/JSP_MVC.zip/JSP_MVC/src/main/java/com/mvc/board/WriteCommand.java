package com.mvc.board;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WriteCommand implements Command{

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response) {
		String writer= request.getParameter("writer");
		String title= request.getParameter("title");
		String content= request.getParameter("content");
		BoardDTO dto = new BoardDTO();
		dto.setWriter(writer);
		dto.setTitle(title);
		dto.setContent(content);
		BoardDAO dao = BoardDAO.getInstance();
		int num = dao.boardInsert(dto);
		String msg =null;
		String url = null;
		
		if(num==1) {
			msg = "정상적으로 등록되었습니다";
			url="/JSP_MVC/list.do";
		}
		else {
			msg = "등록에 실패했습니다";
			url="/JSP_MVC/writeForm.do";
		}
		request.setAttribute("msg", msg);
		request.setAttribute("url", url);
		
		return "board/message.jsp";
	}

}
