package com.mvc.board;

public class Paging {
	private static final int VIEW_POSTS_NUM =10; // 한 페이지당 보여지는 게시글 수
	private static final int VIEW_PAGE_NUM = 10; // 한 피이지당 보여줄 페이지 수 << [1] [2] [3] [4] ... 같은거
	private int totalPosts; // 총 게시글 수 << db 에서 총 게시글 수를 얻어와야한다
	
	private int currentPage; // 현재 페이지 번호 << 클라이언트에서 전달한 페이지 번호
	private int totalPage; // 게시판 전체 페이지 수
	private int endPage; // 현재 페이지의 끝번호 << 4페이지에 있다면 [10]
	private int startPage; // 현재 페이지의 시작 번호 << 4 페이지에 있다면 [1]
// [1] [2] [3] ... [10] [다음]
// [이전] [11] [12] [13] ... [11] [다음]

	private boolean prev; // 이전 버튼 활성화 여부
	private boolean next; // 다음 버튼 활성화 여부
	
	public Paging(int totalPosts, int currentPage) { // 현재 페이지 번호
		this.totalPosts = totalPosts;
		this.currentPage = currentPage;
		
		pagingMaker();
	}
	
	public void pagingMaker() { // 초기화 용 << 페이지 번호 만들어준다
		// 총 페이지 수 << 총 게시글 수, 한 페이지당 보여질 게시글 수
		totalPage = ((totalPosts -1)/VIEW_POSTS_NUM )+1; 
		System.out.println("총 페이지 수는 : "+totalPage);
		// totalPage =  (int)Math.ceil((double)VIEW_PAGE_NUM/VIEW_POSTS_NUM)  ; 도 가능
		
	// 현재 페이지 유효성 검사
		if(1> currentPage || currentPage> totalPage) {
			currentPage =1;
		}

	// end 페이지 
		endPage = ((currentPage-1)/VIEW_PAGE_NUM +1)*VIEW_PAGE_NUM;
		
	// end page 유효성 검사	
		if( endPage> totalPage) {
			endPage =totalPage;
		}
		
	// start page	
		startPage = ((currentPage-1)/VIEW_PAGE_NUM )*VIEW_PAGE_NUM +1;
			
		// 
		
	// [1] [2] [3] ... [10] [다음]
	// [이전] [11] [12] [13] ... [11] [다음]
		
		prev = (startPage==1)? false:true ;
		next = (endPage==totalPage)? false:true ;
	

	
	}

	public int getTotalPosts() {
		return totalPosts;
	}

	public void setTotalPosts(int totalPosts) {
		this.totalPosts = totalPosts;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public boolean isPrev() {
		return prev;
	}

	public void setPrev(boolean prev) {
		this.prev = prev;
	}

	public boolean isNext() {
		return next;
	}

	public void setNext(boolean next) {
		this.next = next;
	}
	
	
}
