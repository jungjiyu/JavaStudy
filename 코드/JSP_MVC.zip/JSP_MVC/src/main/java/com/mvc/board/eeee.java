package com.mvc.board;

public class eeee {
	public static void main(String[] args) {
		BoardDAO dao = BoardDAO.getInstance();
		int n =dao.getTotalPosts();
		System.out.println(n);
	}

}
