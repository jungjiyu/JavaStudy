package com.mvc.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ContentViewCommand implements Command {

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response) {
		// BoardDTO getContent(int boardId)
		int boardId = Integer.parseInt(request.getParameter("boardId")); // get 방식으로 전달됬건 post 방식으로 전달됬건 클라이언트에게 받은 데이터니까
		BoardDAO dao = BoardDAO.getInstance();
		BoardDTO dto = dao.getContent(boardId);
		request.setAttribute("contentViewDTO", dto);
		

		return "board/contentView.jsp";
	}

}
