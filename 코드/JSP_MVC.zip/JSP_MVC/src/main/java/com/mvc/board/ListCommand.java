package com.mvc.board;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ListCommand implements Command {

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response) {
		
		//1 . currnetPage 받아준다.
		//2.
		String page = request.getParameter("page");//null 값
		int currentPage= 0;
		if (page==null || page =="") {
			currentPage= 1;
		}
		else {
			currentPage= Integer.parseInt(page);
		}
		
		BoardDAO dao = BoardDAO.getInstance();
		int totalPost = dao.getTotalPosts(); 
		Paging paging = new Paging(totalPost, currentPage);
		
		// 1페이지 >> 글번호 1번 , 2페이지 >> 글번호 11번 ,
		currentPage = paging.getCurrentPage();
		int start = (currentPage-1)*10 +1;
		int end = (currentPage)*10;
		
		ArrayList<BoardDTO> list = dao. boardList(start,end); // element >> dto 객ㅊ
//	private Timestamp boardDate;
		
		for(int i = 0 ; i <list.size();i++) {
			//list.get(i).getBoardDate().getTime()
			long boardDate =list.get(i).getBoardDate().getTime() ;
			long currentTime=  System.currentTimeMillis();
			long passedHour= (boardDate - currentTime)/ (1000 * 60 * 60 * 24);
			System.out.println("이전시간:"+boardDate+" 지금시간:"+(currentTime));

			if(passedHour<1) {
				list.get(i).setNewMark(true);
			}
			
		}
		
		// dto 객체의 boardDate 를 활용해서 newMark 여부 활서오하
			// 24시간이 지나지 않았다면 new 마크 표시
				
		// 현재 시간을 밀리 세컨드로 받아오는 메서드
		
		
		// 현재 시간을 읽어 밀리 세컨드를 long 타입으로 바노한
		// timestamp 객체의 getTime 메서드는 그시간의 값을 long 타입으로 반환
		
		
		request.setAttribute("list",list);	
		request.setAttribute("paging",paging);
		
		HttpSession session = request.getSession();    //세션 객체 만들기
		session.setAttribute("cp",currentPage);
		
		
		

		
		return "board/list.jsp";
	}

}
