package com.mvc.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ModifyCommand implements Command {

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response) {
		//	public int boardUpdate(BoardDTO dto) {
			// title, content를 변경

		String title = request.getParameter("title");
		String content = request.getParameter("content");
		int boardId = Integer.parseInt(request.getParameter("boardId"));
		BoardDAO dao = BoardDAO.getInstance();
		BoardDTO dto = new BoardDTO();
		dto.setTitle(title);
		dto.setBoardId(boardId);
		dto.setContent(content);
		
		int num = dao.boardUpdate(dto);
		String msg=null;
		String url = "/JSP_MVC/list.do";
		if(num==1) {
			msg = "정상적으로 수정되었습니다";
		}
		else {
			msg = "수정에 실패하였습니다";
		}
		
		request.setAttribute("msg",msg);
		request.setAttribute("url",url);
		return "board/message.jsp";
	}

}
