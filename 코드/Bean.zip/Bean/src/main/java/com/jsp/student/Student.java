package com.jsp.student;

public class Student {
	
	// 자바빈 규약
		// 1. 빈이 패키지화 되있어야한다 << default package 가 아닌. 직접 만든 패키지
		// 2. 기본 생성자를 반드시 가지고 ㅇ있어야한다 << getter setter 로 필드값을 할당할 목적으로 만들어졌으므로, 기본ㄴ 생성자를 가지고 있어야함
		// 3. 멤버 ㄴ변수의 접근자는 private 으로 선언한다
		// 4. 멤버 변수에 접근하기 위한 publid 접근자인 getter , setter 메서드를 만들어 놓아야한다
	

	private int studentID;
	private String name;
	private int age;
	private int grade;
	
	public Student() { }
	
	
	
	// 이클립스 기능을 사용하여 getter setter 만들기
	//alt+shift+s 하고 generate getters and setters 하고 select all

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}
	

}
