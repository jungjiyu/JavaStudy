<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<%-- com.jsp.member 패키지를 만든 후 Member 클래스 만들기
속성 : id pw name age << String String String int
 --%>
 
 <%-- 데이터객체(=빈) 생성 --%>
<jsp:useBean id="member" class = "com.jsp.member.Member" scope="page" /> <%-- <어쩌구> </어쩌구> ==  <어쩌구/> --%>

<jsp:setProperty name="member" property = "id" value="hong" /> 
<jsp:setProperty name="member" property = "age" value="20" /> 
<jsp:setProperty name="member" property = "name" value="홍길동" /> 
<jsp:setProperty name="member" property = "pw" value="1234" /> 

<h2>멤버정보</h2>

id:<jsp:getProperty name="member" property = "id" /> <br>
나이:<jsp:getProperty name="member" property = "age"  /> <br>
이름:<jsp:getProperty name="member" property = "name" /> <br>
비번:<jsp:getProperty name="member" property = "pw" /> <br>

</body>
</html>