<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%-- 데이터객체(=빈) 생성 --%>
<jsp:useBean id="student" class = "com.jsp.student.Student" scope="page" /> <%-- <어쩌구> </어쩌구> ==  <어쩌구/> --%>

<jsp:setProperty name="student" property = "studentID" value="202401" /> 
<jsp:setProperty name="student" property = "age" value="20" /> 
<jsp:setProperty name="student" property = "name" value="홍길동" /> 
<jsp:setProperty name="student" property = "grade" value="1" /> 

<h2>학생정보</h2>
학번:<jsp:getProperty name="student" property="studentID"/><br>
이름:<jsp:getProperty name="student" property="name"/><br>
나이:<jsp:getProperty name="student" property="age"/><br>
학년:<jsp:getProperty name="student" property="grade"/><br>

</body>
</html>