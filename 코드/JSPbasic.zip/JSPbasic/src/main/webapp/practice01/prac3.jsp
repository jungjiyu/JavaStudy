<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%-- Integer 타입의 ArrayListt 생성한 후 로또 번호(1~45)를 6 개 생성 --%>
<%

ArrayList<Integer> lotto = new ArrayList<Integer>();

while(lotto.size()<6){	
int num = (int)(Math.random()*45)+1;

if(!lotto.contains(num)){
lotto.add(num);
}

}


out.print(lotto.toString());

%>

<%-- <b> </b>&nbsp--%>

</body>
</html>