<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>prac01</title>
</head>

<body>
<%-- 선언문으로 이름 , 나이, 전화번호 변수 선언 --%>
<%! 
String name;
String age;
String phone;
%>

<%-- 스크립트로 변수 초기화 --%>
<%
name="홍길동";
age ="10";
phone="010-1234-1234";

%>

<%-- 표현식으로 웹 브라우저에 출력 --%>
<p><%=name %>,<%=age %>,<%=phone %></p>
</body>

</html>