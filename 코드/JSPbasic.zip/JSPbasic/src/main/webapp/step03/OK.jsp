<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>OK</title>
</head>
<body>
	<h2>성인입니다. 주류 구매가 가능합니다</h2>
	<h2><a href="responseForm.html">처음으로 이동</a></h2>
	
</body>
</html>