<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>responseSend.jsp</title>
</head>
<body>
	<%
		String strAge=request.getParameter("age");
		int age = Integer.parseInt(strAge);
		
		if(age>=20){
			response.sendRedirect("OK.jsp?age="+age); 
			//sendRedirect >> 별다른 데이터 없이 단순히 해당 웹 페이지로 이동
			//sendRedirect 를 사용하면서 데이터도 전송 가능(get 방식으로)
		}
		else{
			response.sendRedirect("NG.jsp?age="+age);
		}
	%>

</body>
</html>