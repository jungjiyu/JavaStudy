<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>include1</title>
</head>
<body>
	<h1>include1 페이지</h1>
	<%@include file="include2.jsp" %>
	<h1>다시 include1 페이지</h1>
</body>
</html>