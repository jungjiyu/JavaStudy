<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h1>include3 페이지</h1>
	<jsp:include page="include4.jsp"></jsp:include>
	<h1>다시 include3 페이지</h1>
</body>
</html>