<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>회원정보입력</title>
</head>
<body>
<%-- id , pw , name, age, hobby[checkbox] --%>
<form action="memberInfo.jsp" method="post">
	<h1>인적사항 입력:</h1>
	<p><label>아이디:<input type="text" name="id" ></label></p>
	<p><label>비밀번호:<input type="text" name="pw" ></label></p>
	<p><label>이름:<input type="text" name="name" ></label></p>
	
	<h4>취미:</h4>
	<label>사진:<input type="checkbox" name="hobby" value="photo" ></label>
	<label>요리:<input type="checkbox" name="hobby" value="cook" ></label>
	<input type="submit" value="멤버정보전송">
	</form>

</body>
</html>