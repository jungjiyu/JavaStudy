<%@page import="java.util.Arrays"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>멤버정보</title>
</head>
<body>
<%!
String id;
String pw;
String name;
String[] hobbies;
%>

<%

request.setCharacterEncoding("UTF-8");
id = request.getParameter("id");
name = request.getParameter("name");
pw = request.getParameter("pw");
hobbies = request.getParameterValues("hobby");

%>
<h2>멤버정보</h2>
<img src="trump2.jpg" style="float:left" title=<%=name%>><br>
<p>&nbsp아이디:<%=id %></p>
<p>&nbsp비번:<%=pw %></p>
<p>&nbsp이름:<%=name %></p>
<p>&nbsp취미:<%=Arrays.toString(hobbies)%></p>

</body>
</html>