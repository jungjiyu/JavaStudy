<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>foodOK</title>
</head>
<body>
	<% 
	request.setCharacterEncoding("UTF-8");

	String food = request.getParameter("food");
	String name = request.getParameter("name");
	out.print(food);
	out.print(name);
	
	
	%>
</body>
</html>