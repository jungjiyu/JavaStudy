<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>food form</title>
</head>
<body>
	<h2>좋아하는 음식 이름 작성</h2>
	<form action="forwardEx.jsp" method="post">
		<label>음식이름:
		<input type="text" name="food"></label>
	<input type="submit" value="전송">
	</form>
</body>
</html>