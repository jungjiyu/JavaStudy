<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>forwardEx</title>
</head>
<body>
	<p>으헤헤</p>
	<%	try{
		out.print("----------forwardEx-----");
		 Thread.sleep(1000);
		}catch(Exception e){e.printStackTrace();}
	%>	
	<jsp:forward page ="foodOK.jsp">
		<jsp:param name="name" value="홍길동"></jsp:param>
	</jsp:forward>
	
	
</body>
</html>