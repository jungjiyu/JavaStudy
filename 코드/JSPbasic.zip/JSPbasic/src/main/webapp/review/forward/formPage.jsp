<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>form</title>
</head>
<body>
	<h2>form</h2>
	<form action="forwardPage.jsp" method="post">
		<fieldset>
			<legend>개인정보</legend>
			<p><label>이름: <input type="text" name="name"></label></p>
			<p><label>나이: <input type="text" name="age"></label></p>
			<input type="submit" value="입력">
		</fieldset>
	</form>
</body>
</html>