<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>result</title>
</head>
<body>
	<%
	request.setCharacterEncoding("UTF-8");
	String name = request.getParameter("name");
	String age = request.getParameter("age");
	String host = request.getParameter("host");
	
	out.println("이름:"+name);
	out.println("나이: "+age);
	out.println("호스트: "+host);
	%>

</body>
</html>