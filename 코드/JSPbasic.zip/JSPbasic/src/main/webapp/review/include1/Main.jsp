<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
</head>
<body>
	<jsp:include page="header.jspf"/>
	<h2>여기는 main</h2>
	<jsp:include page="footer.jsp"/>
</body>
</html>