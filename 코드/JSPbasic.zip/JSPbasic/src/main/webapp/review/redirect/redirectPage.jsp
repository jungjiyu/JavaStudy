<%@page import="java.net.URLEncoder"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>redirect</title>
</head>
<body>
	<% 
	request.setCharacterEncoding("UTF-8");
	String name = request.getParameter("name");
	String age = request.getParameter("age");
	name = URLEncoder.encode(name,"UTF-8");
	age = URLEncoder.encode(age,"UTF-8");
	response.sendRedirect("resultPage.jsp?name="+name+"&age="+age);%>
</body>
</html>