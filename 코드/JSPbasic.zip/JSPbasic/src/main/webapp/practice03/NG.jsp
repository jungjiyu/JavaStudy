<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>NG</title>
</head>
<body>
	<h2>정답아닙니다</h2>
	<h2><a href="formEx.html">처음으로 이동</a></h2>
</body>
</html>