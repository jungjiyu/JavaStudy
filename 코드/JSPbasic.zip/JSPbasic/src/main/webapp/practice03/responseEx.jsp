<%@page import="java.net.URLEncoder"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>responseEx</title>
</head>
<body>
<%
		request.setCharacterEncoding("UTF-8"); // post 방식으로 받는거니까
	//	response.setContentType("html/text; charset=UTF-8");
		String ans=request.getParameter("ans");
		
		try{
		out.print("~~ responseEx~~");
		 Thread.sleep(1000);
		}catch(Exception e){e.printStackTrace();}
		
		if(ans.equals("홍길동")){
		//response.sendRedirect("ok.jsp"); 
		ans = URLEncoder.encode(ans,"UTF-8");
        response.sendRedirect("ok.jsp?ans="+ans); 
		// url 에는 ascii가 아닌 문자를 사용할 수 없다. 그래서 ascii 가 아닌 파라미터의 경우 인코딩을 해주어야한다
		}
		else{
			response.sendRedirect("NG.jsp");
		//	response.sendRedirect("NG.jsp?ans="+ans);
		}
	%>

</body>
</html>