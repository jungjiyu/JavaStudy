<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>r1</title>
</head>

<body>
	<%-- 웹브라우져를 통해 정보를 요청하는 것을 request 라고 하고 이러한 정보는 request 객체가 관리. --%>
	<%-- ㄴ만 아니라 request 객체는 서버와 브라우져의 정보도 얻어올 수 있다 --%>
	<% 
	out.print("server: "+request.getServerName()+"<br>");
	out.print("Context path: "+request.getContextPath()+"<br>");
	out.print("Port:"+request.getServerPort()+"<br>");
	out.print("Protocol: "+request.getProtocol()+"<br>");
	out.print("URL: "+request.getRequestURL()+"<br>");
	out.print("URI: "+request.getRequestURI()+"<br>");
	%>
	
	
	
</body>
</html>