<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h2>학생정보 입력 폼</h2>
	<form action="studentRequest.jsp" method="post"> <!-- 절대경로로 쓰면 /JspBasic/step02/studentRequest.jsp 이다 -->
	<p><label>학번:<input type="text" name="studentID" ></label></p>
	<p><label>이름:<input type="text" name="name" ></label></p>
	<p><label>나이:<input type="text" name="age" ></label></p>
	<h3>동아리:</h3>
	<label>사진:<input type="checkbox" name="circle" value="photo" ></label>
	<label>요리:<input type="checkbox" name="circle" value="cook" ></label>
	<input type="submit" value="학생정보전송">
	</form>

</body>
</html>