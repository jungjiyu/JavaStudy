<%@page import="java.util.Arrays"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title</title>
</head>
<body>
<%!
String studentID;
String name;
String age;
String[] circles;
%>

<%

request.setCharacterEncoding("UTF-8");
studentID = request.getParameter("studentID");
name = request.getParameter("name");
age = request.getParameter("age");
circles = request.getParameterValues("circle");
%>
<h2>학생정보</h2>
<img src="trump.jpg" style="float:right"><br>
<%=studentID %><br>
<%=name %><br>
<%=age %><br>
<%=Arrays.toString(circles) %><br>

</body>

</html>