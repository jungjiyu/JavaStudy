<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>JspPractice</title>
</head>

<body>
<%-- 스크립트릿: JAVA 파일에서 쓰는 모든 것을 쓸 수 있는 자바 영역--%> 
	<%-- 주석도 자바꺼 씀 된다--%> 
<% 
	for(int i = 0 ; i <10 ; i++){
		if(i%2==0){
			out.print("<h3>"+i+"</h3>"); // out >> jsp 페이지서 결과를 출력할때 사용되는ㄴ 출력 스트림 객체
		}
	}
%> 

<% 
	for(int i = 0 ; i <5 ; i++){
%> 
		<h2>장충동왕족발보쌈</h2>
<%
}
%>
<%
int a = 10;
int b = 20;
if(a<b){
%>
	<h1>10은 20 보다 작다</h1>
<% }
else{
%>
	<h1>응 아니야</h1>
<%
}%>
</body>
</html>