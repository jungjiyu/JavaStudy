<%@page import="java.util.Arrays"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>4</title>
</head>
<body>
<%-- <%@ %> : 지시자. JSP 페이지의 전체적인 속성을 지정할떄 사용한다 --%>
<%-- page, include , taglib 지시자가 있다 --%>
	<%-- page: 해당 페이지의 속성을 지정--%>
	<%-- include: 별도의 페이지를 현재 페이지에 삽입--%>
	<%-- taglib: 태그라이브러리의 태그 사용(jstl  을 사용하기 위해 지정) --%>



<%

	int[] ary={1,2,3,4};
	out.println(Arrays.toString(ary));
%>

</body>
</html>