<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%-- 표현식: 결과값을 출력 --%>
<%-- jsp 에서 사용되는 ㅂ변수의 값또는 메서드 호출 등 결과값을 출력하기 위해 샤용 --%>


<%!
	String id = "bing";
	String pw = "1111";
	
	public int sum(int x, int y){
		return x+y;
	}
%>

100+200 = <%=sum(10,20)  %><br>
아이디 = <%= pw  %><br> <%-- 결국 스크립트의 out.print 를 대체한다 --%>

</body>

</html>