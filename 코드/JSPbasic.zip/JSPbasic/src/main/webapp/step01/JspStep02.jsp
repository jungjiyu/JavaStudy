<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%-- 선언문 : JSP 내에서 사용되는 전역변수(지역변수는 놉) 혹은 메서드를 선언할 떄 사용 --%>
	<%--- 스크립틀리에서 선언된 변수는 지역 변수--%>
<%!
	String name = "봉길동";
	int age = 100;
	
	public int sum(int x , int y){
		return x+y;
	}
%>

<%

	out.print(sum(10,20));

%>
</body>
</html>