<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>

<body>
	<%
		if(request.getParameter("popup")!=null){
			String popVal = request.getParameter("popup");
			if(popVal.equals("notshow")){
				Cookie cookie = new Cookie("popup","notshow");
				cookie.setPath("/"); // 패스 설정은 주로 류트로 많이 함
				 cookie.setMaxAge(60*60*24); //24시간
				response.addCookie(cookie);
				 
				 out.print("<script>");
				 out.print("window.close();");// 현재 웹 페지 닫음
				 out.print("</script>");
			}
		}
	
	%>

	<p>공지사항</p>
	<form action="popup.jsp" method="post">
		
	<br><br><br><br><br><br><br><br><br><br>
		24시간 동안 안보기
		<input type="checkbox" name="popup" value="notshow">
		<input type="submit">

	</form>
	
</body>
</html>