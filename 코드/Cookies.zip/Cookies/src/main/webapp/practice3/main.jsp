<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%-- 쿠키 객체의 쿠키 이름이 popup이고 쿠키 값이 not show 인 쿠키가 있다면 팝업창 띄우지 않기 --%>
	<p></p>
	 
 <%
 Cookie[] cookies= request.getCookies();
 boolean flag =true;
 if(cookies!=null){ // 이거 없음 안됨
 for(int i = 0 ; i <cookies.length;i++){
 	String str = cookies[i].getName();
 	
	if(str.equals("popup")){ // 쿠키가 있으면
		
		flag=false;
		break;
		
	}
 }
 }	
 
 
 if(flag){ // 만약 popup 이란 쿠키 자체가 없었으면
	 %>
	 <script> <%-- 자바스트립트의 object 급. 최상위. --%>
		window.open("popup.jsp","_top","width=350, height=550"); <%-- 새창으로 팝업을 만들떄 사용되는 함수 --%>
		// 내부에서 주석 사용 가능능
		// 새 창으로 팝업 만들때사용하는 함수
	</script>
		<%
	}
 
 %>
 



</body>
</html>