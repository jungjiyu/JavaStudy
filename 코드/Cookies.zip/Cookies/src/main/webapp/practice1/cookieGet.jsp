<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h2>련재 디렉터리</h2>

	<%
		Cookie[] cookies= request.getCookies();
		for(int i=0;i<cookies.length;i++){
			String str = cookies[i].getName();
		
		if(str.equals("cookieName")){
	
			out.print("쿠키이름:"+cookies[i].getName()+"<br>");
			out.print("쿠키값:"+cookies[i].getValue()+"<br>");
			out.print("쿠키경로:"+cookies[i].getPath()+"<br>");
			out.print("기타:"+cookies[i]+"<br>");
		}
		}
	%>
	
			<a href="cookieSet.jsp">이전페이지</a><br>
	
</body>
</html>