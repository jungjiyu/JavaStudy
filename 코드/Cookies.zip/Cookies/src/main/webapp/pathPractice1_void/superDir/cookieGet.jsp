<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h2>상위 디렉터리</h2>
	<%
		Cookie[] cookies= request.getCookies();
		for(int i=0;i<cookies.length;i++){
			String str = cookies[i].getName();
		
	
	
			out.print("쿠키이름:"+cookies[i].getName()+"<br>");
			out.print("쿠키값:"+cookies[i].getValue()+"<br>");
			out.print("쿠키경로:"+cookies[i].getPath()+"<br>");
			out.print("<br>");

		
		}
	%>
		<a href="currentDir/cookieSet.jsp">이전페이지</a><br>
	
</body>
</html>