<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>void</title>
</head>
<body>

	<%
		Cookie cookie = new Cookie("cookieName","cookieValue");
		response.addCookie(cookie); // 웹 브라우죠에  저장
		
		
	
	%>
	
	<h2>쿠키 탑재됨</h2>
	<a href="./../cookieGet.jsp">상위 디렉터리에서 쿠키얻기</a><br>
	<a href="cookieGet.jsp">현재 디렉터리에서 쿠키얻기</a><br>
	<a href="subDir/cookieGet.jsp">하위 디렉터리에서 쿠키얻기</a>
	
</body>
</html>