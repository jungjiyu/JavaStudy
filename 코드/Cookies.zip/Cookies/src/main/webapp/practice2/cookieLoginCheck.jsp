<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%-- 
	1. 아이디가 넘어온 데이터 받기
	2. id가 hong 이고 pw = 1234 이면 id 값을 쿠키 값으로 설정하여 쿠키 객체를 생성
		newCookie("id",id);
		
	3. 쿠키 객체를 웹 브라우져에 심음
	4. 리다이렉트를 통하여 cookieMain.jsp 로 이동
	5. id ,pw 기 틀리면 cookieLogin.jps 로 리다이렉트
 --%>
 
 
 <%
 	request.setCharacterEncoding("UTF-8");
 	String id = request.getParameter("id");
 	String pw = request.getParameter("pw");
 	

 	if(id.equals("홍길동") && pw.equals("1234")){
 		Cookie cookie = new Cookie("id",id);
 		response.addCookie(cookie);
 		response.sendRedirect("cookieLogin.jsp");
 	}
 	else{
 		response.sendRedirect("cookieMain.jsp"); 		
 	}

 %>
</body>
</html>