<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%-- 
	
	request 객체를 사용하여 모든 쿠키 객체들을 배열로 얻은 후
	쿠키값이 "hong"인 쿠키가 있다면 웹브라우져에 홍길동님 안녕하세요 출력
	
	 --%>
	 <%
	 
	 Cookie[] cookies = request.getCookies();
	 for(int i  = 0 ; i < cookies.length ; i++){
		 if(cookies[i].getValue().equals("hong")){
			 out.print("홍");
		 }
	 }
	 %>
	 
	 <a href="cookieLogout.jsp">로그아웃</a>
</body>
</html>