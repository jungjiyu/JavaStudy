<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%-- 
	
	쿠키값이 "hong" 인 쿠키 삭제하고 삭제 후에 리다이렉트로 cookieLogin.jsp 로  이동 요청
	 --%>
	 
	 <%
	 
	 Cookie[] cookies= request.getCookies();
	 for(int i = 0 ; i <cookies.length;i++){
	 
	 	 if(cookies[i].getValue().equals("hong")){
	 		cookies[i].setMaxAge(0);//유효시간을 0으로 설정
	 		response.addCookie(cookies[i]);//변경된 쿠키 객체를 웹 브라우져에 저장
	 	}
	 }
	 response.sendRedirect("cookieMain.jsp");
	 %>
</body>
</html>