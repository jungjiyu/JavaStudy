<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%-- 로그인 폼 만들기 id. pw
		cookieLoginCheck 로 보냄
	 --%>
	 <form action="cookieLoginCheck.jsp" method="post">
	 	아이디:<input type="text" name="id"><br>
	 	비번:<input type="text" name="pw">
	 	<input type="submit">
	 </form>
</body>
</html>