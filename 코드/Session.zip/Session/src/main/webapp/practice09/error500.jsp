<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
 <%@ page isErrorPage="true" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<%
	response.setStatus(200); // 기본 세팅. 안해도 문제는 없지만 안전하게 해준다.
	out.print("에러 500: "+exception.getMessage());
%>
</body>
</html>