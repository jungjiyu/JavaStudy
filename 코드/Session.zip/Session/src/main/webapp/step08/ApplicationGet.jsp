<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>get</title>
</head>
<body>
<% 	
	String str = (String)application.getAttribute("applicationName");
	if(str!=null){
	out.print("값: "+ str);
	out.print("<br>");
	}
	
	application.removeAttribute("applicationName");
	str = (String)application.getAttribute("applicationName");
	out.print("삭제하고남은값: ");out.print(str);
%>
</body>
</html>