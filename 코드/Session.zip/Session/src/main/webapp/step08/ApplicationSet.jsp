<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Applicationset</title>
</head>
<body>
<%

	application.setAttribute("applicationName","applicationValue");
%>	
	<a href="ApplicationGet.jsp">어플리케이션 얻기</a>


</body>
</html>