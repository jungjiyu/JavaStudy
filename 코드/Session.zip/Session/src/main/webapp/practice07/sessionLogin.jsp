<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>login</title>
</head>
<body>
	 <form action="sessionLoginCheck.jsp" method="post">
	 	<fieldset>
	 		<legend>로그인폼</legend>
	 	<p><label>아이디:<input type="text" name="id"></label></p>
	 	<p><label>비번:<input type="text" name="pw"></label></p>
	 	<input type="submit" value="로그인">
	 	
	 	</fieldset>
	 </form>
</body>
</html>