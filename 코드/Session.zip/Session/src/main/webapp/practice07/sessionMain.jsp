<%@page import="java.util.Enumeration"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Main</title>
</head>
<body>
<%-- 
	
	request 객체를 사용하여 모든 쿠키 객체들을 배열로 얻은 후
	쿠키값이 "hong"인 쿠키가 있다면 웹브라우져에 홍길동님 안녕하세요 출력
	
	 --%>
	 <%

	// 세션안에 저장된 이름들을 불러오는 목록
	String sName;
	String sValue;
	
	Enumeration e = session.getAttributeNames();
	while(e.hasMoreElements()){
		sName = (String)e.nextElement();
		sValue = session.getAttribute(sName).toString(); // 혹은 parent instanceof child 사용  >> Child c = (Child)p;
		if(sName.equals("id")&&sValue.equals("sung")){
			out.print("안녕하세요 sunggildong님<br>");
			
			out.print("<br>");
			 out.print("세션이름:"+sName+"<br>");
			out.print("세션값:"+sValue+"<br>");
			String sessionID = session.getId();
			out.print("아이디: "+sessionID+"<br>"); // JsessionId 값으로 저장됨 << 서버가 자동 생성 시키는 쿠키 << 세션 쿠키로 저장됨.
			// 세션 유효시간 얻기
			int sessionInter = session.getMaxInactiveInterval();
			out.print("세션 유효 시간:" +sessionInter/60.0+"분. 즉,"+sessionInter+"초 <br>");
			
			

		}

	
	}
	
	
%>
	 <a href="sessionLogout.jsp">로그아웃</a>	

	

</body>
</html>