<%@page import="java.util.Enumeration"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>logout</title>
</head>
<body>
<% 
	out.print("<br>");
	 Enumeration e = session.getAttributeNames();
	 String sName;
	 String sValue;

	while(e.hasMoreElements()){
		sName = (String)e.nextElement();
		sValue = session.getAttribute(sName).toString(); // 혹은 parent instanceof child 사용  >> Child c = (Child)p;
		if(sName.equals("id")&&sValue.equals("sung")){
			session.removeAttribute("id");
			out.print("sunggildong님이 로그아웃되었습니다");
	
	}
	}

	
	out.print("<br>남은 세션객체들:<br>");
	e = session.getAttributeNames();
	
	while(e.hasMoreElements()){
		sName = (String)e.nextElement();
		sValue = session.getAttribute(sName).toString(); // 혹은 parent instanceof child 사용  >> Child c = (Child)p;
		
		out.print(sName+": "+sValue+"<br>");
	
	
	}
	

	%>
</body>
</html>