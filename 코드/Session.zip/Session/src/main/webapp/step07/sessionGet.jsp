<%@page import="java.util.Enumeration"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
	String name = (String)session.getAttribute("sessionName");
	int number = (int)session.getAttribute("sessionNumber");
	out.print("sessionName값: "+name+"<br>");
	out.print("sessionNumber값: "+number+"<br>");

	out.print("<br>");
	// 세션안에 저장된 이름들을 불러오는 목록
	String sName;
	String sValue;
	
	Enumeration e = session.getAttributeNames();
	while(e.hasMoreElements()){
		sName = (String)e.nextElement();
		sValue = session.getAttribute(sName).toString(); // 혹은 parent instanceof child 사용  >> Child c = (Child)p;
		out.print("세션이름:"+sName+"<br>");
		out.print("세션값:"+sValue+"<br>");
	
	}
	
	// 세션 아이디 얻기
	
	String sessionID = session.getId();
	out.print("아이디: "+sessionID+"<br>"); // JsessionId 값으로 저장됨 << 서버가 자동 생성 시키는 쿠키 << 세션 쿠키로 저장됨.
	
	// 세션 유효시간 얻기
	int sessionInter = session.getMaxInactiveInterval();
	out.print("세션 유효 시간:" +sessionInter/60.0+"분. 즉,"+sessionInter+"초 <br>");
	
	session.removeAttribute("sessionName");
	
	//일회성이라 다시 객체를 얻어와야됨 << 그러니까 업데이트가 안된단 소리

	
	out.print("<br>");
	 e = session.getAttributeNames();
	while(e.hasMoreElements()){
		sName = (String)e.nextElement();
		sValue = session.getAttribute(sName).toString(); // 혹은 parent instanceof child 사용  >> Child c = (Child)p;
		out.print("세션이름:"+sName+"<br>");
		out.print("세션값:"+sValue+"<br>");
	
	}
	
	// 세션 무효화. 모든 세션 삭제
	out.print("<br>");
	session.invalidate();
	if(request.isRequestedSessionIdValid()){ // 유효한 세션이 있는지 확인 후 있으면 true, 반환
		out.print("유효 세션 있음<br>");
	}else{
		out.print("유효 세션 없음<br>");

	}
	
%>

</body>
</html>