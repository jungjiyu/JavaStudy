<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%

int count =0;
if( application.getAttribute("visit") != null){
count = (int)application.getAttribute("visit");
}
count++;
application.setAttribute("visit",count);

%>
</body>
</html>