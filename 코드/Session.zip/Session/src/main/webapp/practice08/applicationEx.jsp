<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>누적집계</title>
</head>
<body>
<!-- 어플리케이션 객체를 사용하여 페이지 방문시 방문자수 증가시키기 -->

<%

Integer val= (Integer)application.getAttribute("visitor");

if(val == null){
	application.setAttribute("visitor",1);
	
}else{
	int current = (int)application.getAttribute("visitor");
	application.setAttribute("visitor", current+1);
}

int total= (int)application.getAttribute("visitor");
out.print("총 방문자수는 :"+total);

%>
<p><a href="InitalizeApplication.jsp">방문자수 초기화 하기</a></p>

</body>
</html>