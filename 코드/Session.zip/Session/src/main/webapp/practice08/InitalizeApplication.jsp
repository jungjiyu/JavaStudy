<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>initalize</title>
</head>
<body>
<%
application.removeAttribute("visitor");
response.sendRedirect("applicationEx.jsp");
%>
</body>
</html>