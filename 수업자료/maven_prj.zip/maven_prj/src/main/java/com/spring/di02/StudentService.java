package com.spring.di02;

public class StudentService {
	
	private Student student;
	
	// setter 메소드
	public void setStudent(Student student) {
		this.student = student;
	}
	
	public void studentProfile() {
		
		System.out.println("---------------------");
		System.out.println("학번 : " + student.getStudentID());
		System.out.println("이름 : " + student.getName());
		System.out.println("나이 : " + student.getAge());
		System.out.println("전공 : " + student.getMajor());
		System.out.println("동아리 : " + student.getCircles());
		System.out.println("---------------------");
	}
	
	
	
	
}
