package com.spring.aop03;

import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

// 해당 클래스는 공통기능을 모아놓은 Aspect 역할의 클래스라는 것을
// 명시하기 위해 해당 클래스 위래 @Aspect 어노테이션을 설정한다.

@Aspect
public class LogAop {
	
	private final static Logger LOG = Logger.getGlobal();
	
	// 모든 리턴타입의 com.spring.aop03 패키지의 Bank 클래스의 모든 메소드
	@Pointcut("execution(* com.spring.aop03.Bank.*(..))")
	private void pointCutMethod() {}
	// 포인트컷 식별용으로서 사용하기 위해 구현로직이 없는(내부가 비어있는)
	// 메소드를 만들어 메소드 위에 @PointCut 어노테이션을 설정한다.
	
	// @Before("식별용 메소드")
	@Before("pointCutMethod()")
	public void beforeLog(JoinPoint jp) {
		LOG.info(jp.getSignature().getName() + " 메소드 start");
	}
	
	@After("pointCutMethod()")
	public void afterLog(JoinPoint jp) {
		LOG.info(jp.getSignature().getName() + " 메소드 end");
	}
	
	@Around("pointCutMethod()")
	public Object aroundAop(ProceedingJoinPoint joinPoint) throws Throwable{
		
		long start = System.nanoTime();
		
		try {
			
			Object obj = joinPoint.proceed(); // 핵심기능 실행
			
			return obj;
			
		}finally {
			
			 long end = System.nanoTime();
			 
			 System.out.println("메소드 걸린시간 : " + (end-start) + "ns");
			
		}
		
		
	}

}
