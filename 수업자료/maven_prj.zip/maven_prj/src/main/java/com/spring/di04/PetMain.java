package com.spring.di04;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PetMain {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = 
				new AnnotationConfigApplicationContext(ApplicationConfig.class);
		
		Pet pet = context.getBean("myPet2", Pet.class);
		
		System.out.println(pet.getDog());
		System.out.println();
		
		PetService service = context.getBean("petService", PetService.class);
		
		service.petProfile();
		
		context.close();

	}

}
