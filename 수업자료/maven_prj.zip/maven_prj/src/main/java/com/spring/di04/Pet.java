package com.spring.di04;

public class Pet {
	
	private String dog;
	private String cat;
	private String fish;
	private String duck;
	
	public Pet(String dog, String cat) {
		this.dog = dog;
		this.cat = cat;
	}

	public String getDog() {
		return dog;
	}

	public void setDog(String dog) {
		this.dog = dog;
	}

	public String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}

	public String getFish() {
		return fish;
	}

	public void setFish(String fish) {
		this.fish = fish;
	}

	public String getDuck() {
		return duck;
	}

	public void setDuck(String duck) {
		this.duck = duck;
	}
	
	
	

}
