package com.spring.di05;

import org.springframework.context.support.GenericXmlApplicationContext;

public class LoginMain {

	public static void main(String[] args) {
		
//		LoginInfo info = new LoginInfo();
//		
//		info.loginInformation();
		
		GenericXmlApplicationContext context = 
				new GenericXmlApplicationContext("classpath:applicationConfig04.xml");
		
		LoginInfo info = context.getBean("loginInfo", LoginInfo.class);
		
		info.loginInformation();
		
		context.close();
		

	}

}





