package com.spring.di03;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MemberMain {

	public static void main(String[] args) {
		
		// GenericXmlApplicationContext 스프링 컨테이너 객체 생성 후 
		// MemberService 타입의 객체를 얻은 후 memberProfile 메소드 호출하기
		
		GenericXmlApplicationContext context = 
				new GenericXmlApplicationContext("classpath:applicationConfig03.xml");
		
		
		MemberService service = context.getBean("memberService", MemberService.class);
		
		service.memberProfile();
		System.out.println();
		
		// Spring은 객체들을 기본적으로 싱글톤화 시켜 관리해준다.
		// 싱글톤 : 조회할때마다 클라이언트에게 같은 빈을 반환해준다.
		
		Member member1 = context.getBean("member", Member.class);
		Member member2 = context.getBean("member", Member.class);
		
		if(member1 == member2) {
			System.out.println("같은 객체 입니다.");
		}else {
			System.out.println("다른 객체 입니다.");
		}
		
		member1.setAge(28);
		member1.setName("성춘향");
		
		System.out.println(member2.getName());
		System.out.println(member2.getAge());
		
		
		context.close();
		
		

	}

}






