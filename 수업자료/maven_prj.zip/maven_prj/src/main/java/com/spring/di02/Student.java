package com.spring.di02;

import java.util.List;

public class Student {
	
	private int studentID;
	private String name;
	private int age;
	private String major;
	private List<String> circles;
	
	// 기본생성자
	public Student() {
		
	}

	// 초기화생성자
	public Student(int studentID, String name, int age, String major, List<String> circles) {
		super();
		this.studentID = studentID;
		this.name = name;
		this.age = age;
		this.major = major;
		this.circles = circles;
	}
	
	// getter / setter 메소드

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public List<String> getCircles() {
		return circles;
	}

	public void setCircles(List<String> circles) {
		this.circles = circles;
	}
	
	
	

}
