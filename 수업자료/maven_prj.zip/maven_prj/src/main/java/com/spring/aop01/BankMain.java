package com.spring.aop01;

public class BankMain {

	public static void main(String[] args) {
		
		Bank myBank = new Bank();
		
		myBank.deposit();
		
		System.out.println();
		
		myBank.withdraw();
		
		
	}

}
