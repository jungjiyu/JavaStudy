package com.spring.di01;

public class BHCChicken implements ChickenHouse {

	@Override
	public void chickenCook() {
		System.out.println("BHC 치킨을 요리합니다.");
	}

}
