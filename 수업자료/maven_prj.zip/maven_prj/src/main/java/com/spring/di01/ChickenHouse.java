package com.spring.di01;

public interface ChickenHouse {
	
	public void chickenCook();

}
