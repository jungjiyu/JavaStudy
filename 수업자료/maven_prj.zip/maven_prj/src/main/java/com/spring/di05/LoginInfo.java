package com.spring.di05;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class LoginInfo {
	
	// @Autowired : 객체를 자동 주입할때 사용하는 어노테이션
	// 의존 객체의 "타입" 에 해당하는 "빈"을 찾아 주입한다.
	// 필드, 생성자, 메소드 주입이 있다.
	
	@Autowired(required = false)
	// false 로 지정하면 해당 빈객체가 존재하지 않더라도
	// 예외를 발생시키지 않는다.
	@Qualifier("member2")
	// 타입으로 의존객체를 찾아 주입하기 때문에 @Qualifier 어노테이션으로
	// 빈의 아이디를 지정하여 어떤 빈을 선택하는지 알려준다.
	private Member member;
	
	
	
	// 기본생성자
	public LoginInfo() {
		
	}
	
	//@Autowired
	public LoginInfo(Member member) {
		this.member = member;
	}
	
	//@Autowired
	public void setMember(Member member) {
		this.member = member;
	}
	
	public void loginInformation() {
		
		if(member == null) {
			System.out.println("아이디와 비밀번호 정보가 없습니다.");
			return;
		}
		
		if(member.getId() != null && member.getPw() != null) {
			System.out.println("로그인이 되었습니다.");
			System.out.println("아이디 : " + member.getId());
			System.out.println("비밀번호 : " + member.getPw());
		}else{
			System.out.println("아이디와 비밀번호 정보가 없습니다.");
		}
		
		
	}

}












