package com.spring.di01;

import org.springframework.context.support.GenericXmlApplicationContext;

public class ChickenMain {

	public static void main(String[] args) {
		
		ChickenOrder order = new ChickenOrder();
		
		order.chickenOrder();
		
		System.out.println();
		
		ChickenOrder order2 = new ChickenOrder(new BBQChicken());
		order2.chickenOrder();
		
		System.out.println();
		
		// 스프링에서는 의존객체들을 생성하고 서로 연결(조립, 주입)해주는 
		// 컨테이너가 있는데 그것이 스프링 IoC 컨테이너이다.
		// 컨테이너에 의존 객체들을 설정하는 설정파일은 xml 파일과 자바파일이 있다.
		
		GenericXmlApplicationContext context = 
				new GenericXmlApplicationContext("classpath:applicationConfig01.xml");
		
		// GenericXmlApplicationContext 는 xml 파일에 정의된 
		// 설정정보를 읽어와서 객체를 생성하고 각각의 객체를 연결한 뒤에 내부적으로 보관한다.
		// 스프링 컨테이너는 생성한 빈 객체를 (이름, 객체) 의 형태로 보관한다.
		// 보관하고 있는 객체를 사용하고 싶은경우 빈 객체와 연결되어 있는 이름으로 해당 객체를 얻을 수 있다.
		
		
		ChickenOrder order3 = context.getBean("myOrder", ChickenOrder.class);
		// getBean 메소드를 호출하여 첫번째 인자로 빈의 이름을 문자열로 주고
		// 두번째 인자로는 해당 빈 객체의 타입을 명시하여 객체를 얻을 수 있다.
		
		order3.chickenOrder();
		
		context.close();
		
		
	}

}











