package com.spring.di02;

import org.springframework.context.support.GenericXmlApplicationContext;

public class StudentMain {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext context = 
				new GenericXmlApplicationContext("classpath:applicationConfig02.xml");
		
		StudentService service = context.getBean("stuService", StudentService.class);
		
		service.studentProfile();
		
		context.close();
		
	}

}
