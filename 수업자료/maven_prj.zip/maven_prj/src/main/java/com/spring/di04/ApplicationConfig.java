package com.spring.di04;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// 스프링 IoC 컨테이너가 해당 클래스 파일을 스프링 설정파일로 인식하여
// 사용할 수 있도록 해당 클래스 위에 @Configuration 어노테이션을 붙여준다.

@Configuration
public class ApplicationConfig {
	
	// @Bean 어노테이션을 사용하여 해당 메소드가 반환하는 객체를 
	// 스프링이 관리하는 빈 객체로 등록한다.
	// 빈의 이름은 메소드 이름을 사용한다. 하지만 이름을 직접 부여할 수도 있다.
	@Bean(name="myPet2")
	public Pet myPet() {
		
		Pet pet = new Pet("멍멍이", "야옹이");
		
		pet.setFish("니모");
		pet.setDuck("꽥꽥이");
		
		return pet;
	}
	
	@Bean
	public PetService petService() {
		
		PetService petService = new PetService(myPet());
		
		return petService;
	}
	
	
}








