package com.spring.di01;

public class ChickenOrder {
	
	private ChickenHouse chicken;
	// 변수를 인터페이스 타입으로 설정하면 객체들의 타입을 통일시켜 주어
	// 개발코드는 인터페이스에 정의된 메소드만 호출하면 된다.
	// 즉 객체를 구현하는 코드와 객체를 사용하는 코드를 완전히 분리시켜
	// 객체를 사용하는 코드를 수정할 필요가 없다. (즉 유지보수가 쉬워진다.)
	
	
	public ChickenOrder() {
		//chicken = new BBQChicken();
		chicken = new BHCChicken();
	}
	
	// 직접 new 연산자를 사용하여 객체를 생성할 수도 있지만
	// 의존객체를 주입받아 사용할 수 있다.
	public ChickenOrder(ChickenHouse chicken) {
		this.chicken = chicken;
	}
	
	
	public void chickenOrder() {
		System.out.println("치킨을 주문합니다.");
		chicken.chickenCook();
	}
	
	// Dependency(의존) 이란
	// A클래스의 기능을 사용할때 B클래스의 기능을 이용하는 것을 말한다.
	// A객체가 B객체에 의존한다. 라고 말한다.
	// 즉 B객체의 기능을 사용하지 않으면 작동할 수 없다.
	// B 객체의 기능이 변경되면 A객체에 영향을 미친다.
	
	
	// DI(Dependency Injection) 
	// 의존하는 객체를 직접 생성하는 대신 의존객체를 전달받는 방식이다.
	// 사용이유 : 의존객체의 변경의 유연함 때문이다.
	// (의존객체가 여러 클래스에서 사용되었을시 의존객체를 전달해주는 코드만 변경하면 된다.)
	
	
	

}
