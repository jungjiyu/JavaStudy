package com.spring.aop01;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Bank {
	
	private static final Logger LOG = Logger.getGlobal();
	
	FileHandler fh;
	
	public Bank() {
		
		try {
			
			fh = new FileHandler("C:\\aaa\\myLog%g.txt", 2000, 1000, true);
			//  new FileHandler("파일명", 파일크기, 파일갯수, 이어쓰기 여부);
			// %g : 로그의 로테이션을 식별하는 생성번호
			
			fh.setLevel(Level.ALL);
			// 디폴트 레벨을 지정한다. 디폴트는 Level.ALL
			
			fh.setFormatter(new SimpleFormatter());
			
			LOG.addHandler(fh);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void deposit() {
		LOG.info("deposit 메소드 start");
		System.out.println("통장에 돈을 입금합니다.");
		LOG.info("deposit 메소드 end");
	}
	
	public void withdraw() {
		LOG.info("withdraw 메소드 start");
		System.out.println("통장에 돈을 출금합니다.");
		LOG.info("withdraw 메소드 end");
	}
	
	// 이렇게 핵심기능과 공통기능이 분리되어있지 않고 소스코드 결합되어 있다면
	// 일일이 공통기능을 핵심기능에 적용해야 하는 코드를 일일이 작성해주어야 함으로 
	// 반복적이고 힘든 작업이 될 것이다.
	// 또한 공통 기능에 해당하는 메소드의 수정사항(추가, 변경 등)이 있을 경우
	// 모든 공통 기능을 작성한 곳에 수정작업이 이루어져야 한다.
	

}







