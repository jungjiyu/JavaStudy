package com.spring.di01;

public class BBQChicken implements ChickenHouse {

	@Override
	public void chickenCook() {
		System.out.println("BBQ 치킨을 요리합니다.");
	}

}
