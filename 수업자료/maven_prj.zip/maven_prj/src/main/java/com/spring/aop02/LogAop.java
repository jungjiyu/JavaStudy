package com.spring.aop02;

import java.util.logging.Logger;

import org.aspectj.lang.ProceedingJoinPoint;

public class LogAop {
	
	private final static Logger LOG = Logger.getGlobal();
	
	public void beforeLog() {
		LOG.info("메소드 start");
	}
	
	public void afterLog() {
		LOG.info("메소드 end");
	}
	
	public Object aroundAop(ProceedingJoinPoint joinPoint) throws Throwable{
		// Around 어드바이스는 다른 어드바이스와는 다르게 
		// 반드시 ProceedingJoinPoint 객체를 매개변수로 받아야한다.
		// 반환타입은 Object 타입으로 선언한다.
		
		long start = System.nanoTime();
		
		try {
			
			Object obj = joinPoint.proceed(); // 핵심기능 실행
			// proceed 메소드를 호출하면 타겟(핵심기능) 메소드가 동작한다.
			
			return obj;
			
		}finally {
			
			 long end = System.nanoTime();
			 
			 System.out.println("메소드 걸린시간 : " + (end-start) + "ns");
			
		}
		
		
	}
	

}








