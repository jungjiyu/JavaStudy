package com.spring.aop02;

import org.springframework.context.support.GenericXmlApplicationContext;

public class BankMain {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext context = 
				new GenericXmlApplicationContext("classpath:aopConfig01.xml");
		
		Bank myBank = context.getBean("myBank", Bank.class);
		
		myBank.deposit();
		
		System.out.println();
		
		myBank.withdraw();
		
		context.close();
		

	}

}
