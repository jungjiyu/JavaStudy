package com.spring.di04;

public class PetService {
	
	private Pet pet;
	
	public PetService(Pet pet) {
		this.pet = pet;
	}
	
	public void petProfile() {
		System.out.println("## 애완 동물 리스트 보기 ##");
		System.out.println("강아지 : " + pet.getDog());
		System.out.println("고양이 : " + pet.getCat());
		System.out.println("물고기 : " + pet.getFish());
		System.out.println("오리  : " + pet.getDuck());
		System.out.println("#######################");
	}

}
