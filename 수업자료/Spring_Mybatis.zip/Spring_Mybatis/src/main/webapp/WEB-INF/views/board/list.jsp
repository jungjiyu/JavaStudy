<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>  
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"  %>  
    
<!DOCTYPE html> 
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

<style>
	*{
		text-align: center;
		margin: 0 auto;
	}
</style>

</head>
<body>

	<c:if test="${msg != null }">
	
		<script>
			alert('${msg}');
		</script>
	
	</c:if>
	
	<br><hr>
	<h2><a href="/web/board/list">게시판 목록</a></h2>
	<hr><br>
	
	<form action="/web/board/list">
		
		<select name="searchWord">
			<option ${param.searchWord == 'writer' ? 'selected' : ''} value="writer">작성자</option>
			<option ${param.searchWord == 'title' ? 'selected' : ''} value="title">제목</option>
			<option ${param.searchWord == 'content' ? 'selected' : ''} value="content">내용</option>
		</select>
		
		<input type="text" name="key" placeholder="검색어를 입력해주세요" value="${param.key}" >
		
		<input type="submit" value="검색">
		
	</form>
	
	
	<table border="1">
		
		<tr>
			<th>글번호</th>
			<th>작성자</th>
			<th>제목</th>
			<th>작성일</th>
			<th>조회수</th>
		</tr>
		
		<c:forEach var="dto" items="${list}" >
			
			<tr>
				<td>${dto.id}</td>
				<td>${dto.writer}</td>
				<td>
					<a href="/web/board/contentView?id=${dto.id}&page=${param.page}&searchWord=${param.searchWord}&key=${param.key}">
						${dto.title}
					</a>
					
					<%-- newMark  --%>
					
					<c:if test="${dto.newMark == true}">
						<span style="color:orange">[new]</span>
					</c:if>
					
					
				</td>
				<td>
					<fmt:formatDate value="${dto.regDate}" pattern="yyyy년 MM월 dd일" />
				</td>
				<td>${dto.viewCount}</td>
			</tr>
		
		</c:forEach>
		
		<tr>
			<td colspan="5">
				<a href="/web/board/write">글 작 성</a>
			</td>
		</tr>
		
	</table>
	
	
	<c:if test="${paging.prev}">
		<a href="/web/board/list?page=${paging.startPage-1}&searchWord=${param.searchWord}&key=${param.key}">
			[이전]
		</a>
	</c:if>
	
	<c:forEach var="pageNum" begin="${paging.startPage }" end="${paging.endPage }">
		
		<a href="/web/board/list?page=${pageNum}&searchWord=${param.searchWord}&key=${param.key}"
			style="${pageNum == paging.currentPage ? 'color:red' : 'color:blue'}">
			[${pageNum}]
		</a>
	
	</c:forEach>
	
	
	<c:if test="${paging.next}">
		<a href="/web/board/list?page=${paging.endPage+1}&searchWord=${param.searchWord}&key=${param.key}">
			[다음]
		</a>
	</c:if>
	
	
</body>
</html>






