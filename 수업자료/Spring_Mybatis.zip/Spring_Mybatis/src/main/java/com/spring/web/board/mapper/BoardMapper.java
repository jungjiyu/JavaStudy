package com.spring.web.board.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.spring.web.board.dto.BoardDTO;

public interface BoardMapper {
	
	public List<BoardDTO> boardList(@Param("searchWord")String searchWord, 
									@Param("key")String key, 
									@Param("postStart")int postStart, 
									@Param("postEnd")int postEnd);
	
	public int totalCount(@Param("searchWord")String searchWord, 
						@Param("key")String key);
	
	
	public int boardInsert(BoardDTO dto);
	
	public BoardDTO getContent(int id);
	
	public void upViewCount(int id);
	
	public int boardUpdate(BoardDTO dto);
	
	public int boardDelete(int id);
	
}
