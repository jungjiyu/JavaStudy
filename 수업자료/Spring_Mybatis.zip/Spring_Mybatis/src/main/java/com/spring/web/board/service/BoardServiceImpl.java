package com.spring.web.board.service;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.spring.web.board.dto.BoardDTO;
import com.spring.web.board.mapper.BoardMapper;
import com.spring.web.board.paging.Paging;
import com.spring.web.board.search.SearchVO;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardMapper mapper;
	
	
	@Override
	public List<BoardDTO> boardList(Integer page, SearchVO search, Model model) {
		
		int totalCount = mapper.totalCount(search.getSearchWord(), search.getKey());
		
		Paging paging = new Paging(totalCount, page);
		
		int postStart = (paging.getCurrentPage() -1) * 10 + 1;
		
		int postEnd = paging.getCurrentPage() * 10;
		
		List<BoardDTO> list = mapper.boardList(search.getSearchWord(), search.getKey(), postStart, postEnd);
		
		for(BoardDTO dto : list) {
			
			long nowTime = System.currentTimeMillis();
			
			Timestamp regDate = dto.getRegDate();
			
			long regTime = regDate.getTime();
			
			if((nowTime - regTime) < (1000 * 60 * 60 * 24)) {
				dto.setNewMark(true);
			}
			
		}
		
		
		
		
		
		model.addAttribute("paging", paging);
		
		return list;
	}

	@Override
	public int boardInsert(BoardDTO dto) {
		
		if(dto != null) {
			return mapper.boardInsert(dto);
		}
		return 0;
	}

	@Override
	public BoardDTO getContent(Integer id) {
		
		if(id != null) {
			
			upViewCount(id);
			return mapper.getContent(id);
			
		}
		
		return null;
	}

	@Override
	public void upViewCount(Integer id) {
		
		if(id != null) {
			mapper.upViewCount(id);
		}

	}

	@Override
	public int boardUpdate(BoardDTO dto) {
		
		if(dto != null) {
			return mapper.boardUpdate(dto);
		}
		
		return 0;
	}

	@Override
	public int boardDelete(Integer id) {
		
		if(id != null) {
			return mapper.boardDelete(id);
		}
		
		return 0;
	}

}
