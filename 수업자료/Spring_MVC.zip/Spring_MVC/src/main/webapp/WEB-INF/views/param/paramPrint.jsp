<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	
	이름 : ${name }<br>
	나이 : ${age }<br>
	
	<hr>
	
	이름 : ${member.name }<br>
	나이 : ${member.age }<br>
	
	
	
</body>
</html>