<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	
	<form action="/mvc/page/write" method="post" >
	
		<input type="submit" value="POST 전송">
	
	</form>
	
</body>
</html>