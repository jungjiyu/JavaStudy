package com.spring.mvc.member.service;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mvc.member.repository.MemberDAO;
import com.spring.mvc.member.repository.MemberVO;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberDAO dao;
	
	@Override
	public List<MemberVO> memberList() {
		return dao.memberList();
	}

	@Override
	public boolean memberInsert(MemberVO member) {
		
		if(member != null) {
			
			Timestamp now = new Timestamp(System.currentTimeMillis());
			
			member.setRegDate(now);
			
			boolean result = dao.memberInsert(member);
			return result;
		}else {
			return false;
		}
		
	}

	@Override
	public boolean memberIdCheck(String id) {
		
		if(id != null) {
			return dao.memberIdCheck(id);
		}else {
			return false;
		}
		
	}

	@Override
	public MemberVO getMember(String id) {
		
		if(id != null) {
			return dao.getMember(id);
		}else {
			return null;
		}
		
	}

	@Override
	public boolean memberEdit(MemberVO member) {
		
		if(member != null) {
			return dao.memberEdit(member);
		}else {
			return false;
		}
		
	}

	@Override
	public boolean memberDelete(String id) {
		
		if(id != null) {
			return dao.memberDelete(id);
		}else {
			return false;
		}
		
	}

}
