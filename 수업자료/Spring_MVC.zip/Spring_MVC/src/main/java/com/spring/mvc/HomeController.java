package com.spring.mvc;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
// 해당 클래스는 Controller 의 역할을 수행한다.
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	// @RequestMapping : 컨텍스트패스(ContextPath) 다음에 해당하는 url와 
	// 해당하는 요청방식으로 요청이 들어오면 메소드를 실행 시켜준다.
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		System.out.println("home 메소드 입니다.");
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
		// 문자열로 논리적 뷰 이름을 반환하면 그것을 디스패쳐 서블릿이 받아 뷰 리졸버를 뷰이름을 주면서 호출한다.
		// 뷰 리졸버는 클라이언트에게 실제로 응답을 해줄 자원의 경로로 바꾸어준다.
	}
	
}





