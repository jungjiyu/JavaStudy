package com.spring.mvc.member.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class MemberDAOImpl implements MemberDAO {
	
	List<MemberVO> list = new ArrayList<MemberVO>();
	
	@Override
	public List<MemberVO> memberList() {
		return list;
	}
	
	@Override
	public boolean memberInsert(MemberVO member) {
		
		boolean bool = list.add(member);
		
		return bool;
	}

	@Override
	public boolean memberIdCheck(String id) {
		
		for(int i = 0; i < list.size(); i++) {
			
			MemberVO member = list.get(i);
			
			if(member.getId().equals(id)) {
				return true;
			}
			
		}
		
		return false;
	}

	@Override
	public MemberVO getMember(String id) {
		
		for(int i = 0; i < list.size(); i++) {
			
			MemberVO member = list.get(i);
			
			if(member.getId().equals(id)) {
				
				return member;
			}
		}
		
		return null;
	}

	@Override
	public boolean memberEdit(MemberVO member) {

		// pw tel email address
		
		String id = member.getId();
		
		for(int i = 0; i < list.size(); i++) {
			
			MemberVO edit = list.get(i);
			
			if(edit.getId().equals(id)) {
				
				String pw = member.getPw();
				String tel = member.getTel();
				String email = member.getEmail();
				String address = member.getAddress();
				
				edit.setPw(pw);
				edit.setTel(tel);
				edit.setEmail(email);
				edit.setAddress(address);
				
				return true;
				
			}
			
		}
		
		return false;
	}

	@Override
	public boolean memberDelete(String id) {
		
		for(int i = 0; i < list.size(); i++) {
			
			MemberVO member = list.get(i);
			
			if(member.getId().equals(id)) {
				
				list.remove(i);
				return true;
				
			}
			
		}
		
		return false;
	}

}
