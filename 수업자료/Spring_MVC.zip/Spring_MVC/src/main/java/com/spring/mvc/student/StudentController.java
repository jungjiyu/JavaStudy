package com.spring.mvc.student;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@GetMapping("/form")
	public String studentForm() {
		return "student/studentForm";
	}
	
	@PostMapping("/data")
	public String studentData(@ModelAttribute("student")Student student, Model model) {
		
		//model.addAttribute("student", student);
		
		// jsp 로 데이터를 보낼때 사용하는 Model 객체에 데이터를 넣는 방식 중
		// Command 객체를 @ModelAttribute 어노테이션을 사용하여 
		// 간편하게 Model 객체에 데이터를 넣을 수 있다.
		
		return "student/studentInfo";
	}
	
	
	
}
