package com.spring.mvc.member.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.mvc.member.repository.MemberVO;
import com.spring.mvc.member.service.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	
	@Autowired
	private MemberService service;
	
	// 회원 목록페이지 요청
	@GetMapping("/list")
	public String memberList(Model model) {
		
		List<MemberVO> list = service.memberList();
		
		model.addAttribute("memberList", list);
		
		return "member/memberList";
	}
	
	
	// 회원가입시 회원가입 폼페이지요청
	@GetMapping("/join")
	public String joinForm() {
		return "member/joinForm";
	}
	
	
	// 회원가입폼 작성 후 회원등록 요청
	@PostMapping("/join")
	public String join(MemberVO member, RedirectAttributes ra) {
		
		// 소스코드를 작성함에 있어 redirect를 사용하여 파라미터를 넘겨줘야 하는 경우가 있다.
		// RedirectAttributes 객체를 통해서 데이터를 전달할 수 있다.
		// addFlashAttribute() 는 리다이렉트 직전 플래시에 데이터를 저장하는 메소드다. 
		// 일회성 데이터를 보내주기 때문에 리다이렉트 이후에는 소멸한다.
		
		
		boolean idCheck = service.memberIdCheck(member.getId());
		
		if(idCheck == true) { // 같은 아이디가 있는경우
			
			ra.addFlashAttribute("msg", "같은 아이디가 존재합니다.");
			return "redirect:/member/join";
			
		}
		
		boolean result = service.memberInsert(member);
		
		if(result) { // 회원가입 OK
			
			ra.addFlashAttribute("msg", "회원가입 되었습니다.");
			return "redirect:/member/list";
			
			
		}else { // 회원가입 NG
			ra.addFlashAttribute("msg", "회원가입 실패입니다.");
			return "redirect:/member/join";
			
		}
		
	}
	
	// 회원정보 페이지 요청
	@RequestMapping(value="/info", method=RequestMethod.GET)
	public String getMember(@RequestParam("id")String id, Model model) {
		
		MemberVO member = service.getMember(id);
		
		model.addAttribute("member", member);
		
		return "member/memberInfo";
	}
	
	// 회원정보 수정 폼 페이지 요청
	@PostMapping("/modifyForm")
	public String modifyForm() {
		return "member/modifyForm";
	}
	
	
	// 회원정보 수정 요청
	@PostMapping("/modify")
	public String modify(MemberVO member, RedirectAttributes ra) {
		
		boolean bool = service.memberEdit(member);
		
		if(bool) {
			ra.addFlashAttribute("msg", "회원정보 수정이 되었습니다.");
		}else {
			ra.addFlashAttribute("msg", "회원정보 수정 실패입니다.");
		}
		
		return "redirect:/member/list";
		
	}
	
	// 회원 탈퇴 요청
	@PostMapping("/delete")
	public String delete(@RequestParam("id")String id, RedirectAttributes ra) {
		
		boolean bool = service.memberDelete(id);
		
		if(bool) {
			ra.addFlashAttribute("msg", "회원탈퇴 되었습니다.");
		}else {
			ra.addFlashAttribute("msg", "회원탈퇴 실패입니다.");
		}
		
		return "redirect:/member/list";
	}
	
	
}






















