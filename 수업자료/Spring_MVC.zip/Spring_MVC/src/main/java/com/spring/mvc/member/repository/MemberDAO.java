package com.spring.mvc.member.repository;

import java.util.List;

public interface MemberDAO {
	
	// 회원 전체 목록을 출력하기 위해 데이터를 얻는 기능
	public List<MemberVO> memberList();
	
	// 회원가입폼에서 넘어온 데이터를 받아 회원데이터를 저장하는 기능
	public boolean memberInsert(MemberVO member);
	
	// 회원 가입전에 중복된 아이디가 있는지 확인해주는 기능
	public boolean memberIdCheck(String id);
	
	// 해당 회원의 정보를 얻는 기능
	public MemberVO getMember(String id);
	
	// 해당 회원의 정보를 수정해주는 기능
	public boolean memberEdit(MemberVO member);
	
	// 해당 회원을 삭제해주는 기능
	public boolean memberDelete(String id);
	
}
