package nestedClass;

public class A {
	int aa =100; // 바깥 클래스의 인스턴스 필드
	static int aaa = 200;
	B insideNonStaticInstanceB = new B();
	C insideStaticInstanceC = new C(); 
	
	public A(){
		System.out.println("A 클래스의 객체가 생성됬습니다");
	}
	
	public void infoA() {
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAA");
	}
	
	public void container() {
		//앞 부분서 함 안됨
	/*	D insideDD = new D();
		insideDD.infoD();
		*/
		
		class D{
			
			D(){
				System.out.println("D 클래스의 객체가 생성됬습니다");
				System.out.println(aaa); //내부서 정적 멤버를 새로 선언하지 못한단거지, 외부에 선언된 정적멤버를 사용하지 못한단 말이 아니다
			}
			
			public void infoD() {
				System.out.println("DDDDDDDDDDDDDDDDDDDDDDDD");
			}
		}
		
		D insideD = new D();
		insideD.infoD();

	}
	//인스턴스멤버클래스
	class B{
		int b = 20; //static int a = 10; 해도 오류나는 것 같아보이진 않는데 책에서 하면 안된다고 한다 
		
		
		public B(){
			System.out.println("B 클래스의 객체가 생성됬습니다");
		}
		
		public void infoB() {
			System.out.println("BBBBBBBBBBBBBBBBB");
		}
		
	}
	
	//정적멤버클래스
	static class C{
		static int b = 40; // 정적 멤버 선언 가능하다
		int c = 80; // 클래스 멤버 내부에선 인스턴스 필드 선언 가능 
		
		public C(){
			System.out.println("C 클래스의 객체가 생성됬습니다");
		//	System.out.println(aa);  정적멤버이므로 (멤버 외부의) 인스턴스 필드를 사용하지 못함
		}
		
		public void infoC() {
			System.out.println("CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCcccc");
		}

	
	}
	
	// 인스턴스 멤버 인터페이스
	interface E{
		void sayCheese();
	}
	
	//정적멤버 인터페이스
	static interface D{
		void sayChocolate();
	}
	
}
