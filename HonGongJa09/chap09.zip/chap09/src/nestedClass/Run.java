package nestedClass;

public class Run {
	public static void main(String[] args) {
		
		A a = new A();
		a.container();
		
		A.B b = a.new B();
		b.infoB();	
		
		A.C c = new A.C(); //	A.C c = A.new C(); 함 안된다
		

	}

}
