package anonymous2;

public class Run {
	
	public static void main(String[] args) {
		SmartHouse myHouse = new SmartHouse();
		myHouse.turnOffAll();
		myHouse.turnOnAll();
		System.out.println();

		broke(myHouse.radio);
		broke(myHouse.tv);
		myHouse.turnOnAll(); // 실제로 적용이 안됬음
		System.out.println();

		myHouse.tv = broke1();
		myHouse.radio = broke1();
		myHouse.turnOnAll(); // 실제로 적용이 됬음
		
	}
	
	
	
	public static void broke(SmartHouse.Button button) {
		button = new SmartHouse.Button() { 
			@Override
			public void turnOn() {
				System.out.println("...ㄱ.ㄱ고..고장났습..ㄴ..니다");
			}
			
			@Override
			public void turnOff() {
				turnOn();
			}
		};
		
	}
	
	
	public static SmartHouse.Button broke1() {
		SmartHouse.Button button = new SmartHouse.Button() { 
			@Override
			public void turnOn() {
				System.out.println("...ㄱ.ㄱ고..고장났습..ㄴ..니다");
			}
			
			@Override
			public void turnOff() {
				turnOn();
			}
		};
		
		return button;
		
	}
}
