package anonymous2;

public class SmartHouse { 
	public Button tv = new Button() { // 익명 구현 객체를 참조하는 필드
		@Override
		public void turnOn() {
			System.out.println("Tv 를 켭니다");
		}
		
		@Override
		public void turnOff() {
			System.out.println("Tv 를 끕니다");
		}
	};
	
	
	public Button radio = new Button() { // 익명 구현 객체를 참조하는 필드
		@Override
		public void turnOn() {
			System.out.println("Radio를 켭니다");
		}
		
		@Override
		public void turnOff() {
			System.out.println("Radio를 끕니다");
		}
	};
	
	
	public void turnOnAll( ) {
		tv.turnOn();
		radio.turnOn();
	}
	
	public void turnOffAll( ) {
		tv.turnOff();
		radio.turnOff();
	}
	
	
	public interface Button {
		void turnOn(); // public abstract void turnOn();
		void turnOff(); // public abstract void turnOff();

	}

}
