package anonymous;

public class Person {
	Person(){
		System.out.println("Person 생성자가 실행됬습니다");
	}
	void routine() {
		System.out.println("7시에 기상합니다");
	}
	
	void poop() {
		System.out.println("화장실을 갑니다");
	}

}
