package anonymous;

public class Run {
	public static void main(String[] args) {
		Jiyu jiyu  = new Jiyu(new Person() { // arg 를 익명 자식 객체로 넘김
			@Override
			public void routine() {
				System.out.println("6시에 기상합니다");
			}
		});
		
		jiyu.morning();
		jiyu.emergency.poop(); // 익명자식객체를 가리키고 있는 레퍼런스 필드 활용
		jiyu.night();
		
	}
}
