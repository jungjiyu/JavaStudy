package anonymous;

public class Jiyu {
	
	Person emergency = new Person() { // 필드로 가리킴
		String what = "똥";
		@Override
		public void poop() {
		System.out.println("시간은 중요하지 않습니다. "+what+"이 마렵습니다."+" 당장 화장실에 갑니다.");	
		}
	};
	
	Jiyu(Person person){
		System.out.println("Jiyu 생성자가 실행됬습니다");
		person.routine();
	}
	
	public void morning() {
		Person morningJiyu = new Person() { // 익명 자식 객체 생성
			public void routine2() {
				System.out.println("7시 30분에 이를 닦습니다");
			}
			
			@Override
			public void routine() {
				routine2();
			}
		};
		
		morningJiyu.routine(); // 생성한 로컬 레퍼런스 변수를 사용 (블럭 내부서 선언한거라 로컬 변수임)
		// morningJiyu.routine2(); 익명 클래스 외부에선 익명클래스만의 멤버는 접근 불가다 << 부모 쿨래스 타입 변수니까
		
	}
	
	public void night() {
		Person nightJiyu= new Person() {
			String menu = "짜장면";
			@Override
			public void routine(){
				System.out.println("저녁 8시에 "+menu+"를 먹습니다");
			}
		};
		
		nightJiyu.routine(); // 생성한 로컬 익명 자식 객체 활용 
		emergency.poop(); // 익명객체를 참조하고 있는 필드 활용
	}

}
