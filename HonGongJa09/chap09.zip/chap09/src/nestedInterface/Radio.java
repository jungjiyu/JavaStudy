package nestedInterface;

public class Radio implements Button.Btn{
	Radio(){
		System.out.println("radio 객체가 생성되었습니다");
	}
	
	@Override
	public void click() {
		System.out.println(" 라디오를 켰습니다.");
	}

}
