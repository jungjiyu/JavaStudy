package nestedInterface;

public class Tv implements Button.Btn{ // 정적 인터페이스 사용
	Tv(){
		System.out.println(" TV 객체가 생성됬습니다");
	}
	
	@Override
	public void click() {
		System.out.println("TV 를 켰습니다");
	}

}
