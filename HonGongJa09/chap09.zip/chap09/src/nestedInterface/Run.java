package nestedInterface;

public class Run {
	public static void main(String[] args) {
		Button tv = new Button();
		Button radio = new Button();
		
		tv.setButton(new Tv());
		radio.setButton(new Radio());
		
		
		turnOn(tv.getButton());
		turnOn(radio.getButton());
		
	}
	
	public static void turnOn(Button.Btn button) { // 다형성 구현
		button.click(); 
	}
		
}
