package nestedInterface;

public class Button {
	private Btn button; // 캡슐화
	
	Button(){
		System.out.println("button 객체 생성됨");
	}
	
	public void setButton(Btn button) { // setter
		this.button = button;
	}
	
	public Btn getButton() { // getter
		return button;
	}
	
	public void move(Btn button) { //인터페이스 다형성 구현
		this.button.click();
	}
	
	static interface Btn{
		void click();
	}

}
