package chap08;

public interface Human {
	int sugarSpoon = 100;
	public void sipCoffee(); // == public abstract void sipCoffee
}
