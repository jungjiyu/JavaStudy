package chap08;

public class InterfacePractice {
	public static void main(String[] args) {
		Animal animal = new Cat(new Dog()); // 자동형변환
		System.out.println();
		
		soundLike(animal);
		System.out.println();

		letsDance(animal);
		System.out.println();
		
		animal = new Dog(); 
		soundLike(animal);
		System.out.println();
		
		Human human = new Dog();
		human.sipCoffee();	//	animal.sipCoffee(); 하면 안되는게 Animal 인터페이스엔 sipCoffee 추상메서드가 없어 접근 불가하다

		
	}
	
	public static void letsDance(Animal animal) {
		if( animal instanceof Cat) {
			System.out.println("Cat타입 객체가 Animal 인터페이스 타입으로 자동형변환되었던게 맞습니다");
			Cat cat = (Cat)animal;//강제형변환 >> cat에 있는 메서드 모두 사용 가능
			cat.dance();
		}
	}
	
	public static void soundLike(Animal animal) { // 인터페이스 타입으로 매개변수 선언 >> 어떤 클래스로 선언된 객체냐 따라 다른 기능 구현 가능(오버라이딩된 메서드의 내용이 다르면)
		animal.sound();
	}

}
