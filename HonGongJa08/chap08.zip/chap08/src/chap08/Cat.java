package chap08;

public class Cat implements Animal{
	
	Cat(){}
	
	Cat(Human human){ // 인터페이스를 매개변수 타입으로 할수 있다
		System.out.println("*cat throws coffee with "+human.sugarSpoon+"Spoons of sugar*");
	}
	
	@Override
	public void sound() {
		System.out.println("mewooooo");
	}
	
	public void dance() {
		System.out.println("—ฅ/ᐠ. ̫ .ᐟ\\ฅ —");
	}

}
