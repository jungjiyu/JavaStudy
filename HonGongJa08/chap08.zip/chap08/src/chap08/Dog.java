package chap08;

public class Dog implements Animal , Human{ 
	public int sugarSpoon = 600; // 구현 클래스 내부에서 인터페이스에서 선언됬던 상수 필드를 재선언 했을때 인터페이스의 상수는 어떻게 사용함?
	@Override
	public void sound(){
		System.out.println("Bark bark");
	}
	
	@Override
	public void sipCoffee() {
		System.out.println("i love coffee");
		System.out.println("설탕을 "+ sugarSpoon+"스푼 추가합시다");  // super.sugarSpoon 하면 오류남
		System.out.println("*기존 인터페이스의 sugarSpoon값:"+Human.sugarSpoon);
	}
}
