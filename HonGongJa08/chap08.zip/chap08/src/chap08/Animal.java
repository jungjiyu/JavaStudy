package chap08;

public interface Animal {
	public abstract void sound();
}
