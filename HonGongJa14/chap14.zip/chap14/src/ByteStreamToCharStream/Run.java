package ByteStreamToCharStream;

import java.io.*;

public class Run {
	public static void main(String[] args) {
		String adrs = "c:/DailyJava2/test1.txt"; // adrs 가 ANSI 텍스트 파일의 경로면 실제로 바이트스트림으로 받아온 값의 개수*2 == 문자스트림으로 받아온 값의 개수 인데 UTF-8 텍스트파일의 경로면 그게 아님
		
		// 단순 바이트 스트림으로만 입력
		try(FileInputStream fis = new FileInputStream(adrs)){
			byte[] b = new byte[10000];
			int count ;
			while((count = fis.read(b)) != -1) {
				System.out.print("\n("+count+"개의 자료를 읽어왔습니다)\n");
				for(int i = 0 ; i <count ; i ++) {
					System.out.print((char)b[i]); 
				}
			}
		}catch(IOException e) {
			e.printStackTrace();
		}

		
		
		// 바이트 스트림을 문자스트림으로 변환하여 입력
		System.out.println("\n------------------------------------------");
		try(FileInputStream fis = new FileInputStream(adrs);Reader ir = new InputStreamReader(fis)){
			char[] ary = new char[10000];
			int count ;
			while((count = ir.read(ary)) != -1) {
				System.out.print("\n("+count+"개의 자료를 읽어왔습니다)\n");
				for(int i = 0 ; i <count ; i ++) {
					System.out.print(ary[i]); 
				}
			}
		}catch(IOException e) {
			e.printStackTrace();
		}

		
		
		
		// 문자스트림으로 입력
		System.out.println("\n------------------------------------------");
		try(Reader fr = new FileReader(adrs)){
			char[] ary = new char[10000];
			int count ;
			while((count = fr.read(ary)) != -1) {
				System.out.print("\n("+count+"개의 자료를 읽어왔습니다)\n");
				for(int i = 0 ; i <count ; i ++) {
					System.out.print(ary[i]); 
				}
			}
		}catch(IOException e) {
			e.printStackTrace();
		}

		
		String adrs2= "c:/DailyJava2/test2.txt";
	
		// 단순 바이트 스트림으로만 출력
			try(OutputStream fos = new FileOutputStream(adrs2)){
				fos.write('안');
				fos.write('녕');
				fos.write('하');
				fos.write('신');
				fos.write('가');
				}catch(IOException e) {
					e.printStackTrace();
				}

				
		String adrs3= "c:/DailyJava2/test3.txt"; // 이 프로그램 내에서 한번이라도 바이트 스트림으로 열렸던 전적 있음 ANSI 인코딩 파일로 인식되기에 바이트 스트림으로 열린적 없는 얘 써야됨??				
			// 바이트 스트림을 문자스트림으로 변환하여 입력
		System.out.println("\n------------------------------------------");
		try(OutputStream fos = new FileOutputStream(adrs3); Writer  osw = new OutputStreamWriter(fos)){
				osw.write("응아아아아아아아악");
		
			}catch(IOException e) {
					e.printStackTrace();
				}

		
		
		
	}

	}


