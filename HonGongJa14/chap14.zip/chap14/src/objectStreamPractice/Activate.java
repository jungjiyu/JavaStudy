package objectStreamPractice;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.io.IOException;
import java.io.Serializable;

public class Activate {
	public static void main(String[] args) throws Exception{
		
		ArrayList <Student> students = new ArrayList<Student>(); // stduents 의 요소의 타입은 Stduent 이고 students 자체의 타입은 ArrayList<Student>
		for(int i = 0 ; i <5;i++) {
			students.add(new Student("홍길동"+i, 10 +i));
		}
		
		String adrs = "c:/DailyJava2/dos.txt";
		try(OutputStream fos = new FileOutputStream(adrs) ; ObjectOutputStream oos = new ObjectOutputStream(fos) ){
			for(int i = 0 ; i < students.size() ; i++) {
				oos.writeObject(students.get(i));				
			}
		}catch(IOException e) {}
		
		ArrayList <Student> students2 = new ArrayList<Student>(); 
		try(InputStream fis = new FileInputStream(adrs) ; ObjectInputStream ois = new ObjectInputStream(fis) ){
			for(int i = 0 ; i < students.size() ; i++) {
				Student student =  (Student)ois.readObject() ;
				students2.add(student);				
			//	students2 = (ArrayList<Student>) ois.readObject();
			}
		}catch(IOException e) {}
		
		for(int i = 0 ; i < students2.size() ; i++) {
			System.out.print(students2.get(i).getName());
			System.out.println(", "+students2.get(i).getAge());
		}
		
	}

}
