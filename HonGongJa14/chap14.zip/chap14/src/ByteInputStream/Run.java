package ByteInputStream;

import java.io.InputStream; 
import java.io.FileInputStream;  
import java.io.IOException;

public class Run {
	public static void main(String[] args) {
		
		
		// 넉넉한 배열로 하나로 데이터 받기1 : 한 바이트 단위로 입력받기
		byte[] b= new byte[1000];
		try(InputStream fis = new FileInputStream("C:/SelfStudyJava/chap14/binarytest.db")){ // try 문 종료시 자동으로 .close() 실행됨 
		
			int n ; // 임시로 읽은값 담을 변수
			int index = 0;
			
			while((n= fis.read()) != -1) { // 바이트 단위씩 읽어온다 && 파일의 끝을 만나면 종료한다
				System.out.println("한번에 읽어온 데이터 수: "+1);
				b[index++] =(byte)n;
				System.out.println((char)n);
			}
			
			
		}catch(IOException e){
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		// 넉넉한 배열로 하나로 데이터 받기 2 : 베열로 한번에 받기
				System.out.println("\n\n\n");
				b= new byte[1000];
				try(InputStream fis = new FileInputStream("C:/SelfStudyJava/chap14/binarytest.db")){ // try 문 종료시 자동으로 .close() 실행됨 
				
					int n ; // 몇개 읽었는지 저장하는 변수
					
					while((n= fis.read(b)) != -1) { // 배열크기단위로 읽어온다 && 파일의 끝을 만나면 종료한다
						System.out.println("한번에 읽어온 데이터 수: "+(n));
						for(int j =0 ;j < n ; j++) { // 읽어온 데이터 개수 만큼 반복문 반복하며 값 뽑는다
							System.out.print((char)b[j]);
						}
					}
					
					
				}catch(IOException e){
					e.printStackTrace();
				}
				
				
				
				
				
				
		
		
		
		// 좀 작은 배열로 여러번 입력 받고 입력받은 걸 다른 큰 배열에 저장하기
		System.out.println("\n");
		byte[] ary= new byte[10];
		byte[] ary2 = new byte[1000]; // 받은 값을 저장할 용도
		try(InputStream fis = new FileInputStream("C:/SelfStudyJava/chap14/binarytest.db")){ // try 문 종료시 자동으로 .close() 실행됨 
			
			int count=0; // 읽은 바이트값갯수를 센다
			int index = 0;
			while((count= fis.read(ary)) != -1) { // 바이트 단위씩 읽어온다 && 파일의 끝을 만나면 종료한다
				System.out.println("읽어온 바이트 수 :"+count);
				
				System.out.print("읽어온 내용:");
				for(int i = 0 ; i < ary.length ; i++) {
					System.out.print((char)ary[i]); 
					// 마지막번째에서 2개만 읽었음에도 dewxyzZabc 로 10글자가 나오는게 잘못된게 아니다 . 사실 새로입력된 값은 de 로 2개 제대로 된거 맞는데 나머지 wxyzZabc 는 이전에 복사됬던내역이 아직 남아있는거다
				
				}
			
				
				System.arraycopy(ary,0,ary2,index,count); // conunt 가 아닌 ary.length 를 기준으로 하면 마지막 번째에 들어온 de 뿐 아니라 wxyzZabc 까지 들어와서 걍 count 로 하는게 낫다 && arraycopy 가 값이 복사되는거지 객체 자체가 복사되는건 아님 
				index += count;												
				System.out.println("\n마지막 인덱스: "+index+"\n");
				
			}
			
			for(int i = 0 ; i < ary2.length ; i++) {
				if(ary2[i] != 0 )System.out.print((char)ary2[i]);
				// 마지막 번째에서 읽어온 내용이 dewxyzZabc 로 나왔긴 했지만 앞서 말했듯이 사실 2개가 새로 들어온거고, arraycopy를 ary.lenth 기준이 아닌 count 를 기준으로 했기 떄문에 ary2의 내용은 제대로 출력된다.
			}
			
			
		}catch(IOException e){
			e.printStackTrace();
		}
		
		
		// 데이터를 입력하기 시작하는 지점, 개수 커스터마이징 하기
		System.out.println();
		try( InputStream fis = new FileInputStream("c:/DailyJava2/input2.txt")) {
			byte[] ary3 = new byte[40];
			int count =0;
			while((count = fis.read(ary3,4,9)) != -1) { // ary3의 인덱스 4 부터 9개의 값 입력
				System.out.print("\n읽어온 값 개수:"+count);
				System.out.print("\t읽어온 내용: ");
				
				// 확인해 보면 각 턴 마다 인덱스 4 부터 인덱스 13 까지 값이 들어와있음을 알 수 있다
					// 마지막 턴에선 이전에 저장된 값이 그대로 남아있긴 하다
				 for(int i = 0; i <ary3.length ; i ++) {
					 if(ary3[i] == 0) System.out.print(0);
					 else System.out.print((char)ary3[i]);
				 }
			}
			
			
		}catch(IOException e ) {
			e.printStackTrace();
		}
		
		
		
		
		
		
	
		
	}

}
