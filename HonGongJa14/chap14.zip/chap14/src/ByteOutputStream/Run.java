package ByteOutputStream;



import java.io.OutputStream; // 막 OutputStream 의 하위 클래스 쓰겠다고 꼭 필요한 건 아니지만 다형성 구현을 위해 부모클래스 격인 OutputStream 타입의 객체를 생성했기 때문에 출력 필요
import java.io.FileOutputStream; // 바이트 출력 클래스의 자식 클래스 중 하나
import java.io.IOException;

public class Run {
	public static void main(String[] args) {
		byte[] ary = new byte[26]; // 각 인덱스 기본 0 으로 초기화
	
		for(byte i = 'a' ; i <='z';i++) { // for문으로 값 할당 못받은 인덱스 값은 0 으로 남음
			ary[i-'a'] = i; // 'a' - 'a' == 0 , 'b' - 'a' == 1 ...  
		}
	
		try(OutputStream os = new FileOutputStream("C:/SelfStudyJava/chap14/binarytest.db")){ // autocloseable 인터페이스의 구현 클래스이기에 try 괄호 안에 객체참조변수를 대입함 try 구문의 종료와 함께 자동으로 닫힌다
			
			os.write(ary); // 배열이 다 채워졌건 안채워졌건 전체 사이즈를 출력
			os.write(2147483644); // write(int b) 근데 출력하는건 int 형 아닌 byte 임을 주의
			os.write(ary,0 ,5 ); // 인덱스 0 값 부터 인덱스 5 값까지 출력하는게 아니라 인덱스 0 값 부터 5개의 값을 출력하는거라 인덱스 0부터 인덱스 4 까지의 값이 출력되는거임 주의
			
		}catch(IOException e){
			e.printStackTrace();
		}
		
		


		System.out.println("완료");
		
		
		
	}

}
