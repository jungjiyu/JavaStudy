package scannerPractice;


import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;

public class Activate {
	public static void main(String[] args) {
	ArrayList<String> fileDetail = new ArrayList<String>();

	String adrs = "c:/DailyJava2/dos.txt";	
	String adrs2 = "c:/DailyJava2/does.txt";	
	
	File file = new File(adrs) ;
	boolean flag = file.exists();
	System.out.println("유효한 경로인가 :"+flag);
	
	if(flag) {
	
	fileInfo(file);
	try( Scanner scannerFile = new Scanner(file)){	// 파일 객체를 매개변수로 하는 Scanner 생성자의 경우 throws IOException 처리가 되있지 않기 때문에 따로 try 구문 써야된다
	while(scannerFile.hasNext()) {
		String str = scannerFile.nextLine();
		fileDetail.add(str); // 문장을 기준으로 저장함
	}
	System.out.println("hooooooooo");

	}catch(IOException e) {
		e.printStackTrace();
		System.out.println("IOException 발생");
	}
	
	
	for(int i = 0 ; i < fileDetail.size(); i ++) {
		System.out.print(fileDetail.get(i));
		System.out.println(); // nextLine 이 버퍼에서 엔터를 가져오는 건 맞는데 엔터까지 저장하지 않음
	}
	
	}
	
	else {
		try {
		file.createNewFile();
		System.out.println("파일이 새로 생성됬습니다");
		fileInfo(file);
		
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}
	
	}
	
	
	public static void fileInfo(File file) {
		System.out.println();
		System.out.println("파일명:"+file.getName());
		System.out.println("부모 디렉터리 경로:"+file.getParent());
		System.out.println("파일경로:"+file.getPath());
		System.out.println("파일 권한: r-"+file.canRead()+"w-"+ file.canWrite()+"x-"+file.canExecute());
		System.out.println("숨김여부:"+ file.isHidden());
		System.out.println("파일 크기:"+file.length());
		System.out.println("파일 최종 수정 날짜:"+file.lastModified());
		System.out.println("부모 디렉터리:"+file.getParent());
		System.out.println();
		
	}
	
}
