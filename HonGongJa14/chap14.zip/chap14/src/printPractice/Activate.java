package printPractice;

import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.io.FileWriter;
import java.io.Reader;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Scanner;

public class Activate {
	public static void main(String[] args) {
		String adrs = "c:/DailyJava2/dos.txt";
		Scanner scanner = new Scanner(System.in);
		
		try(OutputStream fos = new FileOutputStream(adrs) ; PrintStream ps = new PrintStream(fos)){
			System.out.println("저장하고 싶은 내용을 입력하세요 (종료:-1): ");
			String str = scanner.nextLine();
			while(!str.equals("-1")) {
				ps.println(str);
				str = scanner.nextLine();
			}
			
		}catch(IOException e) {}
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
		try(Reader fr = new FileReader(adrs) ; BufferedReader br = new BufferedReader(fr)){
			String str;
			while((str =br.readLine())!= null) {
				System.out.println(str);
			}
		}catch(IOException e) {}
		
		scanner.close();
	}

}
