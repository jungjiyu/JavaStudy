package readLinePractice;

import java.io.IOException;
import java.io.FileReader;
import java.io.Reader;
import java.io.BufferedReader;


public class Activate {
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		try(Reader fr = new FileReader("c:/DailyJava2/song.txt");BufferedReader br= new BufferedReader(fr) ){
			String line; 
			while(( line= br.readLine()) != null) {
				System.out.print(line);
			}
		}catch(IOException e) {}
		long endTime = System.currentTimeMillis();	
		System.out.println("시작 시간:"+startTime);
		System.out.println("종료 시간:"+endTime);
		System.out.println("걸린 시간:"+ (endTime-startTime)/1000.0+"초");
		System.out.println("main thread ended");
	}
}
