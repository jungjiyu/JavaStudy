package CharacterReader;


import java.io.Reader;
import java.io.FileReader;
import java.io.IOException;

public class Run {
	public static void main(String[] args) {
		//한 글자씩 입력 받기
		System.out.println("==============한 글자씩 입력받기1==========================");
		try(Reader fr = new FileReader("c:/DailyJava2/reader.txt")){ // Reader == 문자 스트림 클래스 >> 한국어, 러시아어 .. 읽기 가능
			int n;
			while((n = fr.read())!= -1) {
				if(n==13) System.out.print("캐리지리턴"); // 동일한 줄의 첫번째 자리로 커서를 이동시킴
				if(n==10) System.out.print("엔터"); // 자바에서는 다음줄로 가는게 캐리지리턴 + 엔터임 . 
				System.out.print((char)n);	// 왜 엔터가 2번 일어남?			
			}
					
		}catch(IOException e) {
			System.out.println("파일 입력 오류 내용:");
			e.printStackTrace();
		}
		
		
		System.out.println("\n==============한 글자씩 입력받기2+++++++++++++++++++");
		try(Reader fr = new FileReader("c:/DailyJava2/reader.txt")){
			int n;
			while((n = fr.read())!= -1) {
				System.out.print((char)n);				
			}
					
		}catch(IOException e) {
			System.out.println("파일 입력 오류 내용:");
			e.printStackTrace();
		}
		
		
		// 배열을 이용하여 뭉텡이로 입력받기
		System.out.println("\n==============배열 단위로 입력받기+++++++++++++++++++");
		try(Reader fr = new FileReader("c:/DailyJava2/reader.txt")){
			int count;
			char[] ary = new char[200];
			while((count = fr.read(ary))!= -1) {
				System.out.println("("+count+"개의 값을 읽어왔습니다)");
				
				// 중간중간 출력방법 1 >> 향상된 for 문을 사용하는 경우 인덱스적 접근을 못하기 때문에 count 값 못쓰고 별도의 조건 걸어야됨
				System.out.println(" 출력방법1:");
				for( char c : ary ) {
					if(c != 0 )System.out.print(c);
				}
				System.out.println("\n");

				System.out.println(" 출력방법2:");
				for(int i = 0 ; i <count ;i++)
				{
					System.out.print(ary[i]);
				}
				System.out.println("\n");
			}
					
		}catch(IOException e) {
			System.out.println("파일 오류 발생:");
			e.printStackTrace();
		}
	}

}
