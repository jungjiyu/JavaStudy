package CharacterWriter;



import java.io.Writer;
import java.io.IOException;
import java.io.FileWriter;

public class Run {
	public static void main(String[] args) {
		
		// 한 글자 출력하기 >> 유니코드이므로 한글도 된다
		try( Writer w = new FileWriter("c:/DailyJava2/writer.txt")) {
		
			char a = '안';
			char b = '녕';
			char c = '하';
			w.write(a);
			w.write(b);
			w.write(c);			
			
		}catch(IOException e ) {
			e.printStackTrace();
		}
		
		
	}
}
