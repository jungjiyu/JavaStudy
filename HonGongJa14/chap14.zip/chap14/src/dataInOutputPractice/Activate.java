package dataInOutputPractice;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;


public class Activate {
	public static void main(String[] args) {
		
		String adrs = "c:/DailyJava2/dos.txt";
		try(OutputStream fos = new FileOutputStream(adrs); DataOutputStream dos = new DataOutputStream(fos)){
			dos.writeUTF("정지유");
			dos.writeDouble(91.9);
			dos.writeChar('A');
			
			dos.writeUTF("정유하");
			dos.writeDouble(91.0);
			dos.writeChar('B');
			
		}catch(IOException e) {}
		
		try(InputStream fis = new FileInputStream(adrs); DataInputStream dis = new DataInputStream(fis)){
			String name;
			double score;
			char GPA;
			while((name = dis.readUTF())!= null) {
				score = dis.readDouble();
				GPA = dis.readChar();
				System.out.println(name+" 학생의 점수는 "+score+"이고 "+"학점은 "+GPA+"입니다");
			}
			
		}catch(IOException e) {}
		
		System.out.println("mainthread ended");
	}

}
