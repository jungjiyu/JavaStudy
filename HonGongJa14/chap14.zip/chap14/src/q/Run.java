package q;



import java.io.*;

public class Run {
	public static void main(String[] args) throws Exception{
		
		
		
	// 바이트 스트림은 문자 2바이트를 1바이트 ,1바이트로 쪼개서 전송하는 거라길래 직접 2진수로 비교해봤는데 음... 잘 모르겠음.
		/*
		System.out.println("\n\n-----------------------------------------------------------");
		fis = new FileInputStream("c:/DailyJava2/reader.txt");
		
		int n,m;
		while((n = fis.read()) != -1 ) {
				int tmp = n ;
				
				System.out.print(Integer.toString(n,2)+"\t");
		}
		
		fis.close();

		
		
		
		fis = new FileInputStream("c:/DailyJava2/reader.txt"); // 보조 스트림에 쓸 기반 스트림 객체 생성 
		System.out.println("\n\n========================================================\n");
		Reader fr = new InputStreamReader(fis); // FileInputStream 에 보조스트림 연결
		char[] c = new char[1000];
		
		while((count = fr.read(c))!= -1  ) {
			System.out.print("("+count+"개의 자료를 읽어왔습니다)\n");
			
			System.out.println();
			for(int i = 0 ; i <count ; i ++) {
				System.out.print(Integer.toString((int)c[i],2)+"\t");
			}
		}	
		
		fr.close();
		fis.close();
	
		
		*/
		
		
		
	
		
		
		
	// 바이트 스트림 대 바이트 스트림으로 출력하는거랑 직접 출력하는거랑 뭐가 다른건지 모르겠음 		
		/*	
		 fis = new FileInputStream("c:/DailyJava2/test1.txt"); // test1.txt == "안녕하세요" 라고 쓰인 텍스트 파일
		FileOutputStream fos = new FileOutputStream("c:/DailyJava2/test2.txt"); // test2.txt == 빈 텍스트 파일
		int n;
		while((n=fis.read()) !=-1) {
			fos.write(n);
		}
		
		fis.close();
		fos.close();
		
		
		fos = new FileOutputStream("c:/DailyJava2/test3.txt"); // test3.txt == 빈 텍스트 파일
		fos.write('안');
		fos.write('녕');
		fos.write('하');
		fos.write('세');
		fos.write('요');
		
		fis.close();
		fos.close();
		
		
		
		
		fis = new FileInputStream("c:/DailyJava2/reader.txt"); // 보조 스트림에 쓸 기반 스트림 객체 생성 
		System.out.println("\n\n========================================================\n");
		Reader fr = new InputStreamReader(fis); // FileInputStream 에 보조스트림 연결
		char[] c = new char[1000];
		
		while((count = fr.read(c))!= -1  ) {
			System.out.println("("+count+"개의 자료를 읽어왔습니다)");
			
			for(int i = 0 ; i <count ; i ++) {
				System.out.print( c[i]);
			}
		}	
		
		fr.close();
		fis.close();
		
		
		*/
		
		
	// 왜 UTR-8 방식 파일 읽응면 읽은 값 개수가 2배가 아닌지 몰겠음	
		/*
		FileInputStream fis = new FileInputStream("c:/DailyJava2/reader.txt");
		byte[] b = new byte[100];
		int count ;
		while((count = fis.read(b)) != -1) {
			System.out.print("\n("+count+"개의 자료를 읽어왔습니다)\n");
			for(int i = 0 ; i <count ; i ++) {
				System.out.print((char)b[i]); // 유니코드 출력이 이상하게 된다
				
			}	

		}
		fis.close();
		
		
		fis = new FileInputStream("c:/DailyJava2/reader.txt"); // 보조 스트림에 쓸 기반 스트림 객체 생성 
		System.out.println("\n\n========================================================\n");
		Reader fr = new InputStreamReader(fis); // FileInputStream 에 보조스트림 연결
		char[] c = new char[1000];
		
		while((count = fr.read(c))!= -1  ) {
			System.out.println("("+count+"개의 자료를 읽어왔습니다)");
			
			for(int i = 0 ; i <count ; i ++) {
				System.out.print( c[i]);
			}
		}	
		
		fr.close();
		fis.close();
		*/

		
	// ANSI , UTF 로 열리는 기준이 뭔지 모르겠음	
		System.out.print("\n\nAnsiUtf8Check 메서드중 버전 몇을 호출할까여: ");
		int num = System.in.read() - '0';
		System.out.println(num);
		switch(num) {
		case 1:
			AnsiUtf8Check1();  //ANSI
			break;
			
		case 2:
			AnsiUtf8Check2(); //ANSI
			break;
		case 3:
			AnsiUtf8Check3(); // UTF-8
			break;
			
		case 4:
			AnsiUtf8Check4(); //ANSI
			break;
			
		default:
			System.out.println("제대로좀 입력하세요");
		}
		
		
		
		
		// 보조 스트림 사용
		/*
		//바이트 스트림을 문자스트림으로 변환하여 ㅜㅊㄹ력하기
		fos = new FileOutputStream("c:/DailyJava2/writer.txt"); // fos = new FileOutputStream("c:/DailyJava2/writer.txt",true); 로 하면 깨져서 append 된다
		Writer w = new OutputStreamWriter(fos);
		
		w.write("안녕하세요");
		String str = "안녕하세요////";
		w.write(str);
		w.close();
		fos.close();
		
		
		
		
		try (FileWriter fw = new FileWriter("c:/DailyJava2/writer.txt",true)) {	
			fw.write("안녕하세요. 반갑습니다. 또만나요.");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		

		
		*/
	}
	
	
	public static void AnsiUtf8Check1() {
		try(FileOutputStream fos = new FileOutputStream("c:/DailyJava2/writer.txt")){
			fos.write('안');
			fos.write('녕'); 
			fos.write('하'); 
			fos.write('세'); 
			fos.write('요'); 
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		try(Writer fw = new FileWriter("c:/DailyJava2/writer.txt" , true)){
			fw.write("안녕하세요");
			fw.close();	
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}
	
	public static void AnsiUtf8Check2() {
		
		try(Writer fw = new FileWriter("c:/DailyJava2/writer.txt")){
			fw.write("안녕하세요");
			fw.close();
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		try(FileOutputStream fos = new FileOutputStream("c:/DailyJava2/writer.txt",true)){
			fos.write('안');
			fos.write('녕'); 
			fos.write('하'); 
			fos.write('세'); 
			fos.write('요'); 
			fos.close();
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public static void AnsiUtf8Check3() {
		
		try(Writer fw = new FileWriter("c:/DailyJava2/writer.txt")){
			fw.write("안녕하세요");
			fw.close();
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		try(Writer fw = new FileWriter("c:/DailyJava2/writer.txt" , true)){
			fw.write('안');
			fw.write('녕'); 
			fw.write('하'); 
			fw.write('세'); 
			fw.write('요'); 
			fw.close();
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
public static void AnsiUtf8Check4() {
	
		try(FileOutputStream fos = new FileOutputStream("c:/DailyJava2/writer.txt",true) ; Writer osw = new OutputStreamWriter(fos)){
			osw.write("안녕하슈");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}

	}


